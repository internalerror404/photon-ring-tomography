"""Independent readback and human report for Movie008. No source generation or fitting."""
from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd

from common import ROOT, RESULTS, dump, load_inputs, load_movie007_module, noise_calibration, project_modes, sha256, weighted_target_metrics


def main() -> None:
    start = time.perf_counter()
    arrays, _support, _selection, input_hashes = load_inputs()
    m = load_movie007_module()
    summary = json.loads((RESULTS / "SUMMARY.json").read_text())
    df = pd.read_csv(RESULTS / "PER_RECONSTRUCTION.csv")
    frames = pd.read_csv(RESULTS / "PER_FRAME.csv")
    construction = pd.read_csv(RESULTS / "TWIN_CONSTRUCTION_GATES.csv")
    bank = np.load(RESULTS / "MODE_BANK.npz", allow_pickle=False)
    payload = np.load(RESULTS / "TWIN_SOURCES_AND_ESTIMATES.npz", allow_pickle=False)
    modes = bank["mode_coefficients"]
    H = arrays["H"]

    # Byte and algebra checks.
    mode_orth = float(np.linalg.norm(modes.T @ H @ modes - np.eye(4), ord=2))
    direct8 = arrays["A_q8_n0"] @ payload["target_unit_coefficients"]
    direct12 = arrays["A_q12_n0"] @ payload["target_unit_coefficients"]
    fresh_estimate_checks = []
    for pair in (0, 19, 20, 39, 40, 59):
        w = payload["directions"][pair]
        for sign in (1, -1):
            key = f"cond_snr300_a0.08_p{pair}_sgn{sign}_d0_labelled"
            a = payload[key]
            c = modes @ a
            back = project_modes(c, modes, H)
            fresh_estimate_checks.append(float(np.max(np.abs(a - back))))

    primary = df[(df.snr == 300) & np.isclose(df.alpha, 0.08) & (df.estimator == "conditional_gls")]
    direct = primary[primary.arm == "direct"].sort_values(["pair", "sign", "draw"])
    labelled = primary[primary.arm == "labelled"].sort_values(["pair", "sign", "draw"])
    paired_output_identity = True
    for (pair, draw), g in direct.groupby(["pair", "draw"]):
        if len(g) != 2:
            paired_output_identity = False
            break
        # Registered direct estimate is identically zero for both signs.
        for sign in (1, -1):
            key = f"cond_snr300_a0.08_p{pair}_sgn{sign}_d{draw}_direct"
            paired_output_identity &= np.array_equal(payload[key], np.zeros(4))

    checks = {
        "summary_status_matches_checks": (summary["status"].endswith("PASS")) == all(summary["checks"].values()),
        "input_hashes_match": input_hashes == summary["input_hashes"],
        "mode_source_orthonormality": mode_orth <= 1e-10,
        "fresh_target_direct_q8_exact_zero": float(np.max(np.abs(direct8))) == 0.0,
        "fresh_target_direct_q12_exact_zero": float(np.max(np.abs(direct12))) == 0.0,
        "direct_estimates_identical_and_zero": paired_output_identity,
        "mode_projection_roundtrip": max(fresh_estimate_checks) <= 1e-12,
        "all_numeric_tables_finite": all(np.isfinite(x.select_dtypes(include=[np.number]).to_numpy()).all() for x in (df, frames, construction)),
        "primary_case_count_480_per_arm": len(direct) == 480 and len(labelled) == 480,
        "no_physical_attempt_ledger_created": not (ROOT / "attempts" / "physical_calls.jsonl").exists(),
    }
    if not all(checks.values()):
        raise AssertionError(checks)

    agg = pd.read_csv(RESULTS / "AGGREGATE.csv")
    groups = pd.read_csv(RESULTS / "GROUP_RESULTS.csv")
    p = summary["primary"]
    report = f"""# Mahakal II Movie008 — direct-null twin-movie recovery

## Outcome

**{summary['status']}**

Movie008 asks a causal question that Movie007's union-support comparison could not isolate: can the first indirect image recover which old spatial movie occurred when the direct observations are exactly identical?

The frozen target is a four-dimensional subspace selected from a 210-dimensional old, non-axisymmetric parent space after profiling a declared 385-dimensional nuisance movie. Both q8 and q12 direct target matrices are exactly zero. The first-indirect response remains strong and numerically stable.

## Primary result

At SNR0=300 and target source norm alpha=0.08:

- direct-only twin identity accuracy: **{100*p['direct_identity_accuracy']:.2f}%**;
- direct+order1 twin identity accuracy: **{100*p['labelled_identity_accuracy']:.2f}%**;
- labelled median target-coefficient relative error: **{p['labelled_median_target_relative_error']:.4f}**;
- labelled 90th-percentile target error: **{p['labelled_p90_target_relative_error']:.4f}**;
- labelled all-active-frame movie pass rate: **{100*p['labelled_movie_pass_rate']:.2f}%**;
- minimum q12 whitened separation between a twin pair: **{p['minimum_q12_twin_whitened_separation']:.3f}**.

The direct result is exactly 50% because every pair includes both signs, uses the same direct noise, and the registered direct target estimate is the same zero vector for both. This is an information limit, not a failed optimizer. The labelled estimator sees the first-indirect rows and estimates all four unknown movie coefficients after profiling nuisance.

The pair-cluster bootstrap identity interval (median, 2.5%, 97.5%) is `{p['bootstrap_identity_accuracy_median_p2p5_p97p5']}`. The corresponding movie-pass interval is `{p['bootstrap_movie_pass_median_p2p5_p97p5']}`.

## Aggregate estimator results

{agg.to_markdown(index=False)}

## Complexity-group results

{groups.to_markdown(index=False)}

## What is reconstructed

The target component is a spatially non-axisymmetric movie supported only on temporal B-splines missed by the direct rays. Each fresh history is a two-, three-, or four-mode combination active on at least eight old frames between tau=-6M and -28M. Movie frames are scored on an order1-only source-plane support kernel, avoiding Movie007's union-support mixture of time reach and added spatial coverage.

The nuisance background is unknown to the estimator and spans every direct-visible temporal coefficient plus old axisymmetric structure. It is removed in data space before the four target coefficients are estimated. Other old non-axisymmetric source directions are not included as nuisance; the result is conditional on that declared finite source class.

## Numerical and positivity checks

- Mode source-orthonormality error: `{mode_orth:.3e}`.
- Fresh q8 and q12 direct target maxima: exactly `0.0`.
- Maximum q8/q12 twin relative discrepancy: `{summary['construction']['max_q8_q12_twin_relative']:.3e}`.
- Maximum q8/q12 twin whitened discrepancy: `{summary['construction']['max_q8_q12_twin_whitened']:.3e}`.
- Analytic minimum emissivity bound over all signs/amplitudes: `{summary['construction']['minimum_analytic_emissivity_bound']:.4f}`.
- New physical calls: **0**; Paper I units used: **0**.

The positivity statement follows from the nonnegative radial/time B-spline partitions and the uniform trigonometric coefficient envelope, not only from sampled pixels.

## Interpretation and limits

A positive result supports: **the first indirect Kerr image selects and reconstructs the correct old finite-model movie among direct-indistinguishable twins after the declared nuisance background is profiled out.** It is stronger causal evidence than a lower average error on a union support.

It does not establish blind recovery of arbitrary old emission. The four target modes were chosen for conditional order1 response, the nuisance model excludes other old non-axisymmetric directions, the geometry is one Kerr chart, image-order labels are ideal, and no interferometric/telescope acquisition is modeled. Movie007's off-basis and full-annulus negatives remain standing.
"""
    (ROOT / "REPORT.md").write_text(report)
    dump(RESULTS / "VERIFICATION.json", {
        "checks": checks,
        "all_checks_pass": all(checks.values()),
        "mode_source_orthonormality_error": mode_orth,
        "fresh_direct_q8_max_abs": float(np.max(np.abs(direct8))),
        "fresh_direct_q12_max_abs": float(np.max(np.abs(direct12))),
        "mode_projection_roundtrip_max_abs": max(fresh_estimate_checks),
        "source_hashes": {p.name: sha256(p) for p in sorted((ROOT / "source").glob("*.py"))},
        "seconds": time.perf_counter() - start,
    })
    print(report)


if __name__ == "__main__":
    main()
