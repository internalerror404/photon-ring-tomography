"""Fresh Movie008 launcher. Mode bank is a required separately frozen artifact."""
from pathlib import Path
import os
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
if not (root / "results" / "MODE_BANK.npz").exists():
    raise SystemExit("MODE_BANK.npz is absent: run and freeze build_mode_bank.py before source generation")
if (root / "results" / "SUMMARY.json").exists():
    raise SystemExit("Results already exist; reproduce in a fresh directory")
env = {**os.environ, "OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1", "MKL_NUM_THREADS": "1", "NUMEXPR_NUM_THREADS": "1"}
for script in ("run_experiment.py", "verify_and_report.py"):
    subprocess.run([sys.executable, str(root / "source" / script)], cwd=root, env=env, check=True)
