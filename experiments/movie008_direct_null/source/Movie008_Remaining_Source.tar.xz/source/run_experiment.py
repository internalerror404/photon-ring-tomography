"""Execute the frozen Movie008 direct-null twin experiment. No physical calls."""
from __future__ import annotations

import json
import time
from collections import defaultdict

import numpy as np
import pandas as pd
from scipy import linalg

from common import (
    INPUTS,
    RESULTS,
    coefficient_envelope,
    dump,
    load_inputs,
    load_movie007_module,
    make_nuisance_background,
    noise_calibration,
    project_modes,
    residual_projector,
    source_norm,
    weighted_target_metrics,
)

PRIMARY_ALPHA = 0.08
SECONDARY_ALPHA = 0.04
ALPHAS = (PRIMARY_ALPHA, SECONDARY_ALPHA)
SNRS = (300, 100)
SIGNS = (1, -1)
DRAWS = 4
PAIRS = 60


def mode_activity(m, mode_coeff: np.ndarray, weights: np.ndarray) -> dict[str, object]:
    frames = m.eval_frames(mode_coeff)
    old = np.arange(3, 15)
    rms = np.sqrt(np.sum(weights[old] * frames[old] ** 2, axis=(1, 2)))
    threshold = 0.20 * max(float(rms.max()), 1e-15)
    active = rms >= threshold
    return {
        "rms": rms,
        "active": active,
        "accepted": bool(active.sum() >= 8 and active[:6].any() and active[6:].any()),
    }


def generate_directions(m, mode_coeff: np.ndarray, weights: np.ndarray) -> tuple[np.ndarray, list[dict]]:
    rng = np.random.default_rng(80062)
    directions = []
    ledger = []
    groups = [("two_mode", 2), ("three_mode", 3), ("four_mode", 4)]
    for group, nnz in groups:
        accepted = 0
        for candidate in range(500):
            ids = rng.choice(4, size=nnz, replace=False)
            w = np.zeros(4)
            w[ids] = rng.normal(size=nnz)
            w /= np.linalg.norm(w)
            coeff = mode_coeff @ w
            activity = mode_activity(m, coeff, weights)
            record = {
                "group": group,
                "candidate": candidate,
                "mode_indices": ids,
                "weights": w,
                "active_frames": int(np.sum(activity["active"])),
                "accepted": activity["accepted"],
            }
            ledger.append(record)
            if activity["accepted"]:
                directions.append(w)
                accepted += 1
                if accepted == 20:
                    break
        if accepted != 20:
            raise RuntimeError(f"Could not fill {group}: {accepted}/20")
    return np.asarray(directions), ledger


def conditional_estimator(A0, A1, std0, std1, nuisance_coeff, mode_coeff, arm: str):
    if arm == "direct":
        A = A0
        std = std0
    else:
        A = np.vstack([A0, A1])
        std = np.concatenate([std0, std1])
    bn = (A @ nuisance_coeff) / std[:, None]
    bt = (A @ mode_coeff) / std[:, None]
    qn, nuisance_rank, nuisance_s = residual_projector(bn, 1e-12)
    e = bt - qn @ (qn.T @ bt)
    if arm == "direct":
        if np.max(np.abs(e)) != 0.0:
            raise AssertionError("Direct conditional target is not exactly zero")
        return {"std": std, "qn": qn, "e": e, "pinv": np.zeros((4, len(std))), "rank": nuisance_rank}
    u, s, vt = linalg.svd(e, full_matrices=False, lapack_driver="gesdd", check_finite=False)
    keep = s > 1e-12 * s[0]
    pinv = vt[keep].T @ ((1.0 / s[keep])[:, None] * u[:, keep].T)
    return {"std": std, "qn": qn, "e": e, "pinv": pinv, "rank": nuisance_rank, "s": s}


def full_estimator_setup(m, arrays, selection, sigma, shape0, shape1, snr: int, arm: str, method: str):
    std0 = sigma * 300.0 / snr * shape0
    std1 = sigma * 300.0 / snr * shape1
    if arm == "direct":
        A = arrays["A_q8_n0"]
        std = std0
    else:
        A = np.vstack([arrays["A_q8_n0"], arrays["A_q8_n1"]])
        std = np.concatenate([std0, std1])
    B = m.source_normalized_operator(A, std, arrays["H_chol"])
    if method == "ridge":
        gram = B.T @ B
        # Selection scale at SNR300; B^T B scales as SNR^2.
        scale = selection[arm]["ridge_scale"] * (snr / 300.0) ** 2
        alpha = 10.0 ** selection[arm]["ridge_exponent"] * scale
        cf = linalg.cho_factor(gram + alpha * arrays["penalty"], lower=True, check_finite=False)
        return {"B": B, "std": std, "solve": lambda y: linalg.cho_solve(cf, B.T @ y, check_finite=False)}
    u, s, vt = linalg.svd(B, full_matrices=False, lapack_driver="gesdd", check_finite=False)
    keep = s >= selection[arm]["tsvd_cutoff"] * s[0]
    return {"B": B, "std": std, "solve": lambda y: vt[keep].T @ ((u[:, keep].T @ y) / s[keep, None])}


def bootstrap_cluster(values: np.ndarray, pairs: np.ndarray, seed: int, resamples: int = 2000) -> np.ndarray:
    rng = np.random.default_rng(seed)
    unique = np.unique(pairs)
    out = np.empty(resamples)
    for j in range(resamples):
        chosen = rng.choice(unique, size=len(unique), replace=True)
        idx = np.concatenate([np.where(pairs == p)[0] for p in chosen])
        out[j] = np.mean(values[idx])
    return out


def main() -> None:
    if (RESULTS / "SUMMARY.json").exists():
        raise RuntimeError("Movie008 results already exist; use a fresh directory")
    start = time.perf_counter()
    arrays, support, selection, input_hashes = load_inputs()
    m = load_movie007_module()
    bank = np.load(RESULTS / "MODE_BANK.npz", allow_pickle=False)
    bank_info = json.loads((RESULTS / "MODE_BANK.json").read_text())
    mode_coeff = bank["mode_coefficients"]
    target_indices = bank["target_indices"]
    nuisance_indices = bank["nuisance_indices"]
    nuisance_coeff = np.eye(595)[:, nuisance_indices]
    H = arrays["H"]
    L = arrays["H_chol"]
    sigma300, shape0, shape1 = noise_calibration(arrays)

    # Order1-only support. Rebuild from authenticated q12 physical arrays with no ray call.
    def design(q, order):
        tuples = arrays[f"tuples_q{q}_n{order}"]
        weights = arrays[f"weights_q{q}_n{order}"]
        pixels = arrays[f"pixel_q{q}_n{order}"]
        return m.PhysicalDesign(q, order, np.zeros((len(tuples), 2)), pixels, weights, tuples, np.bincount(pixels, weights, minlength=64))

    W1 = m.support_weights([design(12, 1)])
    directions, direction_ledger = generate_directions(m, mode_coeff, W1)
    groups = np.repeat(np.array(["two_mode", "three_mode", "four_mode"]), 20)
    if len(directions) != PAIRS:
        raise AssertionError("Direction count mismatch")

    # Fresh nuisance backgrounds.
    bg_rng = np.random.default_rng(80061)
    backgrounds = []
    background_records = []
    for pair in range(PAIRS):
        coeff, record = make_nuisance_background(bg_rng, nuisance_indices)
        record["pair"] = pair
        record["source_norm"] = source_norm(coeff, H)
        backgrounds.append(coeff)
        background_records.append(record)
    backgrounds = np.column_stack(backgrounds)

    target_unit = mode_coeff @ directions.T
    target_orth = float(np.linalg.norm(target_unit.T @ H @ target_unit - directions @ directions.T, ord=2))
    target_env = np.array([coefficient_envelope(target_unit[:, i]) for i in range(PAIRS)])
    background_env = np.array([x["certified_envelope"] for x in background_records])
    positivity_lower = {
        str(alpha): 1.0 - background_env - alpha * target_env for alpha in ALPHAS
    }
    if min(np.min(v) for v in positivity_lower.values()) < 0.5:
        raise AssertionError("Analytic positivity gate failed")

    # q8/q12 target construction checks before noise.
    direct8 = arrays["A_q8_n0"] @ target_unit
    direct12 = arrays["A_q12_n0"] @ target_unit
    order1_8 = arrays["A_q8_n1"] @ target_unit
    order1_12 = arrays["A_q12_n1"] @ target_unit
    if np.max(np.abs(direct8)) != 0.0 or np.max(np.abs(direct12)) != 0.0:
        raise AssertionError("Fresh target directions are not exactly direct-null")

    records = []
    frame_records = []
    estimates = {}
    standardized_noise = {}
    construction_rows = []
    oracle_rows = []
    max_paired_noisy_direct_difference = 0.0
    paired_noisy_direct_identical = True
    rng_noise = np.random.default_rng(80063)

    for snr in SNRS:
        sigma = sigma300 * 300.0 / snr
        std0 = sigma * shape0
        std1 = sigma * shape1
        cond = {
            arm: conditional_estimator(
                arrays["A_q8_n0"], arrays["A_q8_n1"], std0, std1, nuisance_coeff, mode_coeff, arm
            )
            for arm in ("direct", "labelled")
        }
        full_setups = {
            (arm, method): full_estimator_setup(m, arrays, selection, sigma300, shape0, shape1, snr, arm, method)
            for arm in ("direct", "labelled")
            for method in ("ridge", "tsvd")
        }

        # Shared standardized noise for both amplitudes and both signs. This makes
        # amplitude sensitivity paired without multiplying independent samples.
        noise0 = rng_noise.normal(size=(832, PAIRS, DRAWS))
        noise1 = rng_noise.normal(size=(832, PAIRS, DRAWS))
        standardized_noise[f"z0_{snr}"] = noise0
        standardized_noise[f"z1_{snr}"] = noise1

        for alpha in ALPHAS:
            # Clean q12 signal, arranged by pair and sign below.
            for pair in range(PAIRS):
                bg = backgrounds[:, pair]
                h = target_unit[:, pair]
                w = directions[pair]
                group = groups[pair]
                y8diff = 2 * alpha * order1_8[:, pair]
                y12diff = 2 * alpha * order1_12[:, pair]
                rel = float(np.linalg.norm(y8diff - y12diff) / max(np.linalg.norm(y12diff), 1e-15))
                white = float(np.linalg.norm((y8diff - y12diff) / std1))
                separation = float(np.linalg.norm(y12diff / std1))
                construction_rows.append({
                    "snr": snr, "alpha": alpha, "pair": pair, "group": group,
                    "direct_q8_max_abs": float(np.max(np.abs(2 * alpha * direct8[:, pair]))),
                    "direct_q12_max_abs": float(np.max(np.abs(2 * alpha * direct12[:, pair]))),
                    "labelled_q12_twin_whitened_separation": separation,
                    "q8_q12_twin_relative": rel,
                    "q8_q12_twin_whitened": white,
                    "minimum_emissivity_bound": float(positivity_lower[str(alpha)][pair]),
                })

                clean_by_sign = {}
                for sign in SIGNS:
                    c = bg + sign * alpha * h
                    clean0 = arrays["base_q12_n0"] + arrays["A_q12_n0"] @ c
                    clean1 = arrays["base_q12_n1"] + arrays["A_q12_n1"] @ c
                    clean_by_sign[sign] = (clean0, clean1)
                if not np.array_equal(clean_by_sign[1][0], clean_by_sign[-1][0]):
                    raise AssertionError("Direct q12 twins are not byte-identical")

                for draw in range(DRAWS):
                    # Build both signs with the same noise before evaluating any estimator.
                    noisy0_by_sign = {
                        sign: clean_by_sign[sign][0] + std0 * noise0[:, pair, draw]
                        for sign in SIGNS
                    }
                    noisy_direct_difference = float(np.max(np.abs(noisy0_by_sign[1] - noisy0_by_sign[-1])))
                    max_paired_noisy_direct_difference = max(max_paired_noisy_direct_difference, noisy_direct_difference)
                    paired_noisy_direct_identical &= np.array_equal(noisy0_by_sign[1], noisy0_by_sign[-1])
                    clean_labelled_plus = np.concatenate(clean_by_sign[1])
                    clean_labelled_minus = np.concatenate(clean_by_sign[-1])
                    std_labelled = np.concatenate([std0, std1])
                    for sign in SIGNS:
                        true_a = sign * alpha * w
                        true_target_c = mode_coeff @ true_a
                        true_frames = m.eval_frames(true_target_c)
                        clean0, clean1 = clean_by_sign[sign]
                        noisy0 = noisy0_by_sign[sign]
                        noisy1 = clean1 + std1 * noise1[:, pair, draw]
                        labelled_data_for_oracle = np.concatenate([noisy0, noisy1])
                        oracle_dplus = float(np.sum(((labelled_data_for_oracle - clean_labelled_plus) / std_labelled) ** 2))
                        oracle_dminus = float(np.sum(((labelled_data_for_oracle - clean_labelled_minus) / std_labelled) ** 2))
                        oracle_sign = 1 if oracle_dplus <= oracle_dminus else -1
                        oracle_rows.append({
                            "snr": snr, "alpha": alpha, "pair": pair, "group": group,
                            "sign": sign, "draw": draw,
                            "labelled_pair_likelihood_identity_correct": int(oracle_sign == sign),
                            "labelled_pair_likelihood_delta_chi2": oracle_dminus - oracle_dplus,
                            "direct_pair_likelihood_delta_chi2": 0.0,
                        })
                        for arm in ("direct", "labelled"):
                            if arm == "direct":
                                data = noisy0
                                base8 = arrays["base_q8_n0"]
                            else:
                                data = np.concatenate([noisy0, noisy1])
                                base8 = np.concatenate([arrays["base_q8_n0"], arrays["base_q8_n1"]])
                            y = (data - base8) / cond[arm]["std"]
                            if arm == "direct":
                                a_hat = np.zeros(4)
                            else:
                                yperp = y - cond[arm]["qn"] @ (cond[arm]["qn"].T @ y)
                                a_hat = cond[arm]["pinv"] @ yperp
                            pred_target_c = mode_coeff @ a_hat
                            pred_frames = m.eval_frames(pred_target_c)
                            metric = weighted_target_metrics(true_frames, pred_frames, W1)
                            dot = float(a_hat @ w)
                            pred_sign = 1 if dot >= 0 else -1
                            nearest = int(pred_sign == sign)
                            relerr = float(np.linalg.norm(a_hat - true_a) / alpha)
                            cosine = float(a_hat @ true_a / max(np.linalg.norm(a_hat) * alpha, 1e-15))
                            key = f"cond_snr{snr}_a{alpha}_p{pair}_sgn{sign}_d{draw}_{arm}"
                            estimates[key] = a_hat
                            rec = {
                                "snr": snr, "alpha": alpha, "pair": pair, "group": group,
                                "sign": sign, "draw": draw, "arm": arm, "estimator": "conditional_gls",
                                "identity_correct": nearest, "target_relative_error": relerr,
                                "target_cosine": cosine, "active_frames": metric["active_frames"],
                                "movie_pass": metric["history_pass"],
                                "mean_active_frame_error": metric["mean_active_error"],
                                "minimum_active_correlation": metric["minimum_active_correlation"],
                            }
                            records.append(rec)
                            for local, frame_index in enumerate(metric["old_frame_indices"]):
                                frame_records.append({
                                    **{k: rec[k] for k in ("snr", "alpha", "pair", "group", "sign", "draw", "arm", "estimator")},
                                    "tau": float(m.MOVIE_TIMES[frame_index]),
                                    "active": bool(metric["active"][local]),
                                    "error": float(metric["error"][local]),
                                    "correlation": float(metric["correlation"][local]),
                                    "pass": bool(metric["passed"][local]),
                                })

                            # Secondary whole-movie estimators.
                            for method in ("ridge", "tsvd"):
                                setup = full_setups[(arm, method)]
                                yfull = (data - base8) / setup["std"]
                                xhat = setup["solve"](yfull[:, None])[:, 0]
                                chat = m.x_to_coeff(xhat, L)
                                a_full = project_modes(chat, mode_coeff, H)
                                pred_target_full = mode_coeff @ a_full
                                metric_full = weighted_target_metrics(true_frames, m.eval_frames(pred_target_full), W1)
                                dot_full = float(a_full @ w)
                                pred_sign_full = 1 if dot_full >= 0 else -1
                                key2 = f"{method}_snr{snr}_a{alpha}_p{pair}_sgn{sign}_d{draw}_{arm}"
                                estimates[key2] = a_full
                                records.append({
                                    "snr": snr, "alpha": alpha, "pair": pair, "group": group,
                                    "sign": sign, "draw": draw, "arm": arm, "estimator": method,
                                    "identity_correct": int(pred_sign_full == sign),
                                    "target_relative_error": float(np.linalg.norm(a_full - true_a) / alpha),
                                    "target_cosine": float(a_full @ true_a / max(np.linalg.norm(a_full) * alpha, 1e-15)),
                                    "active_frames": metric_full["active_frames"],
                                    "movie_pass": metric_full["history_pass"],
                                    "mean_active_frame_error": metric_full["mean_active_error"],
                                    "minimum_active_correlation": metric_full["minimum_active_correlation"],
                                })

    df = pd.DataFrame(records)
    frames_df = pd.DataFrame(frame_records)
    construction = pd.DataFrame(construction_rows)
    df.to_csv(RESULTS / "PER_RECONSTRUCTION.csv", index=False)
    frames_df.to_csv(RESULTS / "PER_FRAME.csv", index=False)
    construction.to_csv(RESULTS / "TWIN_CONSTRUCTION_GATES.csv", index=False)
    oracle_df = pd.DataFrame(oracle_rows)
    oracle_df.to_csv(RESULTS / "PAIR_LIKELIHOOD_DIAGNOSTIC.csv", index=False)
    dump(RESULTS / "PAIRED_DIRECT_OBSERVATION_CHECK.json", {
        "byte_identical": bool(paired_noisy_direct_identical),
        "max_abs_difference": max_paired_noisy_direct_difference,
        "scope": "Same q12 direct clean signal and same standardized direct noise within each balanced twin pair.",
    })
    np.savez_compressed(
        RESULTS / "TWIN_SOURCES_AND_ESTIMATES.npz",
        backgrounds=backgrounds,
        directions=directions,
        groups=groups,
        target_unit_coefficients=target_unit,
        mode_coefficients=mode_coeff,
        **estimates,
    )
    np.savez_compressed(RESULTS / "STANDARDIZED_NOISE.npz", **standardized_noise)
    dump(RESULTS / "DIRECTION_CANDIDATE_LEDGER.json", direction_ledger)
    dump(RESULTS / "BACKGROUND_RECORDS.json", background_records)

    # Aggregate outcomes and paired cluster bootstrap.
    aggregate = []
    family = []
    for keys, g in df.groupby(["snr", "alpha", "arm", "estimator"]):
        snr, alpha, arm, estimator = keys
        aggregate.append({
            "snr": int(snr), "alpha": float(alpha), "arm": arm, "estimator": estimator,
            "identity_accuracy": float(g.identity_correct.mean()),
            "median_target_relative_error": float(g.target_relative_error.median()),
            "p90_target_relative_error": float(g.target_relative_error.quantile(0.90)),
            "movie_pass_rate": float(g.movie_pass.mean()),
            "median_active_frame_error": float(g.mean_active_frame_error.median()),
            "median_minimum_active_correlation": float(g.minimum_active_correlation.median()),
        })
    for keys, g in df.groupby(["snr", "alpha", "arm", "estimator", "group"]):
        snr, alpha, arm, estimator, group = keys
        family.append({
            "snr": int(snr), "alpha": float(alpha), "arm": arm, "estimator": estimator, "group": group,
            "identity_accuracy": float(g.identity_correct.mean()),
            "median_target_relative_error": float(g.target_relative_error.median()),
            "movie_pass_rate": float(g.movie_pass.mean()),
            "cases": len(g),
        })
    agg = pd.DataFrame(aggregate)
    fam = pd.DataFrame(family)
    agg.to_csv(RESULTS / "AGGREGATE.csv", index=False)
    fam.to_csv(RESULTS / "GROUP_RESULTS.csv", index=False)

    primary = df[(df.snr == 300) & (np.isclose(df.alpha, PRIMARY_ALPHA)) & (df.estimator == "conditional_gls")]
    pdirect = primary[primary.arm == "direct"].sort_values(["pair", "sign", "draw"])
    plabel = primary[primary.arm == "labelled"].sort_values(["pair", "sign", "draw"])
    bacc = bootstrap_cluster(plabel.identity_correct.to_numpy(), plabel.pair.to_numpy(), 80064)
    bmovie = bootstrap_cluster(plabel.movie_pass.to_numpy(dtype=float), plabel.pair.to_numpy(), 80065)
    minsep = float(construction[(construction.snr == 300) & np.isclose(construction.alpha, PRIMARY_ALPHA)].labelled_q12_twin_whitened_separation.min())
    maxrel = float(construction.q8_q12_twin_relative.max())
    maxwhite = float(construction.q8_q12_twin_whitened.max())

    checks = {
        "authenticated_inputs": True,
        "mode_bank_checks": all(bank_info["checks"].values()),
        "fresh_direction_count_60": len(directions) == 60,
        "all_directions_active_at_least_8": all(x["active_frames"] >= 8 for x in direction_ledger if x["accepted"]),
        "analytic_positivity_minimum_at_least_0p5": min(np.min(v) for v in positivity_lower.values()) >= 0.5,
        "direct_q8_exact_null": float(np.max(np.abs(direct8))) == 0.0,
        "direct_q12_exact_null": float(np.max(np.abs(direct12))) == 0.0,
        "paired_direct_observations_identical": bool(paired_noisy_direct_identical and max_paired_noisy_direct_difference == 0.0),
        "primary_labelled_twin_separation_min5": minsep >= 5.0,
        "q8_q12_twin_relative": maxrel <= 5e-4,
        "q8_q12_twin_whitened": maxwhite <= 0.1,
        "primary_direct_accuracy_exact_half": float(pdirect.identity_correct.mean()) == 0.5,
        "primary_labelled_accuracy_at_least_0p95": float(plabel.identity_correct.mean()) >= 0.95,
        "primary_labelled_median_error_at_most_0p35": float(plabel.target_relative_error.median()) <= 0.35,
        "primary_labelled_p90_error_at_most_0p60": float(plabel.target_relative_error.quantile(0.90)) <= 0.60,
        "primary_labelled_movie_pass_at_least_0p95": float(plabel.movie_pass.mean()) >= 0.95,
        "each_group_accuracy_at_least_0p90": bool((plabel.groupby("group").identity_correct.mean() >= 0.90).all()),
        "no_new_physical_calls": True,
        "paper1_units_used_zero": True,
    }
    status = "MOVIE008_DIRECT_NULL_TWIN_MOVIE_PASS" if all(checks.values()) else "MOVIE008_DIRECT_NULL_TWIN_MOVIE_FAIL"
    summary = {
        "experiment": "Mahakal II Movie008 direct-null twin movie recovery",
        "status": status,
        "checks": checks,
        "primary": {
            "snr": 300, "alpha": PRIMARY_ALPHA, "estimator": "conditional_gls",
            "direct_identity_accuracy": float(pdirect.identity_correct.mean()),
            "labelled_identity_accuracy": float(plabel.identity_correct.mean()),
            "labelled_median_target_relative_error": float(plabel.target_relative_error.median()),
            "labelled_p90_target_relative_error": float(plabel.target_relative_error.quantile(0.90)),
            "labelled_movie_pass_rate": float(plabel.movie_pass.mean()),
            "minimum_q12_twin_whitened_separation": minsep,
            "labelled_pair_likelihood_selector_accuracy": float(oracle_df[(oracle_df.snr == 300) & np.isclose(oracle_df.alpha, PRIMARY_ALPHA)].labelled_pair_likelihood_identity_correct.mean()),
            "direct_pair_likelihood_is_exact_tie": bool((oracle_df.direct_pair_likelihood_delta_chi2 == 0.0).all()),
            "bootstrap_identity_accuracy_median_p2p5_p97p5": [float(np.median(bacc)), float(np.percentile(bacc, 2.5)), float(np.percentile(bacc, 97.5))],
            "bootstrap_movie_pass_median_p2p5_p97p5": [float(np.median(bmovie)), float(np.percentile(bmovie, 2.5)), float(np.percentile(bmovie, 97.5))],
        },
        "aggregate": aggregate,
        "group_results": family,
        "construction": {
            "target_parent_dimension": 210,
            "nuisance_dimension": 385,
            "frozen_modes": 4,
            "pairs": PAIRS,
            "signs": 2,
            "draws": DRAWS,
            "primary_cases": len(plabel),
            "target_direction_gram_error": target_orth,
            "minimum_analytic_emissivity_bound": float(min(np.min(v) for v in positivity_lower.values())),
            "max_q8_q12_twin_relative": maxrel,
            "max_q8_q12_twin_whitened": maxwhite,
            "paired_noisy_direct_max_abs_difference": max_paired_noisy_direct_difference,
        },
        "input_hashes": input_hashes,
        "paper1_units_used": 0,
        "new_physical_calls": 0,
        "scope": [
            "one Movie007 Kerr chart with ideal order labels",
            "four-mode old nonaxisymmetric target under a 385-dimensional declared nuisance model",
            "order1-only measured-support movie metric",
            "not arbitrary nuisance, off-basis, full-annulus, visibility-domain, or telescope movie recovery",
        ],
        "seconds": time.perf_counter() - start,
    }
    dump(RESULTS / "SUMMARY.json", summary)
    dump(ROOT / "SUMMARY.json", summary)
    print(status)
    print(agg.to_string(index=False))


if __name__ == "__main__":
    main()
