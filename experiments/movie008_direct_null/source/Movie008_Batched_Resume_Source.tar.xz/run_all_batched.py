"""Movie008 post-mode-bank launcher after the recorded scalar timeout."""
from pathlib import Path
import os
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
if not (root / "results" / "MODE_BANK.npz").exists():
    raise SystemExit("MODE_BANK.npz is absent: build and freeze it first")
if (root / "results" / "SUMMARY.json").exists():
    raise SystemExit("Results already exist; reproduce in a fresh directory")
env = {**os.environ, "OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1", "MKL_NUM_THREADS": "1", "NUMEXPR_NUM_THREADS": "1"}
for script in ("run_experiment_batched.py", "verify_and_report_batched.py"):
    subprocess.run([sys.executable, str(root / "source" / script)], cwd=root, env=env, check=True)
