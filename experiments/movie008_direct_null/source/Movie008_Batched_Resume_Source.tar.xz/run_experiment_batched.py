"""Batched Movie008 execution after the recorded scalar-loop timeout.

The physical inputs, frozen mode bank, source/noise seeds, source classes,
estimators, thresholds and endpoints are unchanged.  The implementation batches
linear solves and mode-frame evaluation and validates scalar/batch equivalence on
a fixed first case before writing any fresh scientific result.
"""
from __future__ import annotations

import json
import time
from typing import Any

import numpy as np
import pandas as pd
from scipy import linalg

from common import (
    ROOT,
    RESULTS,
    coefficient_envelope,
    dump,
    load_inputs,
    load_movie007_module,
    make_nuisance_background,
    noise_calibration,
    project_modes,
    residual_projector,
    source_norm,
    weighted_target_metrics,
)

PRIMARY_ALPHA = 0.08
SECONDARY_ALPHA = 0.04
ALPHAS = (PRIMARY_ALPHA, SECONDARY_ALPHA)
SNRS = (300, 100)
SIGNS = np.array([1, -1], dtype=np.int64)
DRAWS = 4
PAIRS = 60
MODE_COUNT = 4


def mode_activity(m, mode_coeff: np.ndarray, weights: np.ndarray) -> dict[str, object]:
    frames = m.eval_frames(mode_coeff)
    old = np.arange(3, 15)
    rms = np.sqrt(np.sum(weights[old] * frames[old] ** 2, axis=(1, 2)))
    threshold = 0.20 * max(float(rms.max()), 1e-15)
    active = rms >= threshold
    return {
        "rms": rms,
        "active": active,
        "accepted": bool(active.sum() >= 8 and active[:6].any() and active[6:].any()),
    }


def generate_directions(m, mode_coeff: np.ndarray, weights: np.ndarray) -> tuple[np.ndarray, list[dict[str, Any]]]:
    rng = np.random.default_rng(80062)
    directions: list[np.ndarray] = []
    ledger: list[dict[str, Any]] = []
    groups = [("two_mode", 2), ("three_mode", 3), ("four_mode", 4)]
    for group, nnz in groups:
        accepted = 0
        for candidate in range(500):
            ids = rng.choice(MODE_COUNT, size=nnz, replace=False)
            w = np.zeros(MODE_COUNT)
            w[ids] = rng.normal(size=nnz)
            w /= np.linalg.norm(w)
            coeff = mode_coeff @ w
            activity = mode_activity(m, coeff, weights)
            ledger.append({
                "group": group,
                "candidate": candidate,
                "mode_indices": ids,
                "weights": w,
                "active_frames": int(np.sum(activity["active"])),
                "accepted": activity["accepted"],
            })
            if activity["accepted"]:
                directions.append(w)
                accepted += 1
                if accepted == 20:
                    break
        if accepted != 20:
            raise RuntimeError(f"Could not fill {group}: {accepted}/20")
    return np.asarray(directions), ledger


def conditional_setup(A0, A1, std0, std1, nuisance_coeff, mode_coeff, arm: str):
    if arm == "direct":
        A = A0
        std = std0
    else:
        A = np.vstack([A0, A1])
        std = np.concatenate([std0, std1])
    bn = (A @ nuisance_coeff) / std[:, None]
    bt = (A @ mode_coeff) / std[:, None]
    qn, nuisance_rank, nuisance_s = residual_projector(bn, 1e-12)
    e = bt - qn @ (qn.T @ bt)
    if arm == "direct":
        if np.max(np.abs(e)) != 0.0:
            raise AssertionError("Direct conditional target is not exactly zero")
        pinv = np.zeros((MODE_COUNT, len(std)))
        s = np.zeros(MODE_COUNT)
    else:
        u, s, vt = linalg.svd(e, full_matrices=False, lapack_driver="gesdd", check_finite=False)
        keep = s > 1e-12 * s[0]
        pinv = vt[keep].T @ ((1.0 / s[keep])[:, None] * u[:, keep].T)
    return {"std": std, "qn": qn, "e": e, "pinv": pinv, "rank": nuisance_rank, "s": s, "nuisance_s": nuisance_s}


def build_full_estimator_bases(m, arrays, selection, sigma300, shape0, shape1):
    """Build SNR300 factorizations once; exact SNR scaling is applied later."""
    out: dict[tuple[str, str], dict[str, Any]] = {}
    for arm in ("direct", "labelled"):
        if arm == "direct":
            A = arrays["A_q8_n0"]
            std300 = sigma300 * shape0
        else:
            A = np.vstack([arrays["A_q8_n0"], arrays["A_q8_n1"]])
            std300 = sigma300 * np.concatenate([shape0, shape1])
        B300 = m.source_normalized_operator(A, std300, arrays["H_chol"])
        gram = B300.T @ B300
        alpha300 = 10.0 ** selection[arm]["ridge_exponent"] * selection[arm]["ridge_scale"]
        cf = linalg.cho_factor(gram + alpha300 * arrays["penalty"], lower=True, check_finite=False)
        out[(arm, "ridge")] = {"B300": B300, "std300": std300, "cf": cf}
        u, s, vt = linalg.svd(B300, full_matrices=False, lapack_driver="gesdd", check_finite=False)
        keep = s >= selection[arm]["tsvd_cutoff"] * s[0]
        out[(arm, "tsvd")] = {"B300": B300, "std300": std300, "u": u[:, keep], "s": s[keep], "vt": vt[keep]}
    return out


def solve_full_batched(setup: dict[str, Any], y: np.ndarray, snr: int, method: str) -> np.ndarray:
    """Return source-normalized coefficient matrix x, one column per case."""
    scale = snr / 300.0
    if method == "ridge":
        # B_s = scale B_300 and M_s = scale^2 M_300, hence x = scale^-1 M_300^-1 B_300^T y_s.
        return (1.0 / scale) * linalg.cho_solve(setup["cf"], setup["B300"].T @ y, check_finite=False)
    return (1.0 / scale) * setup["vt"].T @ ((setup["u"].T @ y) / setup["s"][:, None])


def mode_frame_metrics(
    mode_frames: np.ndarray,
    true_a: np.ndarray,
    pred_a: np.ndarray,
    weights: np.ndarray,
    *,
    chunk: int = 120,
) -> dict[str, np.ndarray]:
    """Vectorized equivalent of common.weighted_target_metrics for many cases."""
    n = true_a.shape[1]
    old = np.arange(3, 15)
    w = weights[old]
    out = {
        "true_rms": np.empty((12, n)),
        "pred_rms": np.empty((12, n)),
        "active": np.empty((12, n), dtype=bool),
        "error": np.empty((12, n)),
        "correlation": np.empty((12, n)),
        "passed": np.empty((12, n), dtype=bool),
        "active_frames": np.empty(n, dtype=np.int64),
        "history_pass": np.empty(n, dtype=bool),
        "mean_active_error": np.empty(n),
        "minimum_active_correlation": np.empty(n),
    }
    for lo in range(0, n, chunk):
        hi = min(n, lo + chunk)
        truth = np.einsum("trpm,mn->trpn", mode_frames[old], true_a[:, lo:hi], optimize=True)
        pred = np.einsum("trpm,mn->trpn", mode_frames[old], pred_a[:, lo:hi], optimize=True)
        ww = w[..., None]
        truth_rms = np.sqrt(np.sum(ww * truth**2, axis=(1, 2)))
        pred_rms = np.sqrt(np.sum(ww * pred**2, axis=(1, 2)))
        peak = np.max(truth_rms, axis=0)
        active = truth_rms >= 0.20 * np.maximum(peak, 1e-15)[None, :]
        err = np.sqrt(np.sum(ww * (pred - truth) ** 2, axis=(1, 2))) / np.maximum(truth_rms, 1e-15)
        mx = np.sum(ww * truth, axis=(1, 2))
        my = np.sum(ww * pred, axis=(1, 2))
        xc = truth - mx[:, None, None, :]
        yc = pred - my[:, None, None, :]
        cov = np.sum(ww * xc * yc, axis=(1, 2))
        den = np.sqrt(np.sum(ww * xc**2, axis=(1, 2)) * np.sum(ww * yc**2, axis=(1, 2)))
        corr = np.zeros_like(cov)
        np.divide(cov, den, out=corr, where=den > 1e-15)
        passed = active & (err <= 0.35) & (corr >= 0.75)
        active_count = np.sum(active, axis=0)
        history_pass = (active_count >= 8) & np.all((~active) | passed, axis=0)
        mean_err = np.sum(err * active, axis=0) / np.maximum(active_count, 1)
        min_corr = np.min(np.where(active, corr, np.inf), axis=0)
        min_corr = np.where(active_count > 0, min_corr, 0.0)
        sl = slice(lo, hi)
        out["true_rms"][:, sl] = truth_rms
        out["pred_rms"][:, sl] = pred_rms
        out["active"][:, sl] = active
        out["error"][:, sl] = err
        out["correlation"][:, sl] = corr
        out["passed"][:, sl] = passed
        out["active_frames"][sl] = active_count
        out["history_pass"][sl] = history_pass
        out["mean_active_error"][sl] = mean_err
        out["minimum_active_correlation"][sl] = min_corr
    return out


def add_records(
    record_frames: list[pd.DataFrame],
    frame_frames: list[pd.DataFrame],
    *,
    snr: int,
    alpha: float,
    arm: str,
    estimator: str,
    pair_idx: np.ndarray,
    sign_idx: np.ndarray,
    draw_idx: np.ndarray,
    group_idx: np.ndarray,
    true_a: np.ndarray,
    pred_a: np.ndarray,
    metrics: dict[str, np.ndarray],
    save_frames: bool,
) -> None:
    # Identity is the sign along the unsigned pair direction w. Since
    # true_a = sign * alpha * w, recover w without changing the case order.
    dot = sign_idx * np.sum(pred_a * true_a, axis=0) / alpha
    pred_sign = np.where(dot >= 0, 1, -1)
    norm_pred = np.linalg.norm(pred_a, axis=0)
    cosine = np.sum(pred_a * true_a, axis=0) / np.maximum(norm_pred * alpha, 1e-15)
    record_frames.append(pd.DataFrame({
        "snr": snr,
        "alpha": alpha,
        "pair": pair_idx,
        "group": group_idx,
        "sign": sign_idx,
        "draw": draw_idx,
        "arm": arm,
        "estimator": estimator,
        "identity_correct": (pred_sign == sign_idx).astype(np.int64),
        "target_relative_error": np.linalg.norm(pred_a - true_a, axis=0) / alpha,
        "target_cosine": cosine,
        "active_frames": metrics["active_frames"],
        "movie_pass": metrics["history_pass"],
        "mean_active_frame_error": metrics["mean_active_error"],
        "minimum_active_correlation": metrics["minimum_active_correlation"],
    }))
    if save_frames:
        rows = []
        old_times = -2.0 * np.arange(3, 15)
        for j, tau in enumerate(old_times):
            rows.append(pd.DataFrame({
                "snr": snr,
                "alpha": alpha,
                "pair": pair_idx,
                "group": group_idx,
                "sign": sign_idx,
                "draw": draw_idx,
                "arm": arm,
                "estimator": estimator,
                "tau": tau,
                "active": metrics["active"][j],
                "error": metrics["error"][j],
                "correlation": metrics["correlation"][j],
                "pass": metrics["passed"][j],
            }))
        frame_frames.extend(rows)


def bootstrap_cluster(values: np.ndarray, pairs: np.ndarray, seed: int, resamples: int = 2000) -> np.ndarray:
    rng = np.random.default_rng(seed)
    unique = np.unique(pairs)
    by_pair = np.asarray([np.mean(values[pairs == p]) for p in unique])
    sampled = rng.integers(0, len(unique), size=(resamples, len(unique)))
    return np.mean(by_pair[sampled], axis=1)


def scalar_batch_fixture(
    *,
    m,
    arrays,
    H,
    L,
    mode_coeff,
    nuisance_coeff,
    W1,
    sigma300,
    shape0,
    shape1,
    cond300,
    full_bases,
    selection,
    backgrounds,
    target_unit,
    directions,
    noise0,
    noise1,
) -> dict[str, float]:
    """One deterministic case evaluated both scalar and batched before full completion."""
    pair, draw, sign, alpha, snr = 0, 0, 1, PRIMARY_ALPHA, 300
    std0, std1 = sigma300 * shape0, sigma300 * shape1
    bg, h, w = backgrounds[:, pair], target_unit[:, pair], directions[pair]
    clean0 = arrays["base_q12_n0"] + arrays["A_q12_n0"] @ (bg + sign * alpha * h)
    clean1 = arrays["base_q12_n1"] + arrays["A_q12_n1"] @ (bg + sign * alpha * h)
    data0 = clean0 + std0 * noise0[:, pair, draw]
    data1 = clean1 + std1 * noise1[:, pair, draw]
    data = np.concatenate([data0, data1])
    base8 = np.concatenate([arrays["base_q8_n0"], arrays["base_q8_n1"]])
    y = (data - base8) / cond300["labelled"]["std"]
    ys = y - cond300["labelled"]["qn"] @ (cond300["labelled"]["qn"].T @ y)
    scalar_cond = cond300["labelled"]["pinv"] @ ys
    batch_y = y[:, None]
    batch_cond = cond300["labelled"]["pinv"] @ (batch_y - cond300["labelled"]["qn"] @ (cond300["labelled"]["qn"].T @ batch_y))

    diffs = {"conditional_max_abs": float(np.max(np.abs(scalar_cond - batch_cond[:, 0])))}
    for method in ("ridge", "tsvd"):
        setup = full_bases[("labelled", method)]
        scalar_x = solve_full_batched(setup, y[:, None], snr, method)[:, 0]
        scalar_c = m.x_to_coeff(scalar_x, L)
        scalar_a = project_modes(scalar_c, mode_coeff, H)
        batch_x = solve_full_batched(setup, y[:, None], snr, method)
        batch_c = m.x_to_coeff(batch_x, L)
        batch_a = mode_coeff.T @ H @ batch_c
        diffs[f"{method}_max_abs"] = float(np.max(np.abs(scalar_a - batch_a[:, 0])))

    true_a = (sign * alpha * w)[:, None]
    mf = m.eval_frames(mode_coeff)
    bm = mode_frame_metrics(mf, true_a, batch_cond, W1)
    sm = weighted_target_metrics(m.eval_frames(mode_coeff @ true_a[:, 0]), m.eval_frames(mode_coeff @ scalar_cond), W1)
    diffs["metric_error_max_abs"] = float(np.max(np.abs(bm["error"][:, 0] - sm["error"])))
    diffs["metric_corr_max_abs"] = float(np.max(np.abs(bm["correlation"][:, 0] - sm["correlation"])))
    diffs["metric_pass_equal"] = float(bm["history_pass"][0] == sm["history_pass"])
    if max(v for k, v in diffs.items() if k != "metric_pass_equal") > 1e-11 or diffs["metric_pass_equal"] != 1.0:
        raise AssertionError({"scalar_batch_fixture": diffs})
    return diffs


def main() -> None:
    if (RESULTS / "SUMMARY.json").exists():
        raise RuntimeError("Movie008 results already exist; use a fresh directory")
    start = time.perf_counter()
    arrays, support, selection, input_hashes = load_inputs()
    m = load_movie007_module()
    bank = np.load(RESULTS / "MODE_BANK.npz", allow_pickle=False)
    bank_info = json.loads((RESULTS / "MODE_BANK.json").read_text())
    mode_coeff = bank["mode_coefficients"]
    nuisance_indices = bank["nuisance_indices"]
    nuisance_coeff = np.eye(595)[:, nuisance_indices]
    H, L = arrays["H"], arrays["H_chol"]
    sigma300, shape0, shape1 = noise_calibration(arrays)

    def design(q: int, order: int):
        tuples = arrays[f"tuples_q{q}_n{order}"]
        weights = arrays[f"weights_q{q}_n{order}"]
        pixels = arrays[f"pixel_q{q}_n{order}"]
        return m.PhysicalDesign(q, order, np.zeros((len(tuples), 2)), pixels, weights, tuples, np.bincount(pixels, weights, minlength=64))

    W1 = m.support_weights([design(12, 1)])
    directions, direction_ledger = generate_directions(m, mode_coeff, W1)
    groups = np.repeat(np.array(["two_mode", "three_mode", "four_mode"]), 20)
    if len(directions) != PAIRS:
        raise AssertionError("Direction count mismatch")

    bg_rng = np.random.default_rng(80061)
    backgrounds_list = []
    background_records = []
    for pair in range(PAIRS):
        coeff, record = make_nuisance_background(bg_rng, nuisance_indices)
        record["pair"] = pair
        record["source_norm"] = source_norm(coeff, H)
        backgrounds_list.append(coeff)
        background_records.append(record)
    backgrounds = np.column_stack(backgrounds_list)
    target_unit = mode_coeff @ directions.T
    target_orth = float(np.linalg.norm(target_unit.T @ H @ target_unit - directions @ directions.T, ord=2))
    target_env = np.array([coefficient_envelope(target_unit[:, i]) for i in range(PAIRS)])
    background_env = np.array([x["certified_envelope"] for x in background_records])
    positivity_lower = {str(alpha): 1.0 - background_env - alpha * target_env for alpha in ALPHAS}
    if min(np.min(v) for v in positivity_lower.values()) < 0.5:
        raise AssertionError("Analytic positivity gate failed")

    direct8 = arrays["A_q8_n0"] @ target_unit
    direct12 = arrays["A_q12_n0"] @ target_unit
    order1_8 = arrays["A_q8_n1"] @ target_unit
    order1_12 = arrays["A_q12_n1"] @ target_unit
    if np.max(np.abs(direct8)) != 0.0 or np.max(np.abs(direct12)) != 0.0:
        raise AssertionError("Fresh target directions are not exactly direct-null")

    cond_by_snr = {}
    for snr in SNRS:
        factor = 300.0 / snr
        std0, std1 = sigma300 * factor * shape0, sigma300 * factor * shape1
        cond_by_snr[snr] = {
            arm: conditional_setup(arrays["A_q8_n0"], arrays["A_q8_n1"], std0, std1, nuisance_coeff, mode_coeff, arm)
            for arm in ("direct", "labelled")
        }
    full_bases = build_full_estimator_bases(m, arrays, selection, sigma300, shape0, shape1)
    mode_frames = m.eval_frames(mode_coeff)

    # Generate exactly the same standardized-noise streams as the scalar source.
    rng_noise = np.random.default_rng(80063)
    noise_by_snr = {}
    for snr in SNRS:
        noise_by_snr[snr] = (
            rng_noise.normal(size=(832, PAIRS, DRAWS)),
            rng_noise.normal(size=(832, PAIRS, DRAWS)),
        )

    fixture = scalar_batch_fixture(
        m=m, arrays=arrays, H=H, L=L, mode_coeff=mode_coeff, nuisance_coeff=nuisance_coeff,
        W1=W1, sigma300=sigma300, shape0=shape0, shape1=shape1,
        cond300=cond_by_snr[300], full_bases=full_bases, selection=selection,
        backgrounds=backgrounds, target_unit=target_unit, directions=directions,
        noise0=noise_by_snr[300][0], noise1=noise_by_snr[300][1],
    )

    pair_idx = np.repeat(np.arange(PAIRS), DRAWS * 2)
    draw_idx = np.tile(np.repeat(np.arange(DRAWS), 2), PAIRS)
    sign_idx = np.tile(SIGNS, PAIRS * DRAWS)
    group_idx = groups[pair_idx]
    ncase = len(pair_idx)
    if ncase != 480:
        raise AssertionError(ncase)

    record_frames: list[pd.DataFrame] = []
    frame_frames: list[pd.DataFrame] = []
    construction_rows: list[dict[str, Any]] = []
    oracle_frames: list[pd.DataFrame] = []
    estimate_arrays: dict[str, np.ndarray] = {
        "backgrounds": backgrounds,
        "directions": directions,
        "groups": groups,
        "target_unit_coefficients": target_unit,
        "mode_coefficients": mode_coeff,
        "case_pair": pair_idx,
        "case_sign": sign_idx,
        "case_draw": draw_idx,
    }
    standardized_noise: dict[str, np.ndarray] = {}
    max_paired_direct_diff = 0.0
    paired_direct_identical = True

    clean_bg0_pair = arrays["base_q12_n0"][:, None] + arrays["A_q12_n0"] @ backgrounds
    clean_bg1_pair = arrays["base_q12_n1"][:, None] + arrays["A_q12_n1"] @ backgrounds

    for snr in SNRS:
        factor = 300.0 / snr
        std0, std1 = sigma300 * factor * shape0, sigma300 * factor * shape1
        noise0, noise1 = noise_by_snr[snr]
        standardized_noise[f"z0_{snr}"] = noise0
        standardized_noise[f"z1_{snr}"] = noise1
        z0case = noise0[:, pair_idx, draw_idx]
        z1case = noise1[:, pair_idx, draw_idx]
        clean0case = clean_bg0_pair[:, pair_idx]
        data0 = clean0case + std0[:, None] * z0case
        # Adjacent plus/minus signs have the same pair/draw direct data.
        diff = np.max(np.abs(data0[:, 0::2] - data0[:, 1::2]))
        max_paired_direct_diff = max(max_paired_direct_diff, float(diff))
        paired_direct_identical &= np.array_equal(data0[:, 0::2], data0[:, 1::2])

        for alpha in ALPHAS:
            true_a = directions[pair_idx].T * (sign_idx * alpha)[None, :]
            target1case = order1_12[:, pair_idx] * (sign_idx * alpha)[None, :]
            clean1case = clean_bg1_pair[:, pair_idx] + target1case
            data1 = clean1case + std1[:, None] * z1case

            # Construction gates, once per pair/condition.
            for pair in range(PAIRS):
                y8diff = 2 * alpha * order1_8[:, pair]
                y12diff = 2 * alpha * order1_12[:, pair]
                construction_rows.append({
                    "snr": snr,
                    "alpha": alpha,
                    "pair": pair,
                    "group": groups[pair],
                    "direct_q8_max_abs": float(np.max(np.abs(2 * alpha * direct8[:, pair]))),
                    "direct_q12_max_abs": float(np.max(np.abs(2 * alpha * direct12[:, pair]))),
                    "labelled_q12_twin_whitened_separation": float(np.linalg.norm(y12diff / std1)),
                    "q8_q12_twin_relative": float(np.linalg.norm(y8diff - y12diff) / max(np.linalg.norm(y12diff), 1e-15)),
                    "q8_q12_twin_whitened": float(np.linalg.norm((y8diff - y12diff) / std1)),
                    "minimum_emissivity_bound": float(positivity_lower[str(alpha)][pair]),
                })

            # Pair-likelihood upper bound diagnostic.
            plus1 = clean_bg1_pair[:, pair_idx] + alpha * order1_12[:, pair_idx]
            minus1 = clean_bg1_pair[:, pair_idx] - alpha * order1_12[:, pair_idx]
            labelled_data = np.vstack([data0, data1])
            plus_clean = np.vstack([clean0case, plus1])
            minus_clean = np.vstack([clean0case, minus1])
            std_label = np.concatenate([std0, std1])[:, None]
            dplus = np.sum(((labelled_data - plus_clean) / std_label) ** 2, axis=0)
            dminus = np.sum(((labelled_data - minus_clean) / std_label) ** 2, axis=0)
            oracle_sign = np.where(dplus <= dminus, 1, -1)
            oracle_frames.append(pd.DataFrame({
                "snr": snr,
                "alpha": alpha,
                "pair": pair_idx,
                "group": group_idx,
                "sign": sign_idx,
                "draw": draw_idx,
                "labelled_pair_likelihood_identity_correct": (oracle_sign == sign_idx).astype(np.int64),
                "labelled_pair_likelihood_delta_chi2": dminus - dplus,
                "direct_pair_likelihood_delta_chi2": np.zeros(ncase),
            }))

            for arm in ("direct", "labelled"):
                if arm == "direct":
                    data = data0
                    base8 = arrays["base_q8_n0"]
                    a_cond = np.zeros((MODE_COUNT, ncase))
                else:
                    data = np.vstack([data0, data1])
                    base8 = np.concatenate([arrays["base_q8_n0"], arrays["base_q8_n1"]])
                    y = (data - base8[:, None]) / cond_by_snr[snr][arm]["std"][:, None]
                    qn = cond_by_snr[snr][arm]["qn"]
                    yperp = y - qn @ (qn.T @ y)
                    a_cond = cond_by_snr[snr][arm]["pinv"] @ yperp
                metrics = mode_frame_metrics(mode_frames, true_a, a_cond, W1)
                add_records(record_frames, frame_frames, snr=snr, alpha=alpha, arm=arm,
                            estimator="conditional_gls", pair_idx=pair_idx, sign_idx=sign_idx,
                            draw_idx=draw_idx, group_idx=group_idx, true_a=true_a,
                            pred_a=a_cond, metrics=metrics, save_frames=True)
                estimate_arrays[f"conditional_gls_snr{snr}_a{alpha}_{arm}"] = a_cond

                for method in ("ridge", "tsvd"):
                    setup = full_bases[(arm, method)]
                    yfull = (data - base8[:, None]) / (setup["std300"][:, None] * (300.0 / snr))
                    xhat = solve_full_batched(setup, yfull, snr, method)
                    chat = m.x_to_coeff(xhat, L)
                    a_full = mode_coeff.T @ H @ chat
                    metrics_full = mode_frame_metrics(mode_frames, true_a, a_full, W1)
                    add_records(record_frames, frame_frames, snr=snr, alpha=alpha, arm=arm,
                                estimator=method, pair_idx=pair_idx, sign_idx=sign_idx,
                                draw_idx=draw_idx, group_idx=group_idx, true_a=true_a,
                                pred_a=a_full, metrics=metrics_full, save_frames=False)
                    estimate_arrays[f"{method}_snr{snr}_a{alpha}_{arm}"] = a_full

    df = pd.concat(record_frames, ignore_index=True)
    frames_df = pd.concat(frame_frames, ignore_index=True)
    construction = pd.DataFrame(construction_rows)
    oracle_df = pd.concat(oracle_frames, ignore_index=True)

    # Aggregate endpoints.
    aggregate = []
    for (snr, alpha, arm, estimator), g in df.groupby(["snr", "alpha", "arm", "estimator"], sort=True):
        aggregate.append({
            "snr": int(snr), "alpha": float(alpha), "arm": arm, "estimator": estimator,
            "identity_accuracy": float(g.identity_correct.mean()),
            "median_target_relative_error": float(g.target_relative_error.median()),
            "p90_target_relative_error": float(g.target_relative_error.quantile(0.90)),
            "movie_pass_rate": float(g.movie_pass.mean()),
            "median_active_frame_error": float(g.mean_active_frame_error.median()),
            "median_minimum_active_correlation": float(g.minimum_active_correlation.median()),
        })
    family = []
    for (snr, alpha, arm, estimator, group), g in df.groupby(["snr", "alpha", "arm", "estimator", "group"], sort=True):
        family.append({
            "snr": int(snr), "alpha": float(alpha), "arm": arm, "estimator": estimator, "group": group,
            "identity_accuracy": float(g.identity_correct.mean()),
            "median_target_relative_error": float(g.target_relative_error.median()),
            "movie_pass_rate": float(g.movie_pass.mean()),
            "cases": len(g),
        })
    agg = pd.DataFrame(aggregate)
    fam = pd.DataFrame(family)

    primary = df[(df.snr == 300) & np.isclose(df.alpha, PRIMARY_ALPHA) & (df.estimator == "conditional_gls")]
    pdirect = primary[primary.arm == "direct"].sort_values(["pair", "draw", "sign"])
    plabel = primary[primary.arm == "labelled"].sort_values(["pair", "draw", "sign"])
    bacc = bootstrap_cluster(plabel.identity_correct.to_numpy(), plabel.pair.to_numpy(), 80064)
    bmovie = bootstrap_cluster(plabel.movie_pass.to_numpy(dtype=float), plabel.pair.to_numpy(), 80065)
    primary_construction = construction[(construction.snr == 300) & np.isclose(construction.alpha, PRIMARY_ALPHA)]
    minsep = float(primary_construction.labelled_q12_twin_whitened_separation.min())
    maxrel = float(construction.q8_q12_twin_relative.max())
    maxwhite = float(construction.q8_q12_twin_whitened.max())
    primary_oracle = oracle_df[(oracle_df.snr == 300) & np.isclose(oracle_df.alpha, PRIMARY_ALPHA)]

    checks = {
        "authenticated_inputs": True,
        "mode_bank_checks": all(bank_info["checks"].values()),
        "scalar_batch_equivalence": max(v for k, v in fixture.items() if k != "metric_pass_equal") <= 1e-11 and fixture["metric_pass_equal"] == 1.0,
        "fresh_direction_count_60": len(directions) == 60,
        "all_directions_active_at_least_8": all(x["active_frames"] >= 8 for x in direction_ledger if x["accepted"]),
        "analytic_positivity_minimum_at_least_0p5": min(np.min(v) for v in positivity_lower.values()) >= 0.5,
        "direct_q8_exact_null": float(np.max(np.abs(direct8))) == 0.0,
        "direct_q12_exact_null": float(np.max(np.abs(direct12))) == 0.0,
        "paired_direct_observations_identical": bool(paired_direct_identical and max_paired_direct_diff == 0.0),
        "primary_labelled_twin_separation_min5": minsep >= 5.0,
        "q8_q12_twin_relative": maxrel <= 5e-4,
        "q8_q12_twin_whitened": maxwhite <= 0.1,
        "primary_direct_accuracy_exact_half": float(pdirect.identity_correct.mean()) == 0.5,
        "primary_labelled_accuracy_at_least_0p95": float(plabel.identity_correct.mean()) >= 0.95,
        "primary_labelled_median_error_at_most_0p35": float(plabel.target_relative_error.median()) <= 0.35,
        "primary_labelled_p90_error_at_most_0p60": float(plabel.target_relative_error.quantile(0.90)) <= 0.60,
        "primary_labelled_movie_pass_at_least_0p95": float(plabel.movie_pass.mean()) >= 0.95,
        "each_group_accuracy_at_least_0p90": bool((plabel.groupby("group").identity_correct.mean() >= 0.90).all()),
        "no_new_physical_calls": True,
        "paper1_units_used_zero": True,
    }
    status = "MOVIE008_DIRECT_NULL_TWIN_MOVIE_PASS" if all(checks.values()) else "MOVIE008_DIRECT_NULL_TWIN_MOVIE_FAIL"
    summary = {
        "experiment": "Mahakal II Movie008 direct-null twin movie recovery",
        "status": status,
        "checks": checks,
        "execution": {
            "implementation": "batched algebraic successor after recorded scalar timeout",
            "scalar_batch_fixture": fixture,
            "source_seed_backgrounds": 80061,
            "source_seed_directions": 80062,
            "noise_seed": 80063,
        },
        "primary": {
            "snr": 300,
            "alpha": PRIMARY_ALPHA,
            "estimator": "conditional_gls",
            "direct_identity_accuracy": float(pdirect.identity_correct.mean()),
            "labelled_identity_accuracy": float(plabel.identity_correct.mean()),
            "labelled_median_target_relative_error": float(plabel.target_relative_error.median()),
            "labelled_p90_target_relative_error": float(plabel.target_relative_error.quantile(0.90)),
            "labelled_movie_pass_rate": float(plabel.movie_pass.mean()),
            "minimum_q12_twin_whitened_separation": minsep,
            "labelled_pair_likelihood_selector_accuracy": float(primary_oracle.labelled_pair_likelihood_identity_correct.mean()),
            "direct_pair_likelihood_is_exact_tie": bool((oracle_df.direct_pair_likelihood_delta_chi2 == 0.0).all()),
            "bootstrap_identity_accuracy_median_p2p5_p97p5": [float(np.median(bacc)), float(np.percentile(bacc, 2.5)), float(np.percentile(bacc, 97.5))],
            "bootstrap_movie_pass_median_p2p5_p97p5": [float(np.median(bmovie)), float(np.percentile(bmovie, 2.5)), float(np.percentile(bmovie, 97.5))],
        },
        "aggregate": aggregate,
        "group_results": family,
        "construction": {
            "target_parent_dimension": 210,
            "nuisance_dimension": 385,
            "frozen_modes": 4,
            "pairs": PAIRS,
            "signs": 2,
            "draws": DRAWS,
            "primary_cases_per_arm": len(plabel),
            "target_direction_gram_error": target_orth,
            "minimum_analytic_emissivity_bound": float(min(np.min(v) for v in positivity_lower.values())),
            "max_q8_q12_twin_relative": maxrel,
            "max_q8_q12_twin_whitened": maxwhite,
            "paired_noisy_direct_max_abs_difference": max_paired_direct_diff,
        },
        "input_hashes": input_hashes,
        "paper1_units_used": 0,
        "new_physical_calls": 0,
        "scope": [
            "one Movie007 Kerr chart with ideal order labels",
            "four-mode old nonaxisymmetric target under a 385-dimensional declared nuisance model",
            "order1-only measured-support movie metric",
            "not arbitrary nuisance, off-basis, full-annulus, visibility-domain, or telescope movie recovery",
        ],
        "seconds": time.perf_counter() - start,
    }

    # Write only after the entire computation and all endpoint checks exist.
    df.to_csv(RESULTS / "PER_RECONSTRUCTION.csv", index=False)
    frames_df.to_csv(RESULTS / "PER_FRAME.csv", index=False)
    construction.to_csv(RESULTS / "TWIN_CONSTRUCTION_GATES.csv", index=False)
    oracle_df.to_csv(RESULTS / "PAIR_LIKELIHOOD_DIAGNOSTIC.csv", index=False)
    agg.to_csv(RESULTS / "AGGREGATE.csv", index=False)
    fam.to_csv(RESULTS / "GROUP_RESULTS.csv", index=False)
    np.savez_compressed(RESULTS / "TWIN_SOURCES_AND_ESTIMATES.npz", **estimate_arrays)
    np.savez_compressed(RESULTS / "STANDARDIZED_NOISE.npz", **standardized_noise)
    dump(RESULTS / "DIRECTION_CANDIDATE_LEDGER.json", direction_ledger)
    dump(RESULTS / "BACKGROUND_RECORDS.json", background_records)
    dump(RESULTS / "PAIRED_DIRECT_OBSERVATION_CHECK.json", {
        "byte_identical": bool(paired_direct_identical),
        "max_abs_difference": max_paired_direct_diff,
        "scope": "Same q12 direct clean signal and same standardized direct noise within each balanced twin pair.",
    })
    dump(RESULTS / "BATCH_EQUIVALENCE.json", fixture)
    dump(RESULTS / "SUMMARY.json", summary)
    dump(ROOT / "SUMMARY.json", summary)
    print(status)
    print(agg.to_string(index=False))


if __name__ == "__main__":
    main()
