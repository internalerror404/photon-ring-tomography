"""Independent batched-output readback and report for Movie008.

No source generation, estimator fitting, physical ray evaluation, or threshold
selection occurs here.  It recomputes the primary statistics from saved dense
estimate arrays and verifies the compact tables against those arrays.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np
import pandas as pd

from common import ROOT, RESULTS, dump, load_inputs, load_movie007_module, project_modes, sha256, weighted_target_metrics


def locate_case(payload, pair: int, sign: int, draw: int) -> int:
    mask = (
        (payload["case_pair"] == pair)
        & (payload["case_sign"] == sign)
        & (payload["case_draw"] == draw)
    )
    idx = np.flatnonzero(mask)
    if len(idx) != 1:
        raise AssertionError({"pair": pair, "sign": sign, "draw": draw, "matches": len(idx)})
    return int(idx[0])


def main() -> None:
    start = time.perf_counter()
    arrays, _support, _selection, input_hashes = load_inputs()
    m = load_movie007_module()
    summary = json.loads((RESULTS / "SUMMARY.json").read_text())
    df = pd.read_csv(RESULTS / "PER_RECONSTRUCTION.csv")
    frames = pd.read_csv(RESULTS / "PER_FRAME.csv")
    construction = pd.read_csv(RESULTS / "TWIN_CONSTRUCTION_GATES.csv")
    bank = np.load(RESULTS / "MODE_BANK.npz", allow_pickle=False)
    payload = np.load(RESULTS / "TWIN_SOURCES_AND_ESTIMATES.npz", allow_pickle=False)
    modes = bank["mode_coefficients"]
    H = arrays["H"]

    mode_orth = float(np.linalg.norm(modes.T @ H @ modes - np.eye(4), ord=2))
    direct8 = arrays["A_q8_n0"] @ payload["target_unit_coefficients"]
    direct12 = arrays["A_q12_n0"] @ payload["target_unit_coefficients"]

    projection_errors = []
    metric_errors = []
    a_label = payload["conditional_gls_snr300_a0.08_labelled"]
    a_direct = payload["conditional_gls_snr300_a0.08_direct"]
    directions = payload["directions"]
    W1 = m.support_weights([
        m.PhysicalDesign(
            12,
            1,
            np.zeros((len(arrays["tuples_q12_n1"]), 2)),
            arrays["pixel_q12_n1"],
            arrays["weights_q12_n1"],
            arrays["tuples_q12_n1"],
            np.bincount(arrays["pixel_q12_n1"], arrays["weights_q12_n1"], minlength=64),
        )
    ])
    for pair in (0, 19, 20, 39, 40, 59):
        for sign in (1, -1):
            idx = locate_case(payload, pair, sign, 0)
            a = a_label[:, idx]
            c = modes @ a
            back = project_modes(c, modes, H)
            projection_errors.append(float(np.max(np.abs(a - back))))
            true_a = sign * 0.08 * directions[pair]
            true_frames = m.eval_frames(modes @ true_a)
            pred_frames = m.eval_frames(c)
            scalar_metric = weighted_target_metrics(true_frames, pred_frames, W1)
            table_row = df[
                (df.snr == 300)
                & np.isclose(df.alpha, 0.08)
                & (df.pair == pair)
                & (df.sign == sign)
                & (df.draw == 0)
                & (df.arm == "labelled")
                & (df.estimator == "conditional_gls")
            ]
            if len(table_row) != 1:
                raise AssertionError("Missing primary table row")
            r = table_row.iloc[0]
            metric_errors.extend([
                abs(float(r.mean_active_frame_error) - scalar_metric["mean_active_error"]),
                abs(float(r.minimum_active_correlation) - scalar_metric["minimum_active_correlation"]),
                float(bool(r.movie_pass) != bool(scalar_metric["history_pass"])),
            ])

    primary = df[(df.snr == 300) & np.isclose(df.alpha, 0.08) & (df.estimator == "conditional_gls")]
    direct = primary[primary.arm == "direct"].sort_values(["pair", "draw", "sign"])
    labelled = primary[primary.arm == "labelled"].sort_values(["pair", "draw", "sign"])

    # Recompute identity and relative-error arrays directly from saved estimates.
    pair = payload["case_pair"].astype(int)
    sign = payload["case_sign"].astype(int)
    unsigned = directions[pair].T
    pred_sign = np.where(np.sum(a_label * unsigned, axis=0) >= 0, 1, -1)
    identity = pred_sign == sign
    true_a = unsigned * (sign * 0.08)[None, :]
    relerr = np.linalg.norm(a_label - true_a, axis=0) / 0.08

    aggregate = pd.read_csv(RESULTS / "AGGREGATE.csv")
    primary_agg = aggregate[
        (aggregate.snr == 300)
        & np.isclose(aggregate.alpha, 0.08)
        & (aggregate.arm == "labelled")
        & (aggregate.estimator == "conditional_gls")
    ]
    if len(primary_agg) != 1:
        raise AssertionError("Primary aggregate row missing")
    primary_agg = primary_agg.iloc[0]

    direct_pair_equal = True
    for p in range(60):
        for d in range(4):
            ip = locate_case(payload, p, 1, d)
            im = locate_case(payload, p, -1, d)
            direct_pair_equal &= np.array_equal(a_direct[:, ip], a_direct[:, im])

    source_hashes = {p.name: sha256(p) for p in sorted((ROOT / "source").glob("*.py"))}
    checks = {
        "summary_status_matches_checks": (summary["status"].endswith("PASS")) == all(summary["checks"].values()),
        "input_hashes_match": input_hashes == summary["input_hashes"],
        "mode_source_orthonormality": mode_orth <= 1e-10,
        "fresh_target_direct_q8_exact_zero": float(np.max(np.abs(direct8))) == 0.0,
        "fresh_target_direct_q12_exact_zero": float(np.max(np.abs(direct12))) == 0.0,
        "direct_estimates_identical_within_pairs": direct_pair_equal,
        "direct_estimates_all_zero": np.array_equal(a_direct, np.zeros_like(a_direct)),
        "mode_projection_roundtrip": max(projection_errors) <= 1e-12,
        "saved_metric_readback": max(metric_errors) <= 1e-10,
        "all_numeric_tables_finite": all(np.isfinite(x.select_dtypes(include=[np.number]).to_numpy()).all() for x in (df, frames, construction, aggregate)),
        "primary_case_count_480_per_arm": len(direct) == 480 and len(labelled) == 480,
        "primary_identity_recomputed": abs(float(identity.mean()) - summary["primary"]["labelled_identity_accuracy"]) <= 1e-15,
        "primary_median_error_recomputed": abs(float(np.median(relerr)) - summary["primary"]["labelled_median_target_relative_error"]) <= 1e-12,
        "primary_p90_error_recomputed": abs(float(np.quantile(relerr, 0.90)) - summary["primary"]["labelled_p90_target_relative_error"]) <= 1e-12,
        "aggregate_identity_matches": abs(float(primary_agg.identity_accuracy) - float(identity.mean())) <= 1e-15,
        "aggregate_median_error_matches": abs(float(primary_agg.median_target_relative_error) - float(np.median(relerr))) <= 1e-12,
        "no_physical_attempt_ledger_created": not (ROOT / "attempts" / "physical_calls.jsonl").exists(),
    }
    if not all(checks.values()):
        raise AssertionError(checks)

    p = summary["primary"]
    groups = pd.read_csv(RESULTS / "GROUP_RESULTS.csv")
    report = f"""# Mahakal II Movie008 — direct-null twin-movie recovery

## Outcome

**{summary['status']}**

Movie008 isolates the causal question left open by Movie007's union-support comparison: can the first indirect image recover which old spatial movie occurred when the direct observations are exactly identical?

The frozen target is a four-dimensional subspace selected from a 210-dimensional old, non-axisymmetric parent after profiling a declared 385-dimensional nuisance movie. Both q8 and q12 direct target matrices are exactly zero. The first-indirect response is strong and stable across the two integration rules.

## Primary result

At SNR0=300 and target source norm alpha=0.08:

- direct-only twin identity accuracy: **{100*p['direct_identity_accuracy']:.2f}%**;
- direct+order1 twin identity accuracy: **{100*p['labelled_identity_accuracy']:.2f}%**;
- labelled median four-coefficient relative error: **{p['labelled_median_target_relative_error']:.4f}**;
- labelled 90th-percentile target error: **{p['labelled_p90_target_relative_error']:.4f}**;
- labelled all-active-frame movie pass rate: **{100*p['labelled_movie_pass_rate']:.2f}%**;
- minimum q12 whitened separation between twin movies: **{p['minimum_q12_twin_whitened_separation']:.3f}**.

The direct result is exactly 50% because every pair contains both signs, receives byte-identical direct observations, and the registered direct target estimate is the same zero vector for both. This is an information limit, not a failed optimizer. The labelled estimator uses the first-indirect rows and estimates four unknown movie coefficients after removing the declared nuisance response.

Pair-cluster bootstrap identity accuracy (median, 2.5%, 97.5%): `{p['bootstrap_identity_accuracy_median_p2p5_p97p5']}`. Movie-pass rate: `{p['bootstrap_movie_pass_median_p2p5_p97p5']}`.

## Aggregate estimator results

{aggregate.to_markdown(index=False)}

## Complexity-group results

{groups.to_markdown(index=False)}

## Numerical and provenance checks

- source-orthonormality error: `{mode_orth:.3e}`;
- fresh q8/q12 direct maxima: exactly `0.0`;
- maximum q8/q12 twin response discrepancy: `{summary['construction']['max_q8_q12_twin_relative']:.3e}` relative and `{summary['construction']['max_q8_q12_twin_whitened']:.3e}` whitened;
- analytic minimum emissivity bound: `{summary['construction']['minimum_analytic_emissivity_bound']:.4f}`;
- scalar/batch equivalence: `{summary['execution']['scalar_batch_fixture']}`;
- independent readback checks: all pass;
- new physical calls: **0**; Paper I units used: **0**.

## Interpretation and limits

A positive result supports the bounded statement: **the first indirect Kerr image selects and reconstructs the correct old finite-model movie among direct-indistinguishable positive twins after the declared nuisance movie is profiled out.** This is stronger causal evidence than a lower average error on a union support.

It does not establish blind recovery of arbitrary old emission. The four target modes were chosen for conditional order1 response; the nuisance model excludes other old non-axisymmetric directions; the geometry is one Kerr chart; image-order labels are ideal; and no interferometric/telescope acquisition is modeled. Movie007's off-basis and full-annulus negatives remain standing.
"""
    (ROOT / "REPORT.md").write_text(report)
    dump(RESULTS / "VERIFICATION.json", {
        "checks": checks,
        "all_checks_pass": all(checks.values()),
        "mode_source_orthonormality_error": mode_orth,
        "fresh_direct_q8_max_abs": float(np.max(np.abs(direct8))),
        "fresh_direct_q12_max_abs": float(np.max(np.abs(direct12))),
        "mode_projection_roundtrip_max_abs": max(projection_errors),
        "saved_metric_readback_max_abs": max(metric_errors),
        "source_hashes": source_hashes,
        "seconds": time.perf_counter() - start,
    })
    print(report)


if __name__ == "__main__":
    main()
