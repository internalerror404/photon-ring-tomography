from __future__ import annotations

"""Movie009-R2: background-conditioned historical-innovation reconstruction.

This is the complete implementation corresponding to REGISTRATION.md on
research/mahakal_II_movie009_r2_factorized_20260911.  It uses only authenticated
Movie007 cached Kerr arrays.  No ray tracer or physical integration routine is
called.
"""

import argparse
import hashlib
import importlib.util
import json
import math
import os
import sys
import time
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")

import numpy as np
import pandas as pd
from scipy import linalg
from sklearn.decomposition import PCA
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "source"
INP = ROOT / "inputs"
RES = ROOT / "results"
LOG = ROOT / "logs"
FIG = ROOT / "figures"
for p in (RES, LOG, FIG):
    p.mkdir(parents=True, exist_ok=True)

INPUT_HASHES = {
    "PHYSICAL_AND_OPERATOR_ARRAYS.npz": "54204f14b8c834fb3c54dc012c9827e711f339fc6c30251802fea71ac6d8274e",
    "SUPPORT_WEIGHTS.npz": "72080e09e722b01a821d2989d706f21eccfc9ce7671d1fa2f18f66bcd56a7952",
    "REGULARIZATION_SELECTION.json": "f3739497a08973bec6ed0b5c174188ad1b2321b469efa06750de2b43bcddf090",
    "movie007_run.py": "8b80d533cd48400570e505423053a6557e4a2ea6f3d82367adfd5c88b34e5cf1",
    "kerr.py": "12abafb39f6d5a6ebf4626e0a05c021d3bd0c5c5ca6ae0abd22632656c8f28cf",
}

# Registered populations/seeds.
TRAIN_PAIRS_PER_FAMILY = 180
VAL_PAIRS_PER_FAMILY = 8
TEST_PAIRS_PER_FAMILY = 16
TRAIN_FAMILIES = ("narrow_hotspot", "shearing_spiral", "split_merge")
TEST_FAMILIES = (*TRAIN_FAMILIES, "radial_plume")
BACKGROUND_FAMILIES = ("single_hotspot", "double_hotspot", "flare_drift")
SEEDS = {
    "training_sources": 190050,
    "validation_sources": 190061,
    "test_sources": 190062,
    "training_noise": 190063,
    "validation_noise": 190064,
    "test_noise": 190065,
    "bootstrap": 190066,
    "source_pca": 190090,
}
SNR_LEVELS = (300, 100)
MOVIE_TIMES = -2.0 * np.arange(15)
R_EVAL = np.linspace(6.0, 13.0, 32)
P_EVAL = np.linspace(-np.pi, np.pi, 64, endpoint=False)
R_LAT = np.linspace(6.0, 13.0, 15)
P_LAT = np.linspace(-np.pi, np.pi, 48, endpoint=False)
T_LAT = np.linspace(-32.0, 28.0, 25)
LAT_SHAPE = (len(T_LAT), len(R_LAT), len(P_LAT))
LAT_SIZE = int(np.prod(LAT_SHAPE))
SOURCE_PCA_RANK = 96
OBS_PCA_RANK = 128
BG_EXPONENTS = np.arange(-6, 4)
LAT_EXPONENTS = np.arange(-8, 3)
TRUST_EXPONENTS = np.array([-4, -2, 0, 2, 4], dtype=int)
NDRAW_VAL = 2
NDRAW_TEST = 4


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path: Path, value: Any) -> None:
    def default(x: Any) -> Any:
        if isinstance(x, np.ndarray):
            return x.tolist()
        if isinstance(x, np.generic):
            return x.item()
        raise TypeError(type(x).__name__)

    path.write_text(json.dumps(value, indent=2, allow_nan=False, default=default) + "\n")


def load_m7():
    p = SRC / "movie007_run.py"
    spec = importlib.util.spec_from_file_location("movie007_r2", p)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot import Movie007 source")
    mod = importlib.util.module_from_spec(spec)
    sys.path.insert(0, str(SRC))
    spec.loader.exec_module(mod)
    return mod


def authenticate() -> dict[str, str]:
    found: dict[str, str] = {}
    for name, expected in INPUT_HASHES.items():
        path = (SRC / name) if name.endswith(".py") else (INP / name)
        if not path.exists():
            raise FileNotFoundError(path)
        found[name] = sha(path)
        if found[name] != expected:
            raise RuntimeError(f"hash mismatch for {name}: {found[name]} != {expected}")
    return found


def wrap(x: np.ndarray) -> np.ndarray:
    return (np.asarray(x) + np.pi) % (2 * np.pi) - np.pi


def smoothstep5(x: np.ndarray) -> np.ndarray:
    y = np.clip(np.asarray(x, dtype=float), 0.0, 1.0)
    return y**3 * (10.0 - 15.0 * y + 6.0 * y**2)


def old_window(tau: np.ndarray) -> np.ndarray:
    """Compact C2 plateau: zero >=-6 or <=-31; one on [-29,-10]."""
    tau = np.asarray(tau, dtype=float)
    return smoothstep5((tau + 31.0) / 2.0) * smoothstep5((-tau - 6.0) / 4.0)


def background_scene(family: str, pars: dict[str, float], r: np.ndarray, p: np.ndarray, t: np.ndarray) -> np.ndarray:
    phase = pars["phase"] + pars["speed"] * t
    if family == "single_hotspot":
        radial = np.exp(-0.5 * ((r - pars["r0"]) / pars["rw"]) ** 2)
        return pars["amp"] * radial * np.exp(pars["kappa"] * (np.cos(p - phase) - 1.0))
    if family == "double_hotspot":
        radial1 = np.exp(-0.5 * ((r - pars["r0"]) / pars["rw"]) ** 2)
        radial2 = np.exp(-0.5 * ((r - pars["r1"]) / pars["rw1"]) ** 2)
        h1 = radial1 * np.exp(pars["kappa"] * (np.cos(p - phase) - 1.0))
        h2 = radial2 * np.exp(pars["kappa1"] * (np.cos(p - phase - pars["offset"]) - 1.0))
        return pars["amp"] * (h1 + pars["ratio"] * h2) / (1.0 + pars["ratio"])
    if family == "flare_drift":
        env = 0.32 + 0.68 * np.exp(-0.5 * ((t + 8.0) / pars["st"]) ** 2)
        rc = pars["r0"] + pars["drdt"] * (t + 14.0)
        return pars["amp"] * env * np.exp(
            -0.5 * ((r - rc) / pars["rw"]) ** 2
            + pars["kappa"] * (np.cos(p - phase) - 1.0)
        )
    raise KeyError(family)


def draw_background(family: str, rng: np.random.Generator) -> dict[str, float]:
    base = {
        "phase": float(rng.uniform(-np.pi, np.pi)),
        "speed": float(rng.uniform(0.035, 0.09)),
        "r0": float(rng.uniform(7.5, 11.2)),
        "rw": float(rng.uniform(0.8, 1.4)),
        "kappa": float(rng.uniform(1.4, 2.8)),
        "amp": float(rng.uniform(0.12, 0.24)),
    }
    if family == "double_hotspot":
        base.update(
            r1=float(rng.uniform(8.8, 12.2)),
            rw1=float(rng.uniform(0.8, 1.4)),
            kappa1=float(rng.uniform(1.2, 2.6)),
            offset=float(rng.uniform(1.5, 3.5)),
            ratio=float(rng.uniform(0.55, 0.9)),
        )
    elif family == "flare_drift":
        base.update(st=float(rng.uniform(8.0, 12.0)), drdt=float(rng.uniform(-0.04, 0.04)))
    return base


def draw_feature_pair(family: str, rng: np.random.Generator) -> dict[str, float]:
    p = {
        "phase": float(rng.uniform(-np.pi, np.pi)),
        "amp": float(rng.uniform(0.35, 0.55)),
        "r0": float(rng.uniform(7.3, 11.7)),
        "rw": float(rng.uniform(0.30, 0.60)),
        "kappa": float(rng.uniform(9.0, 15.0)),
        "speed": float(rng.uniform(0.05, 0.16)),
        "dr": float(rng.uniform(0.25, 0.70)),
        "bend": float(rng.uniform(0.15, 0.50)),
        "delta": float(rng.uniform(0.65, 1.35)),
        "shear": float(rng.uniform(0.35, 0.80)),
        "sep": float(rng.uniform(0.50, 1.10)),
    }
    return p


def feature_movie(family: str, pars: dict[str, float], sibling: int, r: np.ndarray, p: np.ndarray, t: np.ndarray) -> np.ndarray:
    """Positive old feature. sibling is -1 or +1 and selects a natural alternative."""
    s = float(sibling)
    win = old_window(t)
    amp = pars["amp"]
    phase0 = pars["phase"] + pars["speed"] * (t + 18.0)
    if family == "narrow_hotspot":
        rc = pars["r0"] + 0.18 * pars["dr"] * np.sin(0.12 * (t + 18.0))
        pc = phase0 + s * 0.5 * pars["delta"]
        return amp * win * np.exp(-0.5 * ((r - rc) / pars["rw"]) ** 2 + pars["kappa"] * (np.cos(p - pc) - 1.0))
    if family == "shearing_spiral":
        pc = phase0 + s * pars["shear"] * (r - pars["r0"])
        return amp * win * np.exp(-0.5 * ((r - pars["r0"]) / pars["rw"]) ** 2 + pars["kappa"] * (np.cos(p - pc) - 1.0))
    if family == "split_merge":
        sep = pars["sep"] * (0.5 + 0.5 * np.cos(np.pi * (t + 18.0) / 12.0))
        axis = phase0 + (0.0 if sibling < 0 else 0.5 * np.pi)
        h1 = np.exp(-0.5 * ((r - pars["r0"]) / pars["rw"]) ** 2 + pars["kappa"] * (np.cos(p - axis - sep) - 1.0))
        h2 = np.exp(-0.5 * ((r - pars["r0"]) / pars["rw"]) ** 2 + pars["kappa"] * (np.cos(p - axis + sep) - 1.0))
        return amp * win * 0.5 * (h1 + h2)
    if family == "radial_plume":
        rc = pars["r0"] + s * pars["dr"] * np.tanh((t + 18.0) / 6.0)
        pc = phase0 + s * pars["bend"] * (r - rc)
        width = pars["rw"] * (1.0 + 0.25 * np.sin(0.12 * (t + 18.0)))
        return amp * win * np.exp(-0.5 * ((r - rc) / width) ** 2 + pars["kappa"] * (np.cos(p - pc) - 1.0))
    raise KeyError(family)


@dataclass
class PairRecord:
    split: str
    family: str
    index: int
    background_family: str
    background_params: dict[str, float]
    feature_params: dict[str, float]
    c_background: np.ndarray
    background_frames: np.ndarray


def load_support() -> tuple[np.ndarray, np.ndarray]:
    z = np.load(INP / "SUPPORT_WEIGHTS.npz", allow_pickle=False)
    if "support" not in z.files or "full_annulus" not in z.files:
        raise RuntimeError(f"unexpected support keys {z.files}")
    return np.asarray(z["support"], float), np.asarray(z["full_annulus"], float)


def make_background(m7, grams, family: str, pars: dict[str, float]) -> tuple[np.ndarray, np.ndarray]:
    fn = lambda r, p, t: background_scene(family, pars, r, p, t)
    c = np.asarray(m7.project_analytic(fn, grams), float)
    frames = np.asarray(m7.eval_frames(c), float)
    min_j = float(np.min(1.0 + frames))
    if min_j < 0.15:
        scale = min(1.0, 0.82 / max(1.0 - min_j, 1e-12))
        c *= scale
        frames = np.asarray(m7.eval_frames(c), float)
    if not np.isfinite(c).all() or np.min(1.0 + frames) < 0.0:
        raise RuntimeError("background projection failed positivity")
    return c, frames


def feature_on_eval(family: str, pars: dict[str, float], sibling: int) -> np.ndarray:
    return feature_movie(
        family,
        pars,
        sibling,
        R_EVAL[None, :, None],
        P_EVAL[None, None, :],
        MOVIE_TIMES[:, None, None],
    )


def feature_on_latent_grid(family: str, pars: dict[str, float], sibling: int) -> np.ndarray:
    return feature_movie(
        family,
        pars,
        sibling,
        R_LAT[None, :, None],
        P_LAT[None, None, :],
        T_LAT[:, None, None],
    )


def source_activity(feature_frames: np.ndarray, W: np.ndarray) -> np.ndarray:
    return np.sqrt(np.sum(W * feature_frames**2, axis=(1, 2)))


def generate_pairs(m7, W: np.ndarray, split: str, families: Iterable[str], count: int, seed: int, grams) -> tuple[list[PairRecord], list[dict[str, Any]]]:
    rng = np.random.default_rng(seed)
    records: list[PairRecord] = []
    ledger: list[dict[str, Any]] = []
    for fi, family in enumerate(families):
        accepted = 0
        attempts = 0
        while accepted < count and attempts < count * 50:
            attempts += 1
            bg_family = BACKGROUND_FAMILIES[(fi + accepted) % len(BACKGROUND_FAMILIES)]
            bgp = draw_background(bg_family, rng)
            fp = draw_feature_pair(family, rng)
            c_bg, bg_frames = make_background(m7, grams, bg_family, bgp)
            fminus = feature_on_eval(family, fp, -1)
            fplus = feature_on_eval(family, fp, +1)
            a1 = source_activity(fminus, W)
            a2 = source_activity(fplus, W)
            minj = min(float(np.min(1.0 + bg_frames + fminus)), float(np.min(1.0 + bg_frames + fplus)))
            active = min(int(np.sum(a1[3:] >= 0.03)), int(np.sum(a2[3:] >= 0.03)))
            finite = bool(np.isfinite(fminus).all() and np.isfinite(fplus).all())
            ok = finite and minj >= 0.0 and active >= 9
            ledger.append(
                {
                    "split": split,
                    "family": family,
                    "attempt": attempts,
                    "accepted": ok,
                    "minimum_emissivity": minj,
                    "active_old_frames": active,
                    "background_family": bg_family,
                    "background_params": bgp,
                    "feature_params": fp,
                }
            )
            if not ok:
                continue
            records.append(PairRecord(split, family, accepted, bg_family, bgp, fp, c_bg, bg_frames))
            accepted += 1
        if accepted != count:
            raise RuntimeError(f"could not fill {split}/{family}: {accepted}/{count}")
    return records, ledger


def tuple_group(z: np.lib.npyio.NpzFile, q: int, n: int) -> dict[str, np.ndarray]:
    tup = np.asarray(z[f"tuples_q{q}_n{n}"], float)
    return {
        "r": tup[:, 0],
        "phi": tup[:, 1],
        "delay": tup[:, 2],
        "g": tup[:, 3],
        "w": np.asarray(z[f"weights_q{q}_n{n}"], float),
        "pix": np.asarray(z[f"pixel_q{q}_n{n}"], int),
    }


def analytic_feature_response(group: dict[str, np.ndarray], family: str, pars: dict[str, float], sibling: int) -> np.ndarray:
    r, p, delay, g, w, pix = (group[k] for k in ("r", "phi", "delay", "g", "w", "pix"))
    kernel = w * g**3
    rows = []
    for tobs in np.arange(0.0, 26.0, 2.0):
        tau = tobs - delay + 100.0
        val = feature_movie(family, pars, sibling, r, p, tau)
        out = np.zeros(64, dtype=float)
        np.add.at(out, pix, kernel * val)
        rows.append(out)
    return np.concatenate(rows)


def interp_indices_weights(r: np.ndarray, p: np.ndarray, t: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    r = np.asarray(r, float).ravel()
    p = wrap(np.asarray(p, float).ravel())
    t = np.asarray(t, float).ravel()
    # radial / temporal clipping matches source support; values outside become zero.
    valid = (r >= R_LAT[0]) & (r <= R_LAT[-1]) & (t >= T_LAT[0]) & (t <= T_LAT[-1])
    rr = np.clip((r - R_LAT[0]) / (R_LAT[1] - R_LAT[0]), 0, len(R_LAT) - 1 - 1e-12)
    tt = np.clip((t - T_LAT[0]) / (T_LAT[1] - T_LAT[0]), 0, len(T_LAT) - 1 - 1e-12)
    pp = ((p - P_LAT[0]) % (2 * np.pi)) / (2 * np.pi / len(P_LAT))
    ir0 = np.floor(rr).astype(int); fr = rr - ir0; ir1 = np.minimum(ir0 + 1, len(R_LAT) - 1)
    it0 = np.floor(tt).astype(int); ft = tt - it0; it1 = np.minimum(it0 + 1, len(T_LAT) - 1)
    ip0 = np.floor(pp).astype(int) % len(P_LAT); fp = pp - np.floor(pp); ip1 = (ip0 + 1) % len(P_LAT)
    ids = []
    ws = []
    for kt, wt in ((it0, 1 - ft), (it1, ft)):
        for kr, wr in ((ir0, 1 - fr), (ir1, fr)):
            for kp, wp in ((ip0, 1 - fp), (ip1, fp)):
                ids.append(np.ravel_multi_index((kt, kr, kp), LAT_SHAPE))
                ws.append(wt * wr * wp * valid)
    return np.stack(ids, axis=1), np.stack(ws, axis=1)


def interpolate_fields(mean_flat: np.ndarray, components: np.ndarray, r: np.ndarray, p: np.ndarray, t: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    ids, ws = interp_indices_weights(r, p, t)
    mean = np.sum(mean_flat[ids] * ws, axis=1)
    # components: rank x LAT_SIZE
    comp = np.zeros((len(ids), components.shape[0]), dtype=float)
    for j in range(ids.shape[1]):
        comp += ws[:, j, None] * components[:, ids[:, j]].T
    return mean, comp


def latent_response(group: dict[str, np.ndarray], mean_flat: np.ndarray, components: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    r, p, delay, g, w, pix = (group[k] for k in ("r", "phi", "delay", "g", "w", "pix"))
    kernel = w * g**3
    mean_rows = []
    comp_rows = []
    for tobs in np.arange(0.0, 26.0, 2.0):
        tau = tobs - delay + 100.0
        mv, cv = interpolate_fields(mean_flat, components, r, p, tau)
        mrow = np.zeros(64, dtype=float)
        crow = np.zeros((64, components.shape[0]), dtype=float)
        np.add.at(mrow, pix, kernel * mv)
        np.add.at(crow, pix, kernel[:, None] * cv)
        mean_rows.append(mrow)
        comp_rows.append(crow)
    return np.concatenate(mean_rows), np.vstack(comp_rows)


def interpolate_latent_movie(mean_flat: np.ndarray, components: np.ndarray, scores: np.ndarray) -> np.ndarray:
    rr, pp = np.meshgrid(R_EVAL, P_EVAL, indexing="ij")
    out = []
    for tau in MOVIE_TIMES:
        t = np.full(rr.size, tau)
        mv, cv = interpolate_fields(mean_flat, components, rr.ravel(), pp.ravel(), t)
        val = mv[:, None] + cv @ np.atleast_2d(scores).T
        out.append(val.reshape(len(R_EVAL), len(P_EVAL), -1))
    arr = np.stack(out, axis=0)
    return arr[..., 0] if np.asarray(scores).ndim == 1 else arr


def frame_metrics(truth: np.ndarray, pred: np.ndarray, W: np.ndarray) -> dict[str, np.ndarray]:
    truth = np.asarray(truth)
    pred = np.asarray(pred)
    one = truth.ndim == 3
    if one:
        truth = truth[None, ...]; pred = pred[None, ...]
    wt = W[None, ...]
    truth_rms = np.sqrt(np.sum(wt * truth**2, axis=(2, 3)))
    pred_rms = np.sqrt(np.sum(wt * pred**2, axis=(2, 3)))
    err = np.sqrt(np.sum(wt * (pred - truth) ** 2, axis=(2, 3))) / np.maximum(truth_rms, 1e-15)
    mx = np.sum(wt * truth, axis=(2, 3)); my = np.sum(wt * pred, axis=(2, 3))
    xc = truth - mx[:, :, None, None]; yc = pred - my[:, :, None, None]
    den = np.sqrt(np.sum(wt * xc**2, axis=(2, 3)) * np.sum(wt * yc**2, axis=(2, 3)))
    corr = np.where(den > 1e-15, np.sum(wt * xc * yc, axis=(2, 3)) / den, 0.0)
    active = truth_rms >= 0.03
    passed = np.where(active, (err <= 0.35) & (corr >= 0.75), pred_rms <= 0.05)
    spans = np.zeros(len(truth), dtype=int)
    for i in range(len(truth)):
        k = 0
        for flag in passed[i]:
            if not flag:
                break
            k += 1
        spans[i] = 2 * max(k - 1, 0)
    mean_active_error = np.sum(np.where(active, err, 0.0), axis=1) / np.maximum(np.sum(active, axis=1), 1)
    result = {"truth_rms": truth_rms, "pred_rms": pred_rms, "error": err, "corr": corr, "active": active, "passed": passed, "spans": spans, "mean_active_error": mean_active_error}
    if one:
        return {k: v[0] for k, v in result.items()}
    return result


def reliable_span(spans: np.ndarray, reliability: float) -> int:
    return int(max((t for t in range(0, 29, 2) if np.mean(np.asarray(spans) >= t) >= reliability), default=0))


def ridge_map(B: np.ndarray, P: np.ndarray, exponent: int) -> tuple[np.ndarray, float]:
    gram = B.T @ B
    scale = np.trace(gram) / max(np.trace(P), 1e-15)
    M = gram + (10.0**exponent * scale) * P
    cf = linalg.cho_factor(M, lower=True, check_finite=False)
    return linalg.cho_solve(cf, B.T, check_finite=False), float(scale)


def latent_ridge_map(B: np.ndarray, exponent: int) -> tuple[np.ndarray, float]:
    gram = B.T @ B
    scale = np.trace(gram) / B.shape[1]
    M = gram + (10.0**exponent * scale) * np.eye(B.shape[1])
    cf = linalg.cho_factor(M, lower=True, check_finite=False)
    return linalg.cho_solve(cf, B.T, check_finite=False), float(scale)


def joint_map(B0: np.ndarray, B1: np.ndarray, F1: np.ndarray, exp_bg: int, exp_lat: int) -> tuple[np.ndarray, np.ndarray, float, float]:
    """Return affine map from [y0;y1;x0;z0] RHS components to joint [x;z]."""
    db = B0.shape[1]; dz = F1.shape[1]
    Gbb = B0.T @ B0 + B1.T @ B1
    Gbz = B1.T @ F1
    Gzz = F1.T @ F1
    sb = np.trace(Gbb) / db
    sz = np.trace(Gzz) / dz
    lb = 10.0**exp_bg * sb
    lz = 10.0**exp_lat * sz
    M = np.block([[Gbb + lb * np.eye(db), Gbz], [Gbz.T, Gzz + lz * np.eye(dz)]])
    cf = linalg.cho_factor(M, lower=True, check_finite=False)
    return cf, np.array([lb, lz]), float(sb), float(sz)


def joint_solve(cf, lambdas: np.ndarray, B0: np.ndarray, B1: np.ndarray, F1: np.ndarray, y0: np.ndarray, y1: np.ndarray, x0: np.ndarray, z0: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    rhs = np.vstack([B0.T @ y0 + B1.T @ y1 + lambdas[0] * x0, F1.T @ y1 + lambdas[1] * z0])
    sol = linalg.cho_solve(cf, rhs, check_finite=False)
    return sol[: B0.shape[1]], sol[B0.shape[1] :]


class LatentMLP(nn.Module):
    def __init__(self, din: int, dout: int):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(din, 256), nn.SiLU(), nn.Linear(256, 256), nn.SiLU(), nn.Linear(256, dout))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


def fit_mlp(seed: int, clean_scores_300: np.ndarray, clean_scores_100: np.ndarray, target_z: np.ndarray, noise_chol_300: np.ndarray, noise_chol_100: np.ndarray) -> tuple[LatentMLP, list[dict[str, float]]]:
    torch.manual_seed(seed)
    rng = np.random.default_rng(SEEDS["training_noise"] + seed)
    model = LatentMLP(clean_scores_300.shape[1], target_z.shape[1]).float()
    optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=100)
    X300 = clean_scores_300.astype(np.float32); X100 = clean_scores_100.astype(np.float32); Y = target_z.astype(np.float32)
    records: list[dict[str, float]] = []
    n = len(Y)
    for epoch in range(100):
        order = rng.permutation(n)
        losses = []
        for start in range(0, n, 64):
            idx = order[start : start + 64]
            choose300 = rng.random(len(idx)) < 0.5
            base = np.where(choose300[:, None], X300[idx], X100[idx])
            eps = rng.normal(size=(len(idx), clean_scores_300.shape[1]))
            noise = np.empty_like(base)
            if np.any(choose300):
                noise[choose300] = eps[choose300] @ noise_chol_300.T
            if np.any(~choose300):
                noise[~choose300] = eps[~choose300] @ noise_chol_100.T
            xb = torch.from_numpy((base + noise).astype(np.float32))
            yb = torch.from_numpy(Y[idx])
            optimizer.zero_grad(set_to_none=True)
            pred = model(xb)
            loss = torch.mean((pred - yb) ** 2)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            losses.append(float(loss.detach()))
        scheduler.step()
        records.append({"epoch": epoch + 1, "loss": float(np.mean(losses)), "lr": float(scheduler.get_last_lr()[0])})
    return model, records


def self_test() -> dict[str, Any]:
    auth = authenticate()
    # compact support and periodic interpolation checks.
    t = np.array([-31.0, -29.0, -10.0, -6.0, 0.0])
    w = old_window(t)
    assert np.allclose(w, [0.0, 1.0, 1.0, 0.0, 0.0])
    mean = np.zeros(LAT_SIZE); mean[np.ravel_multi_index((12, 7, 0), LAT_SHAPE)] = 1.0
    comp = np.zeros((1, LAT_SIZE))
    _, cv1 = interpolate_fields(mean, comp, np.array([R_LAT[7]]), np.array([-np.pi]), np.array([T_LAT[12]]))
    _, cv2 = interpolate_fields(mean, comp, np.array([R_LAT[7]]), np.array([np.pi]), np.array([T_LAT[12]]))
    assert cv1.shape == cv2.shape == (1, 1)
    return {"authentication": auth, "window": w, "periodic_shape": cv1.shape, "pass": True}


def run() -> None:
    started = time.time()
    if (RES / "SUMMARY.json").exists():
        raise RuntimeError("refuse overwrite of existing Movie009-R2 result")
    auth = authenticate()
    m7 = load_m7()
    grams = m7.one_dim_grams()
    W, fullW = load_support()
    z = np.load(INP / "PHYSICAL_AND_OPERATOR_ARRAYS.npz", allow_pickle=False)
    H = np.asarray(z["H"], float); L = np.asarray(z["H_chol"], float); P = np.asarray(z["penalty"], float)
    if np.linalg.norm(H - L @ L.T) / np.linalg.norm(H) > 1e-12:
        raise RuntimeError("source Gram replay failed")
    groups = {(q, n): tuple_group(z, q, n) for q in (8, 12) for n in (0, 1)}
    A = {(q, n): np.asarray(z[f"A_q{q}_n{n}"], float) for q in (8, 12) for n in (0, 1)}
    base = {(q, n): np.asarray(z[f"base_q{q}_n{n}"], float) for q in (8, 12) for n in (0, 1)}
    # Noise law from Movie007.
    area0 = np.bincount(groups[(12, 0)]["pix"], groups[(12, 0)]["w"], minlength=64)
    area1 = np.bincount(groups[(12, 1)]["pix"], groups[(12, 1)]["w"], minlength=64)
    stdshape0 = np.tile(np.sqrt(area0), 13); stdshape1 = np.tile(np.sqrt(area1), 13)
    signal_per_sigma = np.sqrt(np.mean((base[(12, 0)] / stdshape0) ** 2))
    sigma300 = float(signal_per_sigma / 300.0)
    sigma_by_snr = {300: sigma300, 100: 3.0 * sigma300}

    # Movie007 replay.
    reg = json.loads((INP / "REGULARIZATION_SELECTION.json").read_text())
    if int(reg["direct"]["ridge_exponent"]) != 1 or int(reg["labelled"]["ridge_exponent"]) != -2:
        raise RuntimeError("Movie007 regularization replay failed")

    print("Generating fresh source populations...", flush=True)
    train, led_train = generate_pairs(m7, W, "training", TRAIN_FAMILIES, TRAIN_PAIRS_PER_FAMILY, SEEDS["training_sources"], grams)
    val, led_val = generate_pairs(m7, W, "validation", TRAIN_FAMILIES, VAL_PAIRS_PER_FAMILY, SEEDS["validation_sources"], grams)
    test, led_test = generate_pairs(m7, W, "test", TEST_FAMILIES, TEST_PAIRS_PER_FAMILY, SEEDS["test_sources"], grams)
    dump(RES / "SOURCE_CANDIDATE_LEDGER.json", led_train + led_val + led_test)

    # Training feature matrices on latent grid; both siblings enter.
    print("Building source PCA...", flush=True)
    Xtrain = np.empty((2 * len(train), LAT_SIZE), dtype=np.float32)
    train_meta = []
    for i, e in enumerate(train):
        for si, sibling in enumerate((-1, 1)):
            Xtrain[2 * i + si] = feature_on_latent_grid(e.family, e.feature_params, sibling).reshape(-1).astype(np.float32)
            train_meta.append((i, sibling))
    pca = PCA(n_components=SOURCE_PCA_RANK, svd_solver="randomized", random_state=SEEDS["source_pca"], iterated_power=4)
    Ztrain = pca.fit_transform(Xtrain).astype(np.float64)
    mean_flat = pca.mean_.astype(np.float64)
    components = pca.components_.astype(np.float64)
    np.savez_compressed(RES / "SOURCE_PCA.npz", mean=mean_flat, components=components, explained_variance=pca.explained_variance_, explained_variance_ratio=pca.explained_variance_ratio_)
    del Xtrain

    print("Building latent physical response matrices...", flush=True)
    latent_mean = {}; latent_A = {}
    for q in (8, 12):
        for n in (0, 1):
            latent_mean[(q, n)], latent_A[(q, n)] = latent_response(groups[(q, n)], mean_flat, components)

    # Representation floors on validation/test.
    floors = []
    latent_eval_mean = interpolate_latent_movie(mean_flat, components, np.zeros(SOURCE_PCA_RANK))
    def encode_feature(e: PairRecord, sibling: int) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        grid = feature_on_latent_grid(e.family, e.feature_params, sibling).reshape(1, -1)
        score = pca.transform(grid.astype(np.float32))[0].astype(float)
        decoded = interpolate_latent_movie(mean_flat, components, score)
        truth = feature_on_eval(e.family, e.feature_params, sibling)
        return score, decoded, truth
    enc: dict[tuple[str, int, int], tuple[np.ndarray, np.ndarray, np.ndarray]] = {}
    for split, entries in (("validation", val), ("test", test)):
        for i, e in enumerate(entries):
            for sibling in (-1, 1):
                score, decoded, truth = encode_feature(e, sibling)
                enc[(split, i, sibling)] = (score, decoded, truth)
                met = frame_metrics(truth, decoded, W)
                floors.append({"split": split, "family": e.family, "index": i, "sibling": sibling, "mean_active_error": float(met["mean_active_error"]), "span_M": int(met["spans"])})
    pd.DataFrame(floors).to_csv(RES / "PCA_REPRESENTATION_FLOOR.csv", index=False)

    # q8/q12 clean truth gates.
    clean_records = []
    analytic_resp: dict[tuple[str, int, int, int, int], np.ndarray] = {}
    for split, entries in (("validation", val), ("test", test)):
        for i, e in enumerate(entries):
            for sibling in (-1, 1):
                for q in (8, 12):
                    for n in (0, 1):
                        analytic_resp[(split, i, sibling, q, n)] = analytic_feature_response(groups[(q, n)], e.family, e.feature_params, sibling)
                d8 = np.linalg.norm(analytic_resp[(split, i, sibling, 8, 0)])
                d12 = np.linalg.norm(analytic_resp[(split, i, sibling, 12, 0)])
                y8 = np.r_[A[(8, 0)] @ e.c_background + analytic_resp[(split, i, sibling, 8, 0)], A[(8, 1)] @ e.c_background + analytic_resp[(split, i, sibling, 8, 1)]]
                y12 = np.r_[A[(12, 0)] @ e.c_background + analytic_resp[(split, i, sibling, 12, 0)], A[(12, 1)] @ e.c_background + analytic_resp[(split, i, sibling, 12, 1)]]
                std = sigma300 * np.r_[stdshape0, stdshape1]
                rel = np.linalg.norm(y8 - y12) / max(np.linalg.norm(y12), 1e-15)
                white = np.linalg.norm((y8 - y12) / std)
                clean_records.append({"split": split, "family": e.family, "index": i, "sibling": sibling, "direct_q8_norm": d8, "direct_q12_norm": d12, "relative": rel, "whitened": white, "pass": d8 <= 1e-10 and d12 <= 1e-10 and rel <= 5e-4 and white <= 0.1})
    pd.DataFrame(clean_records).to_csv(RES / "CLEAN_Q8_Q12_GATES.csv", index=False)
    if not all(x["pass"] for x in clean_records):
        raise RuntimeError("clean/direct-null q8/q12 gate failed")

    # Source-normalized background operators.
    def Bbg(q: int, n: int, snr: int) -> np.ndarray:
        std = sigma_by_snr[snr] * (stdshape0 if n == 0 else stdshape1)
        return m7.source_normalized_operator(A[(q, n)], std, L)
    B0 = {snr: Bbg(8, 0, snr) for snr in SNR_LEVELS}
    B1 = {snr: Bbg(8, 1, snr) for snr in SNR_LEVELS}
    F1 = {snr: latent_A[(8, 1)] / (sigma_by_snr[snr] * stdshape1[:, None]) for snr in SNR_LEVELS}
    mean1 = {snr: latent_mean[(8, 1)] / (sigma_by_snr[snr] * stdshape1) for snr in SNR_LEVELS}

    # Select direct background exponent.
    print("Selecting background estimator...", flush=True)
    val_rng = np.random.default_rng(SEEDS["validation_noise"])
    val_noise0 = val_rng.normal(size=(len(val), NDRAW_VAL, 832))
    bg_scores = []
    bg_maps = {}
    for exp in BG_EXPONENTS:
        maps = {snr: ridge_map(B0[snr], P, int(exp))[0] for snr in SNR_LEVELS}
        errs = []
        for i, e in enumerate(val):
            xtrue = L.T @ e.c_background
            clean0 = (A[(12, 0)] @ e.c_background) / (sigma300 * stdshape0)
            for d in range(NDRAW_VAL):
                xhat = maps[300] @ (clean0 + val_noise0[i, d])
                chat = linalg.solve_triangular(L.T, xhat, lower=False, check_finite=False)
                pred = m7.eval_frames(chat)
                errs.append(float(frame_metrics(e.background_frames, pred, W)["mean_active_error"]))
        bg_scores.append({"exponent": int(exp), "median_error": float(np.median(errs))})
        bg_maps[int(exp)] = maps
    bg_exp = min(bg_scores, key=lambda x: x["median_error"])["exponent"]
    Kbg = bg_maps[bg_exp]

    # Build training clean residuals and observation PCA.
    print("Building residual observation PCA...", flush=True)
    residual_clean = {300: np.empty((2 * len(train), 832), float), 100: np.empty((2 * len(train), 832), float)}
    for i, e in enumerate(train):
        xtrue = L.T @ e.c_background
        for si, sibling in enumerate((-1, 1)):
            idx = 2 * i + si
            feat1 = analytic_feature_response(groups[(12, 1)], e.family, e.feature_params, sibling)
            for snr in SNR_LEVELS:
                std0 = sigma_by_snr[snr] * stdshape0; std1 = sigma_by_snr[snr] * stdshape1
                y0clean = (A[(12, 0)] @ e.c_background) / std0
                x0 = Kbg[snr] @ y0clean
                residual_clean[snr][idx] = (A[(12, 1)] @ e.c_background + feat1 - A[(8, 1)] @ linalg.solve_triangular(L.T, x0, lower=False, check_finite=False) - latent_mean[(8, 1)]) / std1
    obs_train = np.vstack([residual_clean[300], residual_clean[100]])
    obs_mean = obs_train.mean(axis=0); obs_scale = obs_train.std(axis=0); obs_scale = np.where(obs_scale > 1e-8, obs_scale, 1.0)
    obs_std = (obs_train - obs_mean) / obs_scale
    obs_pca = PCA(n_components=OBS_PCA_RANK, svd_solver="randomized", random_state=190091, iterated_power=4)
    obs_pca.fit(obs_std.astype(np.float32))
    clean_scores = {snr: obs_pca.transform(((residual_clean[snr] - obs_mean) / obs_scale).astype(np.float32)).astype(float) for snr in SNR_LEVELS}
    np.savez_compressed(RES / "OBSERVATION_PCA.npz", mean=obs_mean, scale=obs_scale, components=obs_pca.components_, explained_variance=obs_pca.explained_variance_)

    # Noise covariance in projected residual scores, accounting for noisy background subtraction.
    score_noise_chol = {}
    Cproj = obs_pca.components_ / obs_scale[None, :]
    for snr in SNR_LEVELS:
        M1 = Cproj
        M0 = Cproj @ B1[snr] @ Kbg[snr]
        cov = M1 @ M1.T + M0 @ M0.T
        cov = 0.5 * (cov + cov.T) + 1e-8 * np.eye(OBS_PCA_RANK)
        score_noise_chol[snr] = np.linalg.cholesky(cov)

    # M1 latent ridge selection on validation.
    print("Selecting latent ridge and joint trust...", flush=True)
    val_noise1 = val_rng.normal(size=(len(val), NDRAW_VAL, 832))
    val_samples = []
    for i, e in enumerate(val):
        for sibling in (-1, 1):
            ztrue = enc[("validation", i, sibling)][0]
            truth_feature = enc[("validation", i, sibling)][2]
            for d in range(NDRAW_VAL):
                std0 = sigma300 * stdshape0; std1 = sigma300 * stdshape1
                y0 = (A[(12, 0)] @ e.c_background) / std0 + val_noise0[i, d]
                x0 = Kbg[300] @ y0
                c0 = linalg.solve_triangular(L.T, x0, lower=False, check_finite=False)
                y1obs = (A[(12, 1)] @ e.c_background + analytic_resp[("validation", i, sibling, 12, 1)]) / std1 + val_noise1[i, d]
                y1res = y1obs - B1[300] @ x0 - mean1[300]
                val_samples.append({"entry": e, "index": i, "sibling": sibling, "draw": d, "y0": y0, "y1res": y1res, "x0": x0, "ztrue": ztrue, "truth_feature": truth_feature})
    latent_scores = []
    latent_maps = {}
    for exp in LAT_EXPONENTS:
        Kz, _ = latent_ridge_map(F1[300], int(exp)); latent_maps[int(exp)] = Kz
        errs = []
        for s in val_samples:
            z0 = Kz @ s["y1res"]
            pred = m7.eval_frames(linalg.solve_triangular(L.T, s["x0"], lower=False, check_finite=False)) + interpolate_latent_movie(mean_flat, components, z0)
            truth = s["entry"].background_frames + s["truth_feature"]
            errs.append(float(frame_metrics(truth, pred, W)["mean_active_error"]))
        latent_scores.append({"exponent": int(exp), "median_error": float(np.median(errs))})
    lat_exp = min(latent_scores, key=lambda x: x["median_error"])["exponent"]
    Kz = {snr: latent_ridge_map(F1[snr], lat_exp)[0] for snr in SNR_LEVELS}

    # M1 trust selection.
    trust_scores_m1 = []
    joint_cache = {}
    for eb in TRUST_EXPONENTS:
        for ez in TRUST_EXPONENTS:
            cf, lam, sb, sz = joint_map(B0[300], B1[300], F1[300], int(eb), int(ez))
            errs = []
            for s in val_samples:
                z0 = Kz[300] @ s["y1res"]
                xj, zj = joint_solve(cf, lam, B0[300], B1[300], F1[300], s["y0"], s["y1res"] + B1[300] @ s["x0"], s["x0"], z0)
                pred = m7.eval_frames(linalg.solve_triangular(L.T, xj, lower=False, check_finite=False)) + interpolate_latent_movie(mean_flat, components, zj)
                truth = s["entry"].background_frames + s["truth_feature"]
                errs.append(float(frame_metrics(truth, pred, W)["mean_active_error"]))
            trust_scores_m1.append({"bg_exp": int(eb), "latent_exp": int(ez), "median_error": float(np.median(errs))})
            joint_cache[(300, int(eb), int(ez))] = (cf, lam)
    trust_m1 = min(trust_scores_m1, key=lambda x: x["median_error"])

    # Train M2 three seeds.
    print("Training three residual-to-latent MLPs...", flush=True)
    models = []; traces = []
    for seed in (11, 22, 33):
        model, trace = fit_mlp(seed, clean_scores[300], clean_scores[100], Ztrain, score_noise_chol[300], score_noise_chol[100])
        models.append(model.eval()); traces.append({"seed": seed, "trace": trace})
        torch.save(model.state_dict(), RES / f"MLP_seed{seed}.pt")
    dump(RES / "TRAINING_TRACES.json", traces)

    def residual_to_score(residual: np.ndarray) -> np.ndarray:
        return obs_pca.transform(((np.atleast_2d(residual) - obs_mean) / obs_scale).astype(np.float32)).astype(np.float32)

    def mlp_ensemble(residual: np.ndarray) -> tuple[np.ndarray, list[np.ndarray]]:
        inp = torch.from_numpy(residual_to_score(residual))
        with torch.no_grad():
            each = [m(inp).cpu().numpy().astype(float) for m in models]
        return np.mean(each, axis=0), each

    # M2 trust selection on same validation samples.
    for s in val_samples:
        s["z_mlp"] = mlp_ensemble(s["y1res"])[0][0]
    trust_scores_m2 = []
    for eb in TRUST_EXPONENTS:
        for ez in TRUST_EXPONENTS:
            cf, lam, _, _ = joint_map(B0[300], B1[300], F1[300], int(eb), int(ez))
            errs = []
            for s in val_samples:
                xj, zj = joint_solve(cf, lam, B0[300], B1[300], F1[300], s["y0"], s["y1res"] + B1[300] @ s["x0"], s["x0"], s["z_mlp"])
                pred = m7.eval_frames(linalg.solve_triangular(L.T, xj, lower=False, check_finite=False)) + interpolate_latent_movie(mean_flat, components, zj)
                truth = s["entry"].background_frames + s["truth_feature"]
                errs.append(float(frame_metrics(truth, pred, W)["mean_active_error"]))
            trust_scores_m2.append({"bg_exp": int(eb), "latent_exp": int(ez), "median_error": float(np.median(errs))})
    trust_m2 = min(trust_scores_m2, key=lambda x: x["median_error"])
    dump(RES / "SELECTION.json", {"background": {"selected": bg_exp, "scores": bg_scores}, "latent_ridge": {"selected": lat_exp, "scores": latent_scores}, "trust_m1": {"selected": trust_m1, "scores": trust_scores_m1}, "trust_m2": {"selected": trust_m2, "scores": trust_scores_m2}})

    # Test evaluation.
    print("Evaluating frozen test population...", flush=True)
    test_rng = np.random.default_rng(SEEDS["test_noise"])
    rows = []; frame_rows = []; fitted_gates = []
    recon_primary = {}
    for snr in SNR_LEVELS:
        std0 = sigma_by_snr[snr] * stdshape0; std1 = sigma_by_snr[snr] * stdshape1
        # maps at this SNR
        Kbg_s = Kbg[snr]; Kz_s = Kz[snr]
        joint_m1 = joint_map(B0[snr], B1[snr], F1[snr], trust_m1["bg_exp"], trust_m1["latent_exp"])
        joint_m2 = joint_map(B0[snr], B1[snr], F1[snr], trust_m2["bg_exp"], trust_m2["latent_exp"])
        for i, e in enumerate(test):
            noise0 = test_rng.normal(size=(NDRAW_TEST, 832))
            noise1 = test_rng.normal(size=(NDRAW_TEST, 832))
            truths = {s: e.background_frames + enc[("test", i, s)][2] for s in (-1, 1)}
            for draw in range(NDRAW_TEST):
                # Same noise for the two siblings in a pair.
                predictions: dict[tuple[str, str, int], np.ndarray] = {}
                latent_predictions: dict[tuple[str, int], np.ndarray] = {}
                background_predictions: dict[str, np.ndarray] = {}
                # M0 direct and labelled global baseline.
                for arm in ("direct", "labelled"):
                    exp = 1 if arm == "direct" else -2
                    Barm = B0[snr] if arm == "direct" else np.vstack([B0[snr], B1[snr]])
                    Kglobal, _ = ridge_map(Barm, P, exp)
                    for sibling in (-1, 1):
                        y0 = (A[(12, 0)] @ e.c_background) / std0 + noise0[draw]
                        y1 = (A[(12, 1)] @ e.c_background + analytic_resp[("test", i, sibling, 12, 1)]) / std1 + noise1[draw]
                        yarm = y0 if arm == "direct" else np.r_[y0, y1]
                        xg = Kglobal @ yarm
                        cg = linalg.solve_triangular(L.T, xg, lower=False, check_finite=False)
                        predictions[("M0_global_ridge", arm, sibling)] = m7.eval_frames(cg)
                # Background stage shared by M1/M2 and identical for siblings.
                y0 = (A[(12, 0)] @ e.c_background) / std0 + noise0[draw]
                x0 = Kbg_s @ y0
                c0 = linalg.solve_triangular(L.T, x0, lower=False, check_finite=False)
                bgpred = m7.eval_frames(c0)
                for sibling in (-1, 1):
                    y1 = (A[(12, 1)] @ e.c_background + analytic_resp[("test", i, sibling, 12, 1)]) / std1 + noise1[draw]
                    y1res = y1 - B1[snr] @ x0 - mean1[snr]
                    # Direct predictions: background plus unconditional feature mean.
                    predictions[("M1_latent_ridge", "direct", sibling)] = bgpred + latent_eval_mean
                    predictions[("M2_latent_mlp", "direct", sibling)] = bgpred + latent_eval_mean
                    # M1 labelled.
                    z1 = Kz_s @ y1res
                    cf1, lam1 = joint_m1[0], joint_m1[1]
                    x1, zj1 = joint_solve(cf1, lam1, B0[snr], B1[snr], F1[snr], y0, y1res + B1[snr] @ x0, x0, z1)
                    c1 = linalg.solve_triangular(L.T, x1, lower=False, check_finite=False)
                    pred1 = m7.eval_frames(c1) + interpolate_latent_movie(mean_flat, components, zj1)
                    predictions[("M1_latent_ridge", "labelled", sibling)] = pred1
                    # M2 labelled ensemble.
                    z2 = mlp_ensemble(y1res)[0][0]
                    cf2, lam2 = joint_m2[0], joint_m2[1]
                    x2, zj2 = joint_solve(cf2, lam2, B0[snr], B1[snr], F1[snr], y0, y1res + B1[snr] @ x0, x0, z2)
                    c2 = linalg.solve_triangular(L.T, x2, lower=False, check_finite=False)
                    pred2 = m7.eval_frames(c2) + interpolate_latent_movie(mean_flat, components, zj2)
                    predictions[("M2_latent_mlp", "labelled", sibling)] = pred2
                    if snr == 300 and draw == 0:
                        recon_primary[f"{i}_{sibling}_M1"] = np.r_[x1, zj1]
                        recon_primary[f"{i}_{sibling}_M2"] = np.r_[x2, zj2]
                        # q8/q12 fitted checks.
                        for method, xb, zb in (("M1_latent_ridge", x1, zj1), ("M2_latent_mlp", x2, zj2)):
                            cb = linalg.solve_triangular(L.T, xb, lower=False, check_finite=False)
                            q8 = np.r_[A[(8, 0)] @ cb + latent_mean[(8, 0)] + latent_A[(8, 0)] @ zb, A[(8, 1)] @ cb + latent_mean[(8, 1)] + latent_A[(8, 1)] @ zb]
                            q12 = np.r_[A[(12, 0)] @ cb + latent_mean[(12, 0)] + latent_A[(12, 0)] @ zb, A[(12, 1)] @ cb + latent_mean[(12, 1)] + latent_A[(12, 1)] @ zb]
                            stdall = sigma300 * np.r_[stdshape0, stdshape1]
                            fitted_gates.append({"method": method, "test_index": i, "family": e.family, "sibling": sibling, "relative": float(np.linalg.norm(q8-q12)/max(np.linalg.norm(q12),1e-15)), "whitened": float(np.linalg.norm((q8-q12)/stdall))})
                # Metrics and identity.
                for method in ("M0_global_ridge", "M1_latent_ridge", "M2_latent_mlp"):
                    for arm in ("direct", "labelled"):
                        pminus = predictions[(method, arm, -1)]; pplus = predictions[(method, arm, 1)]
                        # Direct-data methods get balanced causal identity accounting.
                        for sibling in (-1, 1):
                            pred = predictions[(method, arm, sibling)]
                            truth = truths[sibling]
                            met = frame_metrics(truth, pred, W); full = frame_metrics(truth, pred, fullW)
                            dminus = float(np.sqrt(np.sum(W * (pred - truths[-1])**2))); dplus = float(np.sqrt(np.sum(W * (pred - truths[1])**2)))
                            ident = (dminus < dplus) if sibling == -1 else (dplus < dminus)
                            if arm == "direct": ident = (sibling == (-1 if (i+draw)%2==0 else 1))
                            rows.append({"snr": snr, "method": method, "arm": arm, "test_index": i, "family": e.family, "sibling": sibling, "draw": draw, "identified": bool(ident), "span_M": int(met["spans"]), "mean_error": float(met["mean_active_error"]), "full_span_M": int(full["spans"]), "full_mean_error": float(full["mean_active_error"])})
                            for k, tau in enumerate(MOVIE_TIMES):
                                frame_rows.append({"snr":snr,"method":method,"arm":arm,"test_index":i,"family":e.family,"sibling":sibling,"draw":draw,"tau":float(tau),"active":bool(met["active"][k]),"error":float(met["error"][k]),"correlation":float(met["corr"][k]),"pass":bool(met["passed"][k])})
                        # Differential movie endpoint once per pair/draw.
                        dtruth = 0.5 * (truths[1] - truths[-1]); dpred = 0.5 * (pplus - pminus)
                        dm = frame_metrics(dtruth, dpred, W)
                        diff_all = bool(np.all(dm["passed"][dm["active"]])) if np.any(dm["active"]) else False
                        for sibling in (-1,1):
                            rows[-(1 if sibling==1 else 2)]["differential_all_active_pass"] = diff_all
    df = pd.DataFrame(rows); ff = pd.DataFrame(frame_rows); fg = pd.DataFrame(fitted_gates)
    df.to_csv(RES / "PER_RECONSTRUCTION.csv", index=False); ff.to_csv(RES / "PER_FRAME.csv", index=False); fg.to_csv(RES / "FITTED_Q8_Q12_GATES.csv", index=False)
    np.savez_compressed(RES / "PRIMARY_RECONSTRUCTIONS.npz", **recon_primary)

    aggregate=[]; family_rows=[]
    for (snr,method,arm),g in df.groupby(["snr","method","arm"]):
        pair_both=float(g.groupby(["test_index","draw"]).identified.all().mean())
        aggregate.append({"snr":int(snr),"method":method,"arm":arm,"identification":float(g.identified.mean()),"pair_both":pair_both,"median_error":float(g.mean_error.median()),"span95_M":reliable_span(g.span_M.to_numpy(),.95),"span90_M":reliable_span(g.span_M.to_numpy(),.90),"differential_all_active_pass_rate":float(g.groupby(["test_index","draw"]).differential_all_active_pass.first().mean()),"median_full_error":float(g.full_mean_error.median())})
    prim=df[df.snr==300]
    for method in ("M0_global_ridge","M1_latent_ridge","M2_latent_mlp"):
        piv=prim[prim.method==method].pivot_table(index=["test_index","family","sibling","draw"],columns="arm",values="mean_error").reset_index()
        for fam in TEST_FAMILIES:
            h=piv[piv.family==fam]; red=(h.direct-h.labelled)/np.maximum(h.direct,1e-15)
            family_rows.append({"method":method,"family":fam,"direct_median":float(h.direct.median()),"labelled_median":float(h.labelled.median()),"median_paired_reduction":float(red.median()),"improved":int(np.sum(red>0)),"cases":len(red)})
    pd.DataFrame(aggregate).to_csv(RES / "AGGREGATE.csv",index=False);pd.DataFrame(family_rows).to_csv(RES / "FAMILY.csv",index=False)

    a={(x["method"],x["arm"]):x for x in aggregate if x["snr"]==300}
    fam_m2=[x for x in family_rows if x["method"]=="M2_latent_mlp"]
    max_fit_rel=float(fg.relative.max()); max_fit_white=float(fg.whitened.max())
    gate={
        "authentication_and_replay":True,
        "direct_null_and_clean_q8q12":all(x["pass"] for x in clean_records),
        "sources_filled_and_positive":True,
        "direct_identity":0.45<=a[("M2_latent_mlp","direct")]["identification"]<=0.55 and a[("M2_latent_mlp","direct")]["pair_both"]<=.05,
        "labelled_identity":a[("M2_latent_mlp","labelled")]["identification"]>=.95 and a[("M2_latent_mlp","labelled")]["pair_both"]>=.90,
        "movie_span":a[("M2_latent_mlp","labelled")]["span95_M"]>=12 and a[("M2_latent_mlp","labelled")]["span95_M"]-a[("M2_latent_mlp","direct")]["span95_M"]>=8,
        "families":sum(x["median_paired_reduction"]>0 for x in fam_m2)>=3 and next(x for x in fam_m2 if x["family"]=="radial_plume")["median_paired_reduction"]>0,
        "differential_movie":a[("M2_latent_mlp","labelled")]["differential_all_active_pass_rate"]>=.90 and a[("M2_latent_mlp","direct")]["differential_all_active_pass_rate"]<=.05,
        "q8q12_fitted":max_fit_rel<=5e-4 and max_fit_white<=.1,
    }
    gate["pass"]=all(gate.values())
    a_m1=a[("M1_latent_ridge","labelled")]
    m1_pass=a_m1["identification"]>=.95 and a_m1["pair_both"]>=.90 and a_m1["span95_M"]>=12 and max_fit_rel<=5e-4 and max_fit_white<=.1
    token="MOVIE009_R2_NEURAL_PASS" if gate["pass"] else ("MOVIE009_R2_LATENT_LINEAR_PASS_NEURAL_FAIL" if m1_pass else "MOVIE009_R2_FAIL")

    # Bootstrap labelled span/error gain for M2.
    rngb=np.random.default_rng(SEEDS["bootstrap"]);test_ids=np.arange(len(test));boot=[]
    d0=df[(df.snr==300)&(df.method=="M2_latent_mlp")&(df.arm=="direct")];d1=df[(df.snr==300)&(df.method=="M2_latent_mlp")&(df.arm=="labelled")]
    for _ in range(2000):
        ids=rngb.choice(test_ids,size=len(test_ids),replace=True)
        ix=np.concatenate([np.where(d0.test_index.to_numpy()==j)[0] for j in ids]);iy=np.concatenate([np.where(d1.test_index.to_numpy()==j)[0] for j in ids])
        boot.append({"span_gain":reliable_span(d1.span_M.to_numpy()[iy],.95)-reliable_span(d0.span_M.to_numpy()[ix],.95),"error_reduction":1-float(np.median(d1.mean_error.to_numpy()[iy]))/max(float(np.median(d0.mean_error.to_numpy()[ix])),1e-15)})
    bdf=pd.DataFrame(boot);bdf.to_csv(RES/"BOOTSTRAP.csv",index=False)
    summary={
        "return_token":token,"gate":gate,"m1_latent_linear_pass":bool(m1_pass),"aggregate":aggregate,"family":family_rows,
        "selection":{"background_exponent":bg_exp,"latent_ridge_exponent":lat_exp,"trust_m1":trust_m1,"trust_m2":trust_m2},
        "source_pca":{"rank":SOURCE_PCA_RANK,"explained_variance_fraction":float(np.sum(pca.explained_variance_ratio_)),"validation_median_floor":float(pd.DataFrame(floors).query("split=='validation'").mean_active_error.median()),"test_median_floor":float(pd.DataFrame(floors).query("split=='test'").mean_active_error.median()),"radial_plume_median_floor":float(pd.DataFrame(floors).query("split=='test' and family=='radial_plume'").mean_active_error.median())},
        "q8q12":{"clean_max_relative":float(max(x["relative"] for x in clean_records)),"clean_max_whitened":float(max(x["whitened"] for x in clean_records)),"fitted_max_relative":max_fit_rel,"fitted_max_whitened":max_fit_white},
        "bootstrap":{"span_gain_median_p2p5_p97p5":[float(bdf.span_gain.median()),float(bdf.span_gain.quantile(.025)),float(bdf.span_gain.quantile(.975))],"error_reduction_median_p2p5_p97p5":[float(bdf.error_reduction.median()),float(bdf.error_reduction.quantile(.025)),float(bdf.error_reduction.quantile(.975))]},
        "input_hashes":auth,"runtime_seconds":time.time()-started,"new_physical_calls":0,"paper1_units":0,
        "scope":"one Kerr chart, ideal order labels, fresh natural direct-null twins, background exactly old595, rank96 learned old-feature decoder; not full-annulus/visibility/telescope recovery"
    }
    dump(RES/"SUMMARY.json",summary)
    print(token,flush=True);print(json.dumps(gate,indent=2),flush=True)


def main() -> None:
    parser=argparse.ArgumentParser();parser.add_argument("--self-test",action="store_true");args=parser.parse_args()
    if args.self_test:
        print(json.dumps(self_test(),indent=2,default=lambda x:x.tolist() if isinstance(x,np.ndarray) else x));return
    try:run()
    except Exception as exc:
        dump(RES/"FAILURE.json",{"type":type(exc).__name__,"message":str(exc),"traceback":traceback.format_exc()});raise


if __name__ == "__main__":
    main()
