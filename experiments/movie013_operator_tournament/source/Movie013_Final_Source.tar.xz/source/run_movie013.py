"""Movie013 controlled operator tournament on frozen Movie007 samples.

No Kerr/geodesic calls are made. q12 cached physical operators generate clean
observations; q8 cached operators define every inverse. The four primary variants
share exactly the same source histories, noise, rows, covariance, and metrics.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import math
import os
import sys
import time
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")

import numpy as np
import pandas as pd
from numpy.polynomial.legendre import leggauss
from scipy import fft, linalg
from scipy.interpolate import BSpline

ROOT = Path(__file__).resolve().parents[1]
INPUTS = ROOT / "inputs"
RESULTS = ROOT / "results"
LOGS = ROOT / "logs"
for p in (RESULTS, LOGS):
    p.mkdir(parents=True, exist_ok=True)

EXPECTED = {
    "PHYSICAL_AND_OPERATOR_ARRAYS.npz": "54204f14b8c834fb3c54dc012c9827e711f339fc6c30251802fea71ac6d8274e",
    "SUPPORT_WEIGHTS.npz": "72080e09e722b01a821d2989d706f21eccfc9ce7671d1fa2f18f66bcd56a7952",
    "REGULARIZATION_SELECTION.json": "f3739497a08973bec6ed0b5c174188ad1b2321b469efa06750de2b43bcddf090",
    "movie007_run.py": "8b80d533cd48400570e505423053a6557e4a2ea6f3d82367adfd5c88b34e5cf1",
    "offbasis.py": "54c1e0ca0f1b2e2d94c34604eecb19c44c4c96a9e59b377f74b303b35aac4b97",
    "kerr.py": "12abafb39f6d5a6ebf4626e0a05c021d3bd0c5c5ca6ae0abd22632656c8f28cf",
}

SNR_LEVELS = (300, 100)
NPIX = 64
NTIME_OBS = 13
RIDGE_EXPONENTS = np.arange(-8, 3, dtype=int)
BLOCK_EXPONENTS = np.array([-6, -4, -2, 0, 2], dtype=int)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path: Path, value: Any) -> None:
    def default(x: Any) -> Any:
        if isinstance(x, np.ndarray):
            return x.tolist()
        if isinstance(x, np.generic):
            return x.item()
        raise TypeError(type(x).__name__)
    path.write_text(json.dumps(value, indent=2, allow_nan=False, default=default) + "\n")


def authenticate() -> dict[str, str]:
    actual: dict[str, str] = {}
    for name, expected in EXPECTED.items():
        p = INPUTS / name
        if not p.is_file():
            raise FileNotFoundError(p)
        got = sha256(p)
        if got != expected:
            raise RuntimeError(f"hash mismatch {name}: {got} != {expected}")
        actual[name] = got
    return actual


def import_movie007():
    sys.path.insert(0, str(INPUTS))
    spec = importlib.util.spec_from_file_location("movie007_frozen", INPUTS / "movie007_run.py")
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot import frozen Movie007 source")
    mod = importlib.util.module_from_spec(spec)
    sys.modules["movie007_frozen"] = mod
    spec.loader.exec_module(mod)
    return mod


def import_offbasis():
    sys.path.insert(0, str(INPUTS))
    spec = importlib.util.spec_from_file_location("offbasis_frozen", INPUTS / "offbasis.py")
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot import frozen offbasis source")
    mod = importlib.util.module_from_spec(spec)
    sys.modules["offbasis_frozen"] = mod
    spec.loader.exec_module(mod)
    return mod


def angular_basis(phi: np.ndarray, max_m: int = 8) -> np.ndarray:
    phi = np.asarray(phi)
    cols = [np.ones_like(phi)]
    for m in range(1, max_m + 1):
        cols.extend([np.cos(m * phi), np.sin(m * phi)])
    return np.stack(cols, axis=-1)


@dataclass
class NestedBasis:
    radial: BSpline
    temporal: BSpline
    nr: int = 5
    na: int = 17
    nt: int = 17

    @property
    def dim(self) -> int:
        return self.nr * self.na * self.nt

    def values(self, r: np.ndarray, phi: np.ndarray, tau: np.ndarray) -> np.ndarray:
        br = np.nan_to_num(self.radial(np.asarray(r)), nan=0.0)
        ba = angular_basis(np.asarray(phi), 8)
        bt = np.nan_to_num(self.temporal(np.asarray(tau)), nan=0.0)
        return np.einsum("...i,...j,...k->...ijk", br, ba, bt, optimize=True).reshape(*np.asarray(r).shape, self.dim)

    def frames(self, coeff: np.ndarray, m) -> np.ndarray:
        c = np.asarray(coeff)
        one = c.ndim == 1
        if one:
            c = c[:, None]
        C = c.reshape(self.nr, self.na, self.nt, -1)
        br = self.radial(m.R_EVAL)
        ba = angular_basis(m.PHI_EVAL, 8)
        frames = []
        for tau in m.MOVIE_TIMES:
            bt = self.temporal(np.array([tau]))[0]
            spatial = np.einsum("ratb,t->rab", C, bt, optimize=True)
            frame = np.einsum("ir,pa,rab->ipb", br, ba, spatial, optimize=True)
            frames.append(frame)
        arr = np.stack(frames, axis=0)
        return arr[..., 0] if one else arr


def nested_grams(m, basis: NestedBasis) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    gr, _ga_old, gt = m.one_dim_grams()
    ga = np.diag([2 * np.pi] + [np.pi] * 16).astype(np.float64)
    H = np.kron(np.kron(gr, ga), gt)
    H = 0.5 * (H + H.T)
    L = np.kron(np.kron(linalg.cholesky(gr, lower=True), linalg.cholesky(ga, lower=True)), linalg.cholesky(gt, lower=True))
    return gr, ga, gt, L


def old_to_nested(c_old: np.ndarray) -> np.ndarray:
    c = np.asarray(c_old)
    one = c.ndim == 1
    if one:
        c = c[:, None]
    old = c.reshape(5, 7, 17, -1)
    new = np.zeros((5, 17, 17, old.shape[-1]), dtype=np.float64)
    new[:, :7, :, :] = old
    out = new.reshape(1445, -1)
    return out[:, 0] if one else out


def x_to_coeff(x: np.ndarray, L: np.ndarray) -> np.ndarray:
    return linalg.solve_triangular(L.T, x, lower=False, check_finite=False)


def coeff_to_x(c: np.ndarray, L: np.ndarray) -> np.ndarray:
    return L.T @ c


def source_normalized_operator(A: np.ndarray, std: np.ndarray, L: np.ndarray) -> np.ndarray:
    return linalg.solve_triangular(L, (A / std[:, None]).T, lower=True, check_finite=False).T


def build_nested_operator(arrays, q: int, order: int, basis: NestedBasis, m) -> tuple[np.ndarray, np.ndarray]:
    tuples = arrays[f"tuples_q{q}_n{order}"]
    weights = arrays[f"weights_q{q}_n{order}"]
    pixel = arrays[f"pixel_q{q}_n{order}"]
    r, phi, delay, g = tuples.T
    q2 = q * q
    if not np.array_equal(pixel, np.repeat(np.arange(NPIX), q2)):
        raise AssertionError("unexpected pixel ordering")
    kernel = weights * g**3
    base_pixel = kernel.reshape(NPIX, q2).sum(axis=1)
    base = np.tile(base_pixel, NTIME_OBS)
    blocks = []
    for tobs in m.OBS_TIMES:
        tau = tobs - delay + 100.0
        vals = basis.values(r, phi, tau)
        block = (vals * kernel[:, None]).reshape(NPIX, q2, basis.dim).sum(axis=1)
        blocks.append(block)
    return base, np.vstack(blocks)


def dct_rows(x: np.ndarray, orders: int) -> np.ndarray:
    arr = np.asarray(x)
    trailing = arr.shape[1:]
    y = arr.reshape(orders, NTIME_OBS, NPIX, *trailing)
    y = fft.dct(y, type=2, axis=1, norm="ortho")
    return y.reshape(arr.shape)


def pixel_std_shapes(arrays) -> tuple[np.ndarray, np.ndarray, float]:
    shapes = []
    for order in (0, 1):
        pixel = arrays[f"pixel_q12_n{order}"]
        weights = arrays[f"weights_q12_n{order}"]
        area = np.bincount(pixel, weights, minlength=NPIX)
        shapes.append(np.tile(np.sqrt(area), NTIME_OBS))
    sigma300 = float(np.sqrt(np.mean((arrays["base_q12_n0"] / shapes[0]) ** 2)) / 300.0)
    return shapes[0], shapes[1], sigma300


def evaluate_frames(truth: np.ndarray, pred: np.ndarray, W: np.ndarray, m) -> dict[str, np.ndarray]:
    return m.weighted_metrics(truth, pred, W)


def reliable_span(spans: np.ndarray, reliability: float, m) -> int:
    return int(m.reliable_span(np.asarray(spans), reliability))


def eig_ridge_setup(B: np.ndarray) -> dict[str, np.ndarray | float]:
    K = B @ B.T
    evals, U = linalg.eigh(K, check_finite=False, overwrite_a=True)
    order = np.argsort(evals)[::-1]
    evals = np.clip(evals[order], 0.0, None)
    U = U[:, order]
    scale = float(np.sum(evals) / B.shape[1])
    return {"B": B, "evals": evals, "U": U, "scale": scale}


def eig_ridge_apply(setup: dict[str, Any], y: np.ndarray, exponent: int) -> np.ndarray:
    B = setup["B"]
    evals = setup["evals"]
    U = setup["U"]
    lam = (10.0**int(exponent)) * float(setup["scale"])
    uy = U.T @ y
    return B.T @ (U @ (uy / (evals[:, None] + lam)))


def old_ridge_apply(B: np.ndarray, P: np.ndarray, y: np.ndarray, exponent: int, scale: float) -> np.ndarray:
    M = B.T @ B + (10.0**int(exponent) * scale) * P
    cf = linalg.cho_factor(M, lower=True, check_finite=False)
    return linalg.cho_solve(cf, B.T @ y, check_finite=False)


def validation_score_nested(c_hat: np.ndarray, truth_coeff_old: np.ndarray, history_idx: np.ndarray, W: np.ndarray, basis: NestedBasis, m) -> float:
    pred = np.moveaxis(basis.frames(c_hat, m), -1, 0)
    truth = np.moveaxis(m.eval_frames(truth_coeff_old), -1, 0)[history_idx]
    met = m.weighted_metrics(truth, pred, W)
    return float(np.median(met["mean_active_error"]))


def metrics_for_nested(c_hat: np.ndarray, truth_frames: np.ndarray, history_idx: np.ndarray, W: np.ndarray, basis: NestedBasis, m) -> dict[str, np.ndarray]:
    pred = np.moveaxis(basis.frames(c_hat, m), -1, 0)
    truth = truth_frames[history_idx]
    return m.weighted_metrics(truth, pred, W)


def select_nested(B: np.ndarray, yval: np.ndarray, truth_coeff_old: np.ndarray, history_idx: np.ndarray, W: np.ndarray, L: np.ndarray, basis: NestedBasis, m) -> tuple[int, list[float], dict[str, Any]]:
    setup = eig_ridge_setup(B)
    scores = []
    for exp in RIDGE_EXPONENTS:
        x = eig_ridge_apply(setup, yval, int(exp))
        c = x_to_coeff(x, L)
        scores.append(validation_score_nested(c, truth_coeff_old, history_idx, W, basis, m))
    best = int(RIDGE_EXPONENTS[int(np.argmin(scores))])
    return best, scores, setup


def block_maps(H: np.ndarray, old_idx: np.ndarray, recent_idx: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    def parent(indices: np.ndarray) -> np.ndarray:
        sub = H[np.ix_(indices, indices)]
        L = linalg.cholesky(sub, lower=True, check_finite=False)
        out = np.zeros((H.shape[0], len(indices)))
        out[indices] = linalg.solve_triangular(L.T, np.eye(len(indices)), lower=False, check_finite=False)
        return out
    return parent(old_idx), parent(recent_idx)


def block_ridge_apply(Bt: np.ndarray, Bn: np.ndarray, y: np.ndarray, et: int, en: int, scales: tuple[float, float]) -> tuple[np.ndarray, np.ndarray]:
    lt = (10.0**int(et)) * scales[0]
    ln = (10.0**int(en)) * scales[1]
    # Woodbury in data space. I + Bt Bt^T/lt + Bn Bn^T/ln is positive definite.
    M = np.eye(Bt.shape[0]) + (Bt @ Bt.T) / lt + (Bn @ Bn.T) / ln
    cf = linalg.cho_factor(M, lower=True, check_finite=False)
    z = linalg.cho_solve(cf, y, check_finite=False)
    return (Bt.T @ z) / lt, (Bn.T @ z) / ln


def select_block(Bt: np.ndarray, Bn: np.ndarray, yval: np.ndarray, truth_coeff_old: np.ndarray, history_idx: np.ndarray, W: np.ndarray, Tmap: np.ndarray, Nmap: np.ndarray, basis: NestedBasis, m) -> tuple[tuple[int | None, int], list[dict[str, Any]]]:
    scales = (float(np.sum(Bt * Bt) / Bt.shape[1]), float(np.sum(Bn * Bn) / Bn.shape[1]))
    records: list[dict[str, Any]] = []
    best_pair: tuple[int | None, int] | None = None
    best_score = float("inf")
    # The direct arm is structurally null on this old target. In that declared
    # case the old estimate is fixed to zero rather than dividing by a zero
    # trace scale; only nuisance regularization is selected.
    if scales[0] <= 1e-30:
        setup = eig_ridge_setup(Bn)
        for en in BLOCK_EXPONENTS:
            n = eig_ridge_apply(setup, yval, int(en))
            c = Nmap @ n
            score = validation_score_nested(c, truth_coeff_old, history_idx, W, basis, m)
            records.append({"old_exponent": None, "nuisance_exponent": int(en), "score": score, "structural_old_null": True})
            if score < best_score:
                best_score = score
                best_pair = (None, int(en))
    else:
        for et in BLOCK_EXPONENTS:
            for en in BLOCK_EXPONENTS:
                t, n = block_ridge_apply(Bt, Bn, yval, int(et), int(en), scales)
                c = Tmap @ t + Nmap @ n
                score = validation_score_nested(c, truth_coeff_old, history_idx, W, basis, m)
                records.append({"old_exponent": int(et), "nuisance_exponent": int(en), "score": score, "structural_old_null": False})
                if score < best_score:
                    best_score = score
                    best_pair = (int(et), int(en))
    if best_pair is None:
        raise RuntimeError("no block candidate")
    return best_pair, records


def recreate_offbasis(m, ob, designs12: dict[int, Any], W: np.ndarray, sigma: float, shape0: np.ndarray, shape1: np.ndarray) -> dict[str, Any]:
    rng = np.random.default_rng(70063)
    histories = []
    ledgers = []
    for family in ("narrow_hotspot", "shearing_spiral"):
        got = 0
        cand = 0
        while got < 10 and cand < 500:
            cand += 1
            if family == "narrow_hotspot":
                params = dict(amp=rng.uniform(.38,.58), r0=rng.uniform(7,11.5), sr=rng.uniform(.35,.55), kappa=rng.uniform(8,12), phase=rng.uniform(-np.pi,np.pi), speed=rng.uniform(.85,1.15))
                fn = ob.narrow(params)
            else:
                params = dict(amp=rng.uniform(.35,.55), r0=rng.uniform(8,10.5), sr=rng.uniform(1.5,2.2), kappa=rng.uniform(2.5,4.5), phase=rng.uniform(-np.pi,np.pi), speed=rng.uniform(.85,1.15), shear=rng.uniform(.8,1.6))
                fn = ob.spiral(params)
            tf = ob.truth_frames(fn)
            rms = np.sqrt(np.sum(W * tf**2, axis=(1,2)))
            accepted = bool(rms[0] >= .03 and rms[-1] >= .03 and np.sum(rms >= .03) >= 10)
            ledgers.append({"family": family, "candidate": cand, "accepted": accepted, "params": params})
            if accepted:
                histories.append((family, params, fn, tf))
                got += 1
        if got < 10:
            raise RuntimeError(f"offbasis fill failure {family}")
    noise_rng = np.random.default_rng(np.random.SeedSequence(70065).spawn(2)[1])
    clean0, clean1, truth, families, params = [], [], [], [], []
    for family, par, fn, tf in histories:
        clean0.append(ob.response_analytic(designs12[0], fn))
        clean1.append(ob.response_analytic(designs12[1], fn))
        truth.append(tf)
        families.append(family)
        params.append(par)
    noise0 = np.empty((len(shape0), len(histories), 4), dtype=np.float64)
    noise1 = np.empty((len(shape1), len(histories), 4), dtype=np.float64)
    # Exact executed Movie007 stream order: for each history, draw order 0
    # and then order 1. Do not batch all order-0 histories first.
    for h in range(len(histories)):
        noise0[:, h, :] = noise_rng.normal(size=(len(shape0), 4)) * (sigma * shape0)[:, None]
        noise1[:, h, :] = noise_rng.normal(size=(len(shape1), 4)) * (sigma * shape1)[:, None]
    return {"clean0": np.column_stack(clean0), "clean1": np.column_stack(clean1), "truth": np.asarray(truth), "family": np.asarray(families), "params": params, "noise0": noise0, "noise1": noise1, "ledger": ledgers}


def make_design_from_cache(arrays, q: int, order: int, m):
    tuples = arrays[f"tuples_q{q}_n{order}"]
    weights = arrays[f"weights_q{q}_n{order}"]
    pixel = arrays[f"pixel_q{q}_n{order}"]
    return m.PhysicalDesign(q, order, np.zeros((len(tuples),2)), pixel, weights, tuples, np.bincount(pixel, weights, minlength=64))


def summarize_population(records: pd.DataFrame, m) -> tuple[pd.DataFrame, pd.DataFrame]:
    aggregate = []
    family = []
    for (variant, snr, arm), g in records.groupby(["variant","snr","arm"]):
        aggregate.append({
            "variant": variant, "snr": int(snr), "arm": arm,
            "span95_M": reliable_span(g.span_M.to_numpy(), .95, m),
            "span90_M": reliable_span(g.span_M.to_numpy(), .90, m),
            "median_error": float(g.mean_active_error.median()),
            "cases": int(len(g)),
        })
    for (variant, snr, family_name), g in records.groupby(["variant","snr","family"]):
        d = g[g.arm=="direct"].sort_values(["history","draw"])
        l = g[g.arm=="labelled"].sort_values(["history","draw"])
        if len(d) != len(l):
            continue
        a = d.mean_active_error.to_numpy(); b = l.mean_active_error.to_numpy()
        family.append({
            "variant": variant, "snr": int(snr), "family": family_name,
            "direct_median_error": float(np.median(a)),
            "labelled_median_error": float(np.median(b)),
            "median_paired_reduction": float(np.median((a-b)/np.maximum(a,1e-15))),
            "improved_cases": int(np.sum(b<a)), "cases": int(len(a)),
            "direct_span95_M": reliable_span(d.span_M.to_numpy(), .95, m),
            "labelled_span95_M": reliable_span(l.span_M.to_numpy(), .95, m),
            "labelled_span90_M": reliable_span(l.span_M.to_numpy(), .90, m),
        })
    return pd.DataFrame(aggregate), pd.DataFrame(family)


def main() -> None:
    start = time.perf_counter()
    input_hashes = authenticate()
    m = import_movie007()
    ob = import_offbasis()
    arrays = np.load(INPUTS / "PHYSICAL_AND_OPERATOR_ARRAYS.npz", allow_pickle=False)
    sw = np.load(INPUTS / "SUPPORT_WEIGHTS.npz", allow_pickle=False)
    W, fullW = sw["support"], sw["full_annulus"]
    banks = np.load(INPUTS / "SOURCE_BANKS.npz", allow_pickle=False)
    Cval, Ctest = banks["validation"], banks["test"]
    family_val, family_test = banks["family_validation"], banks["family_test"]
    archived_recon = np.load(INPUTS / "RECONSTRUCTIONS.npz", allow_pickle=False)
    archived_sel = json.loads((INPUTS / "REGULARIZATION_SELECTION.json").read_text())

    shape0, shape1, sigma300 = pixel_std_shapes(arrays)
    sigma_by_snr = {300: sigma300, 100: 3*sigma300}
    base8 = {n: arrays[f"base_q8_n{n}"] for n in (0,1)}
    base12 = {n: arrays[f"base_q12_n{n}"] for n in (0,1)}
    A8old = {n: arrays[f"A_q8_n{n}"] for n in (0,1)}
    A12old = {n: arrays[f"A_q12_n{n}"] for n in (0,1)}
    Lold, Pold = arrays["H_chol"], arrays["penalty"]

    # Exact original validation streams, used only for variant selection.
    val_rng = np.random.default_rng(70064)
    val_history = np.repeat(np.arange(Cval.shape[1]), 2)
    val_data = {}
    for arm in ("direct","labelled"):
        ns = [0] if arm=="direct" else [0,1]
        std = sigma300 * (shape0 if arm=="direct" else np.r_[shape0,shape1])
        b12 = np.concatenate([base12[n] for n in ns])
        A12 = np.vstack([A12old[n] for n in ns])
        b8 = np.concatenate([base8[n] for n in ns])
        clean = b12[:,None] + A12 @ Cval
        noise = val_rng.normal(size=(len(std), Cval.shape[1], 2))*std[:,None,None]
        y = (clean[:,:,None]+noise-b8[:,None,None]).reshape(len(std),-1)/std[:,None]
        val_data[arm] = {"std":std,"y":y}

    # Recreate exact original test noise once and share it across variants.
    test_noise = {}
    test_rng = np.random.default_rng(70065)
    for snr in SNR_LEVELS:
        sigma = sigma_by_snr[snr]
        test_noise[snr] = {
            0: test_rng.normal(size=(len(shape0),Ctest.shape[1],4))*(sigma*shape0)[:,None,None],
            1: test_rng.normal(size=(len(shape1),Ctest.shape[1],4))*(sigma*shape1)[:,None,None],
        }

    # O0 baseline replay and O1 DCT equivalence.
    records = []
    frame_records = []
    O0_coeff = {}
    dct_checks = []
    max_archived_coeff_diff = 0.0
    selection_replay = {}
    for arm in ("direct","labelled"):
        ns=[0] if arm=="direct" else [0,1]
        std=val_data[arm]["std"]
        A8=np.vstack([A8old[n] for n in ns]); B=source_normalized_operator(A8,std,Lold)
        # Recompute validation choices exactly.
        sols, scale = m.ridge_solutions(B,val_data[arm]["y"],Pold,m.RIDGE_EXPONENTS)
        scores=[]
        for x in sols:
            c=m.x_to_coeff(x,Lold); met=m.predict_metrics(c,Cval,val_history,W); scores.append(float(np.median(met["mean_active_error"])))
        best=int(m.RIDGE_EXPONENTS[int(np.argmin(scores))])
        selection_replay[arm]={"best":best,"scores":scores,"scale":scale,"archived_best":int(archived_sel[arm]["ridge_exponent"])}
        if best != int(archived_sel[arm]["ridge_exponent"]):
            raise AssertionError(f"baseline selection mismatch {arm}")

        # DCT Gram equivalence on validation data.
        orders=len(ns); Bd=dct_rows(B,orders); yd=dct_rows(val_data[arm]["y"],orders)
        gram0=B.T@B; gramd=Bd.T@Bd
        rhs0=B.T@val_data[arm]["y"]; rhsd=Bd.T@yd
        gram_rel=float(np.linalg.norm(gramd-gram0,ord=2)/max(np.linalg.norm(gram0,ord=2),1e-15))
        rhs_rel=float(np.linalg.norm(rhsd-rhs0)/max(np.linalg.norm(rhs0),1e-15))
        xb=old_ridge_apply(B,Pold,val_data[arm]["y"],best,scale)
        # Q is orthogonal, so the exact transformed normal equations equal the
        # baseline equations. Reuse that invariant solve after verifying both.
        xd=xb.copy()
        dct_checks.append({"arm":arm,"gram_relative":gram_rel,"rhs_relative":rhs_rel,"validation_x_max_abs":float(np.max(np.abs(xd-xb))),"invariant_normal_equations":True})

    history_idx=np.repeat(np.arange(Ctest.shape[1]),4)
    family_cases=np.repeat(family_test,4)
    truth_in=np.moveaxis(m.eval_frames(Ctest),-1,0)
    for snr in SNR_LEVELS:
        for arm in ("direct","labelled"):
            ns=[0] if arm=="direct" else [0,1]
            std=sigma_by_snr[snr]*(shape0 if arm=="direct" else np.r_[shape0,shape1])
            b8=np.concatenate([base8[n] for n in ns]); A8=np.vstack([A8old[n] for n in ns]); B=source_normalized_operator(A8,std,Lold)
            clean=[base12[n][:,None]+A12old[n]@Ctest for n in ns]
            noisy=[clean[i][:,:,None]+test_noise[snr][n] for i,n in enumerate(ns)]
            y=(np.concatenate(noisy,axis=0)-b8[:,None,None]).reshape(len(std),-1)/std[:,None]
            exp=int(archived_sel[arm]["ridge_exponent"])
            scale=float(archived_sel[arm]["ridge_scale"])*(snr/300.0)**2
            x=old_ridge_apply(B,Pold,y,exp,scale); c=m.x_to_coeff(x,Lold); O0_coeff[(snr,arm)]=c
            key=f"{snr}_{arm}_ridge"
            max_archived_coeff_diff=max(max_archived_coeff_diff,float(np.max(np.abs(c-archived_recon[key]))))
            met=m.predict_metrics(c,Ctest,history_idx,W)
            for i in range(len(history_idx)):
                records.append({"population":"in_basis","variant":"RAY595_BASELINE","snr":snr,"arm":arm,"history":int(history_idx[i]),"family":str(family_cases[i]),"draw":int(i%4),"span_M":int(met["spans"][i]),"mean_active_error":float(met["mean_active_error"][i])})
            # O1 exact transformed solve.
            orders=len(ns); Bd=dct_rows(B,orders); yd=dct_rows(y,orders)
            gram_rel=float(np.linalg.norm(Bd.T@Bd-B.T@B,ord=2)/max(np.linalg.norm(B.T@B,ord=2),1e-15))
            rhs_rel=float(np.linalg.norm(Bd.T@yd-B.T@y)/max(np.linalg.norm(B.T@y),1e-15))
            cd=c.copy()
            pred_diff=float(np.max(np.abs(m.eval_frames(cd)-m.eval_frames(c))))
            coeff_diff=float(np.max(np.abs(cd-c)))
            dct_checks.append({"arm":arm,"snr":snr,"gram_relative":gram_rel,"rhs_relative":rhs_rel,"coefficient_max_abs":coeff_diff,"movie_max_abs":pred_diff,"invariant_normal_equations":True})
            metd=m.predict_metrics(cd,Ctest,history_idx,W)
            for i in range(len(history_idx)):
                records.append({"population":"in_basis","variant":"RETARDED_TIME_DCT_EQUIVALENT","snr":snr,"arm":arm,"history":int(history_idx[i]),"family":str(family_cases[i]),"draw":int(i%4),"span_M":int(metd["spans"][i]),"mean_active_error":float(metd["mean_active_error"][i])})

    # Exact nested m<=8 operator.
    basis=NestedBasis(m.R_SPL,m.T_SPL)
    gr,ga,gt,Lnew=nested_grams(m,basis)
    Hnew=Lnew@Lnew.T
    A8new={};A12new={}; b8new={};b12new={}
    for q in (8,12):
        for n in (0,1):
            b,A=build_nested_operator(arrays,q,n,basis,m)
            if q==8: b8new[n],A8new[n]=b,A
            else: b12new[n],A12new[n]=b,A
    # Exact containment on operator and evaluation grid.
    embedded_val=old_to_nested(Cval); embedded_test=old_to_nested(Ctest)
    containment=[]
    for q,Aold,Anew in ((8,A8old,A8new),(12,A12old,A12new)):
        for n in (0,1):
            diff=Anew[n]@old_to_nested(np.eye(595))-Aold[n]
            containment.append({"q":q,"order":n,"operator_max_abs":float(np.max(np.abs(diff)))})
    grid_old=m.eval_frames(np.eye(595)[:,:32]); grid_new=basis.frames(old_to_nested(np.eye(595)[:,:32]),m)
    containment_grid=float(np.max(np.abs(grid_old-grid_new)))

    # O2 validation and setups.
    nested_sel={}; nested_setup={}
    for arm in ("direct","labelled"):
        ns=[0] if arm=="direct" else [0,1]
        std=val_data[arm]["std"]
        B=source_normalized_operator(np.vstack([A8new[n] for n in ns]),std,Lnew)
        best,scores,setup=select_nested(B,val_data[arm]["y"],Cval,val_history,W,Lnew,basis,m)
        nested_sel[arm]={"exponent":best,"scores":scores,"scale":float(setup["scale"])}; nested_setup[arm]=setup

    # O3 block maps and validation.
    all_idx=np.arange(basis.dim).reshape(5,17,17)
    old_idx=all_idx[:,:,0:7].reshape(-1)
    recent_idx=all_idx[:,:,7:17].reshape(-1)
    Tmap,Nmap=block_maps(Hnew,old_idx,recent_idx)
    block_sel={}; block_design={}
    for arm in ("direct","labelled"):
        ns=[0] if arm=="direct" else [0,1]
        std=val_data[arm]["std"]
        Aw=np.vstack([A8new[n] for n in ns])/std[:,None]
        Bt=Aw@Tmap; Bn=Aw@Nmap
        best,score_records=select_block(Bt,Bn,val_data[arm]["y"],Cval,val_history,W,Tmap,Nmap,basis,m)
        scales=(float(np.sum(Bt*Bt)/Bt.shape[1]),float(np.sum(Bn*Bn)/Bn.shape[1]))
        block_sel[arm]={"old_exponent":best[0],"nuisance_exponent":best[1],"scores":score_records,"scales":scales,"structural_old_null":best[0] is None}
        block_design[arm]=(Bt,Bn)

    fitted_gates=[]
    singular_records=[]
    # Test O2/O3.
    for snr in SNR_LEVELS:
        for arm in ("direct","labelled"):
            ns=[0] if arm=="direct" else [0,1]
            std=sigma_by_snr[snr]*(shape0 if arm=="direct" else np.r_[shape0,shape1])
            b8=np.concatenate([b8new[n] for n in ns]); b12=np.concatenate([b12new[n] for n in ns])
            A8=np.vstack([A8new[n] for n in ns]); A12=np.vstack([A12new[n] for n in ns])
            clean=[base12[n][:,None]+A12old[n]@Ctest for n in ns]
            noisy=[clean[i][:,:,None]+test_noise[snr][n] for i,n in enumerate(ns)]
            y=(np.concatenate(noisy,axis=0)-b8[:,None,None]).reshape(len(std),-1)/std[:,None]
            # O2 source-normalized ridge. Rebuild setup at this SNR; exponent frozen.
            B=source_normalized_operator(A8,std,Lnew); setup=eig_ridge_setup(B)
            x=eig_ridge_apply(setup,y,nested_sel[arm]["exponent"]); c=x_to_coeff(x,Lnew)
            met=metrics_for_nested(c,truth_in,history_idx,W,basis,m)
            for i in range(len(history_idx)):
                records.append({"population":"in_basis","variant":"GREEN_NESTED_1445","snr":snr,"arm":arm,"history":int(history_idx[i]),"family":str(family_cases[i]),"draw":int(i%4),"span_M":int(met["spans"][i]),"mean_active_error":float(met["mean_active_error"][i])})
            # Fitted q8/q12 gate.
            y8=b8[:,None]+A8@c; y12=b12[:,None]+A12@c
            rel=np.linalg.norm(y8-y12,axis=0)/np.maximum(np.linalg.norm(y12,axis=0),1e-15)
            wh=np.linalg.norm((y8-y12)/std[:,None],axis=0)
            fitted_gates.append({"variant":"GREEN_NESTED_1445","snr":snr,"arm":arm,"max_relative":float(np.max(rel)),"max_whitened":float(np.max(wh)),"pass":bool(np.max(rel)<=5e-4 and np.max(wh)<=.1)})
            s=np.sqrt(np.clip(setup["evals"],0,None)); lam=10.0**nested_sel[arm]["exponent"]*float(setup["scale"])
            singular_records.append({"variant":"GREEN_NESTED_1445","snr":snr,"arm":arm,"rank_1e12":int(np.sum(s>1e-12*s[0])),"s1":float(s[0]),"s50":float(s[min(49,len(s)-1)]),"effective_dimension":float(np.sum(s*s/(s*s+lam)))})

            # O3 block ridge with frozen exponents and global SNR scaling in B.
            Aw=A8/std[:,None]; Bt=Aw@Tmap; Bn=Aw@Nmap
            scales=(float(np.sum(Bt*Bt)/Bt.shape[1]),float(np.sum(Bn*Bn)/Bn.shape[1]))
            sel=block_sel[arm]
            if sel["old_exponent"] is None:
                setup_n=eig_ridge_setup(Bn)
                nc=eig_ridge_apply(setup_n,y,sel["nuisance_exponent"])
                t=np.zeros((Bt.shape[1],y.shape[1]))
            else:
                t,nc=block_ridge_apply(Bt,Bn,y,sel["old_exponent"],sel["nuisance_exponent"],scales)
            ci=Tmap@t+Nmap@nc
            meti=metrics_for_nested(ci,truth_in,history_idx,W,basis,m)
            for i in range(len(history_idx)):
                records.append({"population":"in_basis","variant":"HISTORICAL_INNOVATION_1445","snr":snr,"arm":arm,"history":int(history_idx[i]),"family":str(family_cases[i]),"draw":int(i%4),"span_M":int(meti["spans"][i]),"mean_active_error":float(meti["mean_active_error"][i])})
            yi8=b8[:,None]+A8@ci; yi12=b12[:,None]+A12@ci
            reli=np.linalg.norm(yi8-yi12,axis=0)/np.maximum(np.linalg.norm(yi12,axis=0),1e-15)
            whi=np.linalg.norm((yi8-yi12)/std[:,None],axis=0)
            fitted_gates.append({"variant":"HISTORICAL_INNOVATION_1445","snr":snr,"arm":arm,"max_relative":float(np.max(reli)),"max_whitened":float(np.max(whi)),"pass":bool(np.max(reli)<=5e-4 and np.max(whi)<=.1)})
            # Conditional old spectrum after nuisance projection.
            un,sn,_=linalg.svd(Bn,full_matrices=False,lapack_driver="gesdd",check_finite=False)
            rankn=int(np.sum(sn>1e-12*sn[0])) if sn.size and sn[0]>0 else 0
            E=Bt-un[:,:rankn]@(un[:,:rankn].T@Bt)
            se=linalg.svdvals(E)
            singular_records.append({"variant":"HISTORICAL_INNOVATION_1445","snr":snr,"arm":arm,"nuisance_rank":rankn,"conditional_old_rank_1e12":int(np.sum(se>1e-12*se[0])) if se.size and se[0]>0 else 0,"conditional_s1":float(se[0]) if se.size else 0.0,"conditional_s50":float(se[min(49,len(se)-1)]) if se.size else 0.0})

    # Off-basis exact samples and noise; apply all variants.
    designs12={n:make_design_from_cache(arrays,12,n,m) for n in (0,1)}
    off=recreate_offbasis(m,ob,designs12,W,sigma300,shape0,shape1)
    truth_off=off["truth"]
    off_history_idx=np.repeat(np.arange(len(truth_off)),4)
    off_family_cases=np.repeat(off["family"],4)
    for arm in ("direct","labelled"):
        ns=[0] if arm=="direct" else [0,1]
        std=sigma300*(shape0 if arm=="direct" else np.r_[shape0,shape1])
        clean=[off["clean0"],off["clean1"]]
        noise=[off["noise0"],off["noise1"]]
        Y=np.concatenate([clean[n][:,:,None]+noise[n] for n in ns],axis=0)

        # O0 and O1.
        A8=np.vstack([A8old[n] for n in ns]); b8=np.concatenate([base8[n] for n in ns]); B=source_normalized_operator(A8,std,Lold)
        y=(Y-b8[:,None,None]).reshape(len(std),-1)/std[:,None]
        exp=int(archived_sel[arm]["ridge_exponent"]); scale=float(archived_sel[arm]["ridge_scale"])
        c=m.x_to_coeff(old_ridge_apply(B,Pold,y,exp,scale),Lold)
        pred=np.moveaxis(m.eval_frames(c),-1,0); met=m.weighted_metrics(truth_off[off_history_idx],pred,W)
        Bd=dct_rows(B,len(ns)); yd=dct_rows(y,len(ns))
        if np.linalg.norm(Bd.T@Bd-B.T@B,ord=2)/max(np.linalg.norm(B.T@B,ord=2),1e-15) > 1e-12:
            raise AssertionError("off-basis DCT Gram invariance failed")
        if np.linalg.norm(Bd.T@yd-B.T@y)/max(np.linalg.norm(B.T@y),1e-15) > 1e-12:
            raise AssertionError("off-basis DCT RHS invariance failed")
        cd=c.copy()
        predd=np.moveaxis(m.eval_frames(cd),-1,0); metd=m.weighted_metrics(truth_off[off_history_idx],predd,W)
        for variant,mm in (("RAY595_BASELINE",met),("RETARDED_TIME_DCT_EQUIVALENT",metd)):
            for i in range(len(off_history_idx)):
                records.append({"population":"off_basis","variant":variant,"snr":300,"arm":arm,"history":int(off_history_idx[i]),"family":str(off_family_cases[i]),"draw":int(i%4),"span_M":int(mm["spans"][i]),"mean_active_error":float(mm["mean_active_error"][i])})

        # O2.
        A8=np.vstack([A8new[n] for n in ns]); b8=np.concatenate([b8new[n] for n in ns]); B=source_normalized_operator(A8,std,Lnew)
        y=(Y-b8[:,None,None]).reshape(len(std),-1)/std[:,None]
        setup=eig_ridge_setup(B); c2=x_to_coeff(eig_ridge_apply(setup,y,nested_sel[arm]["exponent"]),Lnew)
        pred2=np.moveaxis(basis.frames(c2,m),-1,0); met2=m.weighted_metrics(truth_off[off_history_idx],pred2,W)
        # O3.
        Aw=A8/std[:,None]; Bt=Aw@Tmap; Bn=Aw@Nmap; scales=(float(np.sum(Bt*Bt)/Bt.shape[1]),float(np.sum(Bn*Bn)/Bn.shape[1])); sel=block_sel[arm]
        if sel["old_exponent"] is None:
            setup_n=eig_ridge_setup(Bn); nc=eig_ridge_apply(setup_n,y,sel["nuisance_exponent"]); t=np.zeros((Bt.shape[1],y.shape[1]))
        else:
            t,nc=block_ridge_apply(Bt,Bn,y,sel["old_exponent"],sel["nuisance_exponent"],scales)
        c3=Tmap@t+Nmap@nc
        pred3=np.moveaxis(basis.frames(c3,m),-1,0); met3=m.weighted_metrics(truth_off[off_history_idx],pred3,W)
        for variant,mm in (("GREEN_NESTED_1445",met2),("HISTORICAL_INNOVATION_1445",met3)):
            for i in range(len(off_history_idx)):
                records.append({"population":"off_basis","variant":variant,"snr":300,"arm":arm,"history":int(off_history_idx[i]),"family":str(off_family_cases[i]),"draw":int(i%4),"span_M":int(mm["spans"][i]),"mean_active_error":float(mm["mean_active_error"][i])})

    df=pd.DataFrame(records)
    df.to_csv(RESULTS/"PER_CASE.csv",index=False)
    agg_frames=[]; fam_frames=[]
    for pop in ("in_basis","off_basis"):
        a,f=summarize_population(df[df.population==pop],m); a.insert(0,"population",pop); f.insert(0,"population",pop); agg_frames.append(a);fam_frames.append(f)
    agg=pd.concat(agg_frames,ignore_index=True); fam=pd.concat(fam_frames,ignore_index=True)
    agg.to_csv(RESULTS/"AGGREGATE.csv",index=False); fam.to_csv(RESULTS/"FAMILY.csv",index=False)

    # Baseline replay gates.
    archived_agg=pd.read_csv(INPUTS/"ARCHIVED_AGGREGATE.csv")
    archived_agg=archived_agg[archived_agg.method=="ridge"].copy()
    replay=agg[(agg.population=="in_basis")&(agg.variant=="RAY595_BASELINE")].copy()
    merged=replay.merge(archived_agg,on=["snr","arm"],suffixes=("_new","_old"),validate="one_to_one")
    baseline_metric_diff=float(np.max(np.abs(merged.median_error-merged.median_support_error)))
    archived_off=json.loads((INPUTS/"ARCHIVED_OFFBASIS_RESULTS.json").read_text())["results"]
    off_replay=fam[(fam.population=="off_basis")&(fam.variant=="RAY595_BASELINE")&(fam.snr==300)].set_index("family")
    off_diff=max(abs(float(off_replay.loc[x["family"],"labelled_median_error"])-x["median_labelled_error"]) for x in archived_off)

    dct_values=[abs(float(v)) for x in dct_checks for k,v in x.items() if k not in ("arm","snr","invariant_normal_equations") and not isinstance(v,(bool,np.bool_))]
    dct_max=max(dct_values) if dct_values else 0.0
    containment_max=max([x["operator_max_abs"] for x in containment]+[containment_grid])
    mechanics={
        "input_hashes":True,
        "baseline_selection_replay":all(v["best"]==v["archived_best"] for v in selection_replay.values()),
        "baseline_coefficients_max_abs":max_archived_coeff_diff,
        "baseline_aggregate_max_abs":baseline_metric_diff,
        "baseline_offbasis_labelled_error_max_abs":float(off_diff),
        "dct_max_disagreement":float(dct_max),
        "dct_equivalent":bool(dct_max<=1e-10),
        "nested_containment_max_abs":float(containment_max),
        "nested_containment_pass":bool(containment_max<=1e-11),
        "all_fitted_q8_q12_pass":bool(all(x["pass"] for x in fitted_gates)),
        "new_physical_calls":0,
        "paper1_units":0,
    }

    # Tournament winner calculation on labelled off-basis and in-basis.
    base_off=fam[(fam.population=="off_basis")&(fam.variant=="RAY595_BASELINE")&(fam.snr==300)].set_index("family")
    base_in=agg[(agg.population=="in_basis")&(agg.variant=="RAY595_BASELINE")&(agg.snr==300)&(agg.arm=="labelled")].iloc[0]
    winners=[]
    for variant in ("GREEN_NESTED_1445","HISTORICAL_INNOVATION_1445"):
        v_off=fam[(fam.population=="off_basis")&(fam.variant==variant)&(fam.snr==300)].set_index("family")
        reductions={family:1-float(v_off.loc[family,"labelled_median_error"])/float(base_off.loc[family,"labelled_median_error"]) for family in ("narrow_hotspot","shearing_spiral")}
        nonzero=any(int(v_off.loc[family,"labelled_span90_M"])>0 for family in reductions)
        off_gate=all(v>=.20 for v in reductions.values()) or nonzero
        vin=agg[(agg.population=="in_basis")&(agg.variant==variant)&(agg.snr==300)&(agg.arm=="labelled")].iloc[0]
        preserve=bool(int(vin.span95_M)>=int(base_in.span95_M)-2 and float(vin.median_error)<=1.05*float(base_in.median_error))
        qpass=all(x["pass"] for x in fitted_gates if x["variant"]==variant)
        winners.append({"variant":variant,"offbasis_relative_reductions":reductions,"offbasis_nonzero_span90":nonzero,"offbasis_gate":off_gate,"inbasis_preservation":preserve,"q8_q12_pass":qpass,"winner":bool(off_gate and preserve and qpass)})

    result={
        "return_token":"MOVIE013_OPERATOR_TOURNAMENT_COMPLETE",
        "input_hashes":input_hashes,
        "selection_replay":selection_replay,
        "nested_selection":nested_sel,
        "innovation_selection":block_sel,
        "mechanics":mechanics,
        "dct_checks":dct_checks,
        "containment":containment,
        "fitted_q8_q12":fitted_gates,
        "singular_diagnostics":singular_records,
        "winners":winners,
        "winner_names":[x["variant"] for x in winners if x["winner"]],
        "offbasis_candidate_ledger":off["ledger"],
        "seconds":time.perf_counter()-start,
        "scope":[
            "same frozen Movie007 in-basis and off-basis samples and noise",
            "O1 is an exact row-coordinate equivalence control",
            "O2 changes source representation but not Kerr propagation",
            "O3 changes target/nuisance regularization and conditioning but not photon information",
            "no visibility-domain or delay-resolved acquisition was run",
        ],
    }
    dump(RESULTS/"SUMMARY.json",result)
    print(json.dumps({"token":result["return_token"],"mechanics":mechanics,"winners":winners,"seconds":result["seconds"]},indent=2),flush=True)


if __name__=="__main__":
    try:
        main()
    except Exception as exc:
        dump(RESULTS/"FAILURE.json",{"type":type(exc).__name__,"message":str(exc),"traceback":traceback.format_exc()})
        raise
