"""Postplanned independent numerical closeout for Movie013.

This does not change samples, operators, selected regularization, reconstructions,
metrics, or winner rules. It replays the exact off-basis population and checks
q8/q12 clean and fitted responses for every primary operator variant.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
import run_movie013 as r  # noqa: E402


def clean_fn(ob: Any, family: str, params: dict[str, float]):
    if family == "narrow_hotspot":
        return ob.narrow(params)
    if family == "shearing_spiral":
        return ob.spiral(params)
    raise ValueError(family)


def response_gate(y8: np.ndarray, y12: np.ndarray, std: np.ndarray) -> dict[str, Any]:
    rel = np.linalg.norm(y8 - y12, axis=0) / np.maximum(np.linalg.norm(y12, axis=0), 1e-15)
    wh = np.linalg.norm((y8 - y12) / std[:, None], axis=0)
    return {
        "max_relative": float(np.max(rel)),
        "max_whitened": float(np.max(wh)),
        "pass": bool(np.max(rel) <= 5e-4 and np.max(wh) <= 0.1),
    }


def main() -> None:
    input_hashes = r.authenticate()
    m = r.import_movie007()
    ob = r.import_offbasis()
    arrays = np.load(r.INPUTS / "PHYSICAL_AND_OPERATOR_ARRAYS.npz", allow_pickle=False)
    support = np.load(r.INPUTS / "SUPPORT_WEIGHTS.npz", allow_pickle=False)
    W = support["support"]
    summary = json.loads((r.RESULTS / "SUMMARY.json").read_text())
    agg = pd.read_csv(r.RESULTS / "AGGREGATE.csv")
    fam = pd.read_csv(r.RESULTS / "FAMILY.csv")

    shape0, shape1, sigma300 = r.pixel_std_shapes(arrays)
    base8_old = {n: arrays[f"base_q8_n{n}"] for n in (0, 1)}
    base12_old = {n: arrays[f"base_q12_n{n}"] for n in (0, 1)}
    A8_old = {n: arrays[f"A_q8_n{n}"] for n in (0, 1)}
    A12_old = {n: arrays[f"A_q12_n{n}"] for n in (0, 1)}
    Lold, Pold = arrays["H_chol"], arrays["penalty"]
    archived_sel = json.loads((r.INPUTS / "REGULARIZATION_SELECTION.json").read_text())

    basis = r.NestedBasis(m.R_SPL, m.T_SPL)
    _gr, _ga, _gt, Lnew = r.nested_grams(m, basis)
    Hnew = Lnew @ Lnew.T
    A8_new: dict[int, np.ndarray] = {}
    A12_new: dict[int, np.ndarray] = {}
    base8_new: dict[int, np.ndarray] = {}
    base12_new: dict[int, np.ndarray] = {}
    for q in (8, 12):
        for n in (0, 1):
            b, A = r.build_nested_operator(arrays, q, n, basis, m)
            if q == 8:
                base8_new[n], A8_new[n] = b, A
            else:
                base12_new[n], A12_new[n] = b, A

    all_idx = np.arange(basis.dim).reshape(5, 17, 17)
    old_idx = all_idx[:, :, 0:7].reshape(-1)
    recent_idx = all_idx[:, :, 7:17].reshape(-1)
    Tmap, Nmap = r.block_maps(Hnew, old_idx, recent_idx)

    designs12 = {n: r.make_design_from_cache(arrays, 12, n, m) for n in (0, 1)}
    designs8 = {n: r.make_design_from_cache(arrays, 8, n, m) for n in (0, 1)}
    off = r.recreate_offbasis(m, ob, designs12, W, sigma300, shape0, shape1)

    clean8 = {0: [], 1: []}
    for family, params in zip(off["family"], off["params"]):
        fn = clean_fn(ob, str(family), params)
        for n in (0, 1):
            clean8[n].append(ob.response_analytic(designs8[n], fn))
    clean8 = {n: np.column_stack(clean8[n]) for n in (0, 1)}
    clean12 = {0: off["clean0"], 1: off["clean1"]}

    clean_checks = []
    fitted_checks = []
    for arm in ("direct", "labelled"):
        ns = [0] if arm == "direct" else [0, 1]
        std = sigma300 * (shape0 if arm == "direct" else np.r_[shape0, shape1])
        y8_clean = np.vstack([clean8[n] for n in ns])
        y12_clean = np.vstack([clean12[n] for n in ns])
        clean_checks.append({"population": "off_basis", "arm": arm, **response_gate(y8_clean, y12_clean, std)})

        Y = np.concatenate(
            [clean12[n][:, :, None] + (off["noise0"] if n == 0 else off["noise1"]) for n in ns],
            axis=0,
        )
        yobs = Y.reshape(len(std), -1)

        # O0/O1: exact same coefficient solution.
        A8 = np.vstack([A8_old[n] for n in ns])
        b8 = np.concatenate([base8_old[n] for n in ns])
        b12 = np.concatenate([base12_old[n] for n in ns])
        A12 = np.vstack([A12_old[n] for n in ns])
        B = r.source_normalized_operator(A8, std, Lold)
        yw = (yobs - b8[:, None]) / std[:, None]
        exp = int(archived_sel[arm]["ridge_exponent"])
        scale = float(archived_sel[arm]["ridge_scale"])
        c0 = m.x_to_coeff(r.old_ridge_apply(B, Pold, yw, exp, scale), Lold)
        for variant in ("RAY595_BASELINE", "RETARDED_TIME_DCT_EQUIVALENT"):
            fitted_checks.append({
                "population": "off_basis", "variant": variant, "arm": arm,
                **response_gate(b8[:, None] + A8 @ c0, b12[:, None] + A12 @ c0, std),
            })

        # O2.
        A8 = np.vstack([A8_new[n] for n in ns])
        A12 = np.vstack([A12_new[n] for n in ns])
        b8 = np.concatenate([base8_new[n] for n in ns])
        b12 = np.concatenate([base12_new[n] for n in ns])
        B = r.source_normalized_operator(A8, std, Lnew)
        yw = (yobs - b8[:, None]) / std[:, None]
        setup = r.eig_ridge_setup(B)
        exp2 = int(summary["nested_selection"][arm]["exponent"])
        c2 = r.x_to_coeff(r.eig_ridge_apply(setup, yw, exp2), Lnew)
        fitted_checks.append({
            "population": "off_basis", "variant": "GREEN_NESTED_1445", "arm": arm,
            **response_gate(b8[:, None] + A8 @ c2, b12[:, None] + A12 @ c2, std),
        })

        # O3.
        Aw = A8 / std[:, None]
        Bt, Bn = Aw @ Tmap, Aw @ Nmap
        scales = (float(np.sum(Bt * Bt) / Bt.shape[1]), float(np.sum(Bn * Bn) / Bn.shape[1]))
        sel = summary["innovation_selection"][arm]
        if sel["old_exponent"] is None:
            n_setup = r.eig_ridge_setup(Bn)
            nc = r.eig_ridge_apply(n_setup, yw, int(sel["nuisance_exponent"]))
            tc = np.zeros((Bt.shape[1], yw.shape[1]))
        else:
            tc, nc = r.block_ridge_apply(
                Bt, Bn, yw, int(sel["old_exponent"]), int(sel["nuisance_exponent"]), scales
            )
        c3 = Tmap @ tc + Nmap @ nc
        fitted_checks.append({
            "population": "off_basis", "variant": "HISTORICAL_INNOVATION_1445", "arm": arm,
            **response_gate(b8[:, None] + A8 @ c3, b12[:, None] + A12 @ c3, std),
        })

    # Independent winner readback from deterministic tables.
    base_off = fam[(fam.population == "off_basis") & (fam.variant == "RAY595_BASELINE") & (fam.snr == 300)].set_index("family")
    base_in = agg[(agg.population == "in_basis") & (agg.variant == "RAY595_BASELINE") & (agg.snr == 300) & (agg.arm == "labelled")].iloc[0]
    winner_replay = []
    for variant in ("GREEN_NESTED_1445", "HISTORICAL_INNOVATION_1445"):
        v_off = fam[(fam.population == "off_basis") & (fam.variant == variant) & (fam.snr == 300)].set_index("family")
        reductions = {
            f: 1 - float(v_off.loc[f, "labelled_median_error"]) / float(base_off.loc[f, "labelled_median_error"])
            for f in ("narrow_hotspot", "shearing_spiral")
        }
        nonzero = any(int(v_off.loc[f, "labelled_span90_M"]) > 0 for f in reductions)
        off_gate = all(v >= 0.20 for v in reductions.values()) or nonzero
        vin = agg[(agg.population == "in_basis") & (agg.variant == variant) & (agg.snr == 300) & (agg.arm == "labelled")].iloc[0]
        preserve = bool(int(vin.span95_M) >= int(base_in.span95_M) - 2 and float(vin.median_error) <= 1.05 * float(base_in.median_error))
        qpass = all(x["pass"] for x in fitted_checks if x["variant"] == variant)
        winner_replay.append({
            "variant": variant,
            "offbasis_relative_reductions": reductions,
            "offbasis_nonzero_span90": nonzero,
            "offbasis_gate": off_gate,
            "inbasis_preservation": preserve,
            "postplanned_offbasis_q8_q12_pass": qpass,
            "winner": bool(off_gate and preserve and qpass),
        })

    expected = {x["variant"]: x for x in summary["winners"]}
    winner_match = all(
        x["winner"] == expected[x["variant"]]["winner"]
        and abs(x["offbasis_relative_reductions"]["narrow_hotspot"] - expected[x["variant"]]["offbasis_relative_reductions"]["narrow_hotspot"]) < 1e-14
        and abs(x["offbasis_relative_reductions"]["shearing_spiral"] - expected[x["variant"]]["offbasis_relative_reductions"]["shearing_spiral"]) < 1e-14
        for x in winner_replay
    )

    output = {
        "status": "POSTPLANNED_NUMERICAL_VERIFICATION_COMPLETE",
        "purpose": "Complete clean/fitted q8-q12 checks on the exact archived off-basis population and independently replay the tournament decision; no candidate or endpoint changed.",
        "input_hashes": input_hashes,
        "clean_offbasis_q8_q12": clean_checks,
        "fitted_offbasis_q8_q12": fitted_checks,
        "all_clean_offbasis_pass": bool(all(x["pass"] for x in clean_checks)),
        "all_fitted_offbasis_pass": bool(all(x["pass"] for x in fitted_checks)),
        "winner_replay": winner_replay,
        "winner_replay_matches_summary": bool(winner_match),
        "scientific_file_hashes": {
            p.name: r.sha256(p)
            for p in (r.RESULTS / "PER_CASE.csv", r.RESULTS / "AGGREGATE.csv", r.RESULTS / "FAMILY.csv", r.RESULTS / "SUMMARY.json")
        },
        "checks": {
            "inputs_authenticated": True,
            "all_clean_offbasis_q8_q12_pass": bool(all(x["pass"] for x in clean_checks)),
            "all_fitted_offbasis_q8_q12_pass": bool(all(x["pass"] for x in fitted_checks)),
            "winner_replay_matches_summary": bool(winner_match),
            "no_new_physical_calls": True,
            "paper1_units_zero": True,
        },
        "limitations": [
            "This verification reuses the registered histories, noise, operators, and selected hyperparameters after the tournament outcome; it cannot promote a failed variant.",
            "q8/q12 agreement is a two-rule numerical check, not a continuum error certificate.",
        ],
    }
    r.dump(r.RESULTS / "POSTPLANNED_NUMERICAL_VERIFICATION.json", output)
    if not all(output["checks"].values()):
        raise AssertionError(output["checks"])
    print(json.dumps({"status": output["status"], "checks": output["checks"], "clean": clean_checks, "fitted": fitted_checks}, indent=2))


if __name__ == "__main__":
    main()
