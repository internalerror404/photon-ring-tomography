"""Movie009: fresh-seed signal ladder for exact direct-null twin movies.

This code reuses the frozen Movie008 mode bank and authenticated Movie007
source-linear operators. It performs no Kerr ray tracing or physical quadrature.
All amplitudes are reported; no post-outcome threshold or estimator tuning occurs.
"""
from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy import linalg

from common import (
    ROOT,
    RESULTS,
    coefficient_envelope,
    dump,
    load_inputs,
    load_movie007_module,
    make_nuisance_background,
    noise_calibration,
    residual_projector,
    source_norm,
)

ALPHAS = np.array([0.08, 0.16, 0.24, 0.32, 0.40, 0.48], dtype=np.float64)
SNRS = (300, 100)
PAIRS = 60
DRAWS = 4
SIGNS = np.array([1, -1], dtype=np.int64)
MODE_COUNT = 4
ALPHA_MAX = float(ALPHAS[-1])
SEEDS = {"backgrounds": 81061, "directions": 81062, "noise": 81063, "bootstrap": 81064}
MODE_BANK_SHA256 = "da24a26323d615b8f1896be6caa5b9f571601c70446c5bc95e916a7abd0029e1"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def design_from_cache(m, arrays, q: int, order: int):
    tuples = arrays[f"tuples_q{q}_n{order}"]
    weights = arrays[f"weights_q{q}_n{order}"]
    pixels = arrays[f"pixel_q{q}_n{order}"]
    return m.PhysicalDesign(
        q,
        order,
        np.zeros((len(tuples), 2)),
        pixels,
        weights,
        tuples,
        np.bincount(pixels, weights, minlength=64),
    )


def mode_activity(m, coefficient: np.ndarray, weights: np.ndarray) -> dict[str, Any]:
    frames = m.eval_frames(coefficient)
    old = np.arange(3, 15)
    rms = np.sqrt(np.sum(weights[old] * frames[old] ** 2, axis=(1, 2)))
    threshold = 0.20 * max(float(rms.max()), 1e-15)
    active = rms >= threshold
    accepted = bool(active.sum() >= 8 and active[:6].any() and active[6:].any())
    return {"rms": rms, "active": active, "accepted": accepted}


def generate_directions(m, mode_coeff: np.ndarray, weights: np.ndarray) -> tuple[np.ndarray, list[dict[str, Any]]]:
    rng = np.random.default_rng(SEEDS["directions"])
    directions: list[np.ndarray] = []
    ledger: list[dict[str, Any]] = []
    maximum_target_envelope = 0.25 / ALPHA_MAX
    for group, nnz in (("two_mode", 2), ("three_mode", 3), ("four_mode", 4)):
        accepted = 0
        for candidate in range(500):
            ids = rng.choice(MODE_COUNT, size=nnz, replace=False)
            weights_mode = np.zeros(MODE_COUNT)
            weights_mode[ids] = rng.normal(size=nnz)
            weights_mode /= np.linalg.norm(weights_mode)
            coefficient = mode_coeff @ weights_mode
            activity = mode_activity(m, coefficient, weights)
            envelope = coefficient_envelope(coefficient)
            envelope_pass = envelope <= maximum_target_envelope + 1e-15
            keep = bool(activity["accepted"] and envelope_pass)
            ledger.append({
                "group": group,
                "candidate": candidate,
                "mode_indices": ids,
                "mode_weights": weights_mode,
                "active_frames": int(np.sum(activity["active"])),
                "unit_target_envelope": envelope,
                "maximum_allowed_target_envelope": maximum_target_envelope,
                "activity_pass": activity["accepted"],
                "positivity_envelope_pass": envelope_pass,
                "accepted": keep,
            })
            if keep:
                directions.append(weights_mode)
                accepted += 1
                if accepted == 20:
                    break
        if accepted != 20:
            raise RuntimeError(f"Could not fill {group}: {accepted}/20")
    return np.asarray(directions), ledger


def conditional_setup(A0, A1, std0, std1, nuisance_coeff, mode_coeff, arm: str) -> dict[str, Any]:
    if arm == "direct":
        A, std = A0, std0
    elif arm == "labelled":
        A, std = np.vstack([A0, A1]), np.concatenate([std0, std1])
    else:
        raise ValueError(arm)
    bn = (A @ nuisance_coeff) / std[:, None]
    bt = (A @ mode_coeff) / std[:, None]
    qn, nuisance_rank, nuisance_s = residual_projector(bn, 1e-12)
    e = bt - qn @ (qn.T @ bt)
    if arm == "direct":
        if float(np.max(np.abs(e))) != 0.0:
            raise AssertionError("Direct conditional target is not exactly zero")
        pinv = np.zeros((MODE_COUNT, len(std)))
        singular = np.zeros(MODE_COUNT)
    else:
        u, singular, vt = linalg.svd(e, full_matrices=False, lapack_driver="gesdd", check_finite=False)
        keep = singular > 1e-12 * singular[0]
        pinv = vt[keep].T @ ((1.0 / singular[keep])[:, None] * u[:, keep].T)
    return {
        "std": std,
        "qn": qn,
        "e": e,
        "pinv": pinv,
        "singular_values": singular,
        "nuisance_rank": nuisance_rank,
        "nuisance_singular_values": nuisance_s,
    }


def mode_frame_metrics(
    mode_frames: np.ndarray,
    true_a: np.ndarray,
    pred_a: np.ndarray,
    support_weights: np.ndarray,
    chunk: int = 160,
) -> dict[str, np.ndarray]:
    """Vectorized Movie008 metric; arrays are mode x case."""
    ncase = true_a.shape[1]
    old = np.arange(3, 15)
    w = support_weights[old]
    out: dict[str, np.ndarray] = {
        "true_rms": np.empty((12, ncase)),
        "pred_rms": np.empty((12, ncase)),
        "active": np.empty((12, ncase), dtype=bool),
        "error": np.empty((12, ncase)),
        "correlation": np.empty((12, ncase)),
        "passed": np.empty((12, ncase), dtype=bool),
        "active_frames": np.empty(ncase, dtype=np.int64),
        "history_pass": np.empty(ncase, dtype=bool),
        "mean_active_error": np.empty(ncase),
        "minimum_active_correlation": np.empty(ncase),
    }
    for lo in range(0, ncase, chunk):
        hi = min(ncase, lo + chunk)
        truth = np.einsum("trpm,mn->trpn", mode_frames[old], true_a[:, lo:hi], optimize=True)
        pred = np.einsum("trpm,mn->trpn", mode_frames[old], pred_a[:, lo:hi], optimize=True)
        ww = w[..., None]
        truth_rms = np.sqrt(np.sum(ww * truth**2, axis=(1, 2)))
        pred_rms = np.sqrt(np.sum(ww * pred**2, axis=(1, 2)))
        peak = np.max(truth_rms, axis=0)
        active = truth_rms >= 0.20 * np.maximum(peak, 1e-15)[None, :]
        error = np.sqrt(np.sum(ww * (pred - truth) ** 2, axis=(1, 2))) / np.maximum(truth_rms, 1e-15)
        mean_true = np.sum(ww * truth, axis=(1, 2))
        mean_pred = np.sum(ww * pred, axis=(1, 2))
        centered_true = truth - mean_true[:, None, None, :]
        centered_pred = pred - mean_pred[:, None, None, :]
        covariance = np.sum(ww * centered_true * centered_pred, axis=(1, 2))
        denominator = np.sqrt(
            np.sum(ww * centered_true**2, axis=(1, 2))
            * np.sum(ww * centered_pred**2, axis=(1, 2))
        )
        correlation = np.zeros_like(covariance)
        np.divide(covariance, denominator, out=correlation, where=denominator > 1e-15)
        passed = active & (error <= 0.35) & (correlation >= 0.75)
        active_count = np.sum(active, axis=0)
        history_pass = (active_count >= 8) & np.all((~active) | passed, axis=0)
        mean_error = np.sum(error * active, axis=0) / np.maximum(active_count, 1)
        min_correlation = np.min(np.where(active, correlation, np.inf), axis=0)
        min_correlation = np.where(active_count > 0, min_correlation, 0.0)
        sl = slice(lo, hi)
        out["true_rms"][:, sl] = truth_rms
        out["pred_rms"][:, sl] = pred_rms
        out["active"][:, sl] = active
        out["error"][:, sl] = error
        out["correlation"][:, sl] = correlation
        out["passed"][:, sl] = passed
        out["active_frames"][sl] = active_count
        out["history_pass"][sl] = history_pass
        out["mean_active_error"][sl] = mean_error
        out["minimum_active_correlation"][sl] = min_correlation
    return out


def bootstrap_distribution(values: np.ndarray, pairs: np.ndarray, sample_indices: np.ndarray) -> np.ndarray:
    unique = np.unique(pairs)
    pair_mean = np.asarray([np.mean(values[pairs == pair]) for pair in unique])
    return np.mean(pair_mean[sample_indices], axis=1)


def main() -> None:
    if (RESULTS / "SUMMARY.json").exists():
        raise RuntimeError("Movie009 results already exist; use a fresh directory")
    started = time.perf_counter()
    arrays, _registered_support, _selection, input_hashes = load_inputs()
    m = load_movie007_module()
    mode_path = ROOT / "inputs" / "MODE_BANK.npz"
    if sha256(mode_path) != MODE_BANK_SHA256:
        raise RuntimeError("Frozen mode-bank hash mismatch")
    bank = np.load(mode_path, allow_pickle=False)
    mode_coeff = bank["mode_coefficients"]
    nuisance_indices = bank["nuisance_indices"]
    nuisance_coeff = np.eye(595)[:, nuisance_indices]
    H = arrays["H"]
    sigma300, shape0, shape1 = noise_calibration(arrays)

    W1 = m.support_weights([design_from_cache(m, arrays, 12, 1)])
    directions, direction_ledger = generate_directions(m, mode_coeff, W1)
    groups = np.repeat(np.array(["two_mode", "three_mode", "four_mode"]), 20)
    target_unit = mode_coeff @ directions.T
    target_gram_error = float(np.linalg.norm(target_unit.T @ H @ target_unit - directions @ directions.T, ord=2))

    rng_background = np.random.default_rng(SEEDS["backgrounds"])
    backgrounds_list: list[np.ndarray] = []
    background_records: list[dict[str, Any]] = []
    for pair in range(PAIRS):
        coefficient, record = make_nuisance_background(rng_background, nuisance_indices)
        record["pair"] = pair
        record["source_norm"] = source_norm(coefficient, H)
        backgrounds_list.append(coefficient)
        background_records.append(record)
    backgrounds = np.column_stack(backgrounds_list)
    target_envelope = np.array([coefficient_envelope(target_unit[:, i]) for i in range(PAIRS)])
    background_envelope = np.array([record["certified_envelope"] for record in background_records])
    positivity = np.stack([1.0 - background_envelope - alpha * target_envelope for alpha in ALPHAS])
    if float(np.min(positivity)) < 0.5:
        raise AssertionError("Analytic positivity gate failed")

    direct8 = arrays["A_q8_n0"] @ target_unit
    direct12 = arrays["A_q12_n0"] @ target_unit
    order1_8 = arrays["A_q8_n1"] @ target_unit
    order1_12 = arrays["A_q12_n1"] @ target_unit
    if float(np.max(np.abs(direct8))) != 0.0 or float(np.max(np.abs(direct12))) != 0.0:
        raise AssertionError("Fresh target direction is not exactly direct-null")

    setups: dict[int, dict[str, dict[str, Any]]] = {}
    for snr in SNRS:
        noise_factor = 300.0 / snr
        std0 = sigma300 * noise_factor * shape0
        std1 = sigma300 * noise_factor * shape1
        setups[snr] = {
            arm: conditional_setup(
                arrays["A_q8_n0"], arrays["A_q8_n1"], std0, std1,
                nuisance_coeff, mode_coeff, arm,
            )
            for arm in ("direct", "labelled")
        }

    rng_noise = np.random.default_rng(SEEDS["noise"])
    noise_by_snr: dict[int, tuple[np.ndarray, np.ndarray]] = {}
    for snr in SNRS:
        noise_by_snr[snr] = (
            rng_noise.normal(size=(832, PAIRS, DRAWS)),
            rng_noise.normal(size=(832, PAIRS, DRAWS)),
        )

    pair_idx = np.repeat(np.arange(PAIRS), DRAWS * 2)
    draw_idx = np.tile(np.repeat(np.arange(DRAWS), 2), PAIRS)
    sign_idx = np.tile(SIGNS, PAIRS * DRAWS)
    group_idx = groups[pair_idx]
    ncase = len(pair_idx)
    if ncase != 480:
        raise AssertionError(ncase)

    # One paired set of history-cluster resamples is shared across the ladder.
    rng_bootstrap = np.random.default_rng(SEEDS["bootstrap"])
    bootstrap_indices = rng_bootstrap.integers(0, PAIRS, size=(2000, PAIRS))

    mode_frames = m.eval_frames(mode_coeff)
    unit_mode_frame_rms = np.sqrt(np.sum(W1[3:15, ..., None] * mode_frames[3:15] ** 2, axis=(1, 2)))
    unit_direction_frame_rms = unit_mode_frame_rms @ np.abs(directions.T)

    clean_background0 = arrays["base_q12_n0"][:, None] + arrays["A_q12_n0"] @ backgrounds
    clean_background1 = arrays["base_q12_n1"][:, None] + arrays["A_q12_n1"] @ backgrounds

    reconstruction_rows: list[pd.DataFrame] = []
    frame_rows: list[pd.DataFrame] = []
    construction_rows: list[dict[str, Any]] = []
    bootstrap_rows: list[dict[str, Any]] = []
    oracle_rows: list[pd.DataFrame] = []
    saved_estimates: dict[str, np.ndarray] = {
        "directions": directions,
        "target_unit_coefficients": target_unit,
        "backgrounds": backgrounds,
        "groups": groups,
        "case_pair": pair_idx,
        "case_draw": draw_idx,
        "case_sign": sign_idx,
        "alphas": ALPHAS,
    }
    saved_noise: dict[str, np.ndarray] = {}
    direct_pair_max_difference = 0.0
    direct_pair_byte_identical = True

    for snr in SNRS:
        noise_factor = 300.0 / snr
        std0 = sigma300 * noise_factor * shape0
        std1 = sigma300 * noise_factor * shape1
        noise0, noise1 = noise_by_snr[snr]
        saved_noise[f"z0_{snr}"] = noise0
        saved_noise[f"z1_{snr}"] = noise1
        z0 = noise0[:, pair_idx, draw_idx]
        z1 = noise1[:, pair_idx, draw_idx]
        direct_data = clean_background0[:, pair_idx] + std0[:, None] * z0
        paired_difference = float(np.max(np.abs(direct_data[:, 0::2] - direct_data[:, 1::2])))
        direct_pair_max_difference = max(direct_pair_max_difference, paired_difference)
        direct_pair_byte_identical &= np.array_equal(direct_data[:, 0::2], direct_data[:, 1::2])

        for alpha_index, alpha in enumerate(ALPHAS):
            true_a = directions[pair_idx].T * (sign_idx * alpha)[None, :]
            order1_target = order1_12[:, pair_idx] * (sign_idx * alpha)[None, :]
            order1_data = clean_background1[:, pair_idx] + order1_target + std1[:, None] * z1
            labelled_data = np.vstack([direct_data, order1_data])

            for pair in range(PAIRS):
                twin8 = 2.0 * alpha * order1_8[:, pair]
                twin12 = 2.0 * alpha * order1_12[:, pair]
                construction_rows.append({
                    "snr": snr,
                    "alpha": alpha,
                    "pair": pair,
                    "group": groups[pair],
                    "direct_q8_max_abs": float(np.max(np.abs(2.0 * alpha * direct8[:, pair]))),
                    "direct_q12_max_abs": float(np.max(np.abs(2.0 * alpha * direct12[:, pair]))),
                    "q12_twin_whitened_separation": float(np.linalg.norm(twin12 / std1)),
                    "q8_q12_relative": float(np.linalg.norm(twin8 - twin12) / max(np.linalg.norm(twin12), 1e-15)),
                    "q8_q12_whitened": float(np.linalg.norm((twin8 - twin12) / std1)),
                    "minimum_emissivity_bound": float(positivity[alpha_index, pair]),
                })

            plus_clean = np.vstack([
                clean_background0[:, pair_idx],
                clean_background1[:, pair_idx] + alpha * order1_12[:, pair_idx],
            ])
            minus_clean = np.vstack([
                clean_background0[:, pair_idx],
                clean_background1[:, pair_idx] - alpha * order1_12[:, pair_idx],
            ])
            std_labelled = np.concatenate([std0, std1])[:, None]
            dplus = np.sum(((labelled_data - plus_clean) / std_labelled) ** 2, axis=0)
            dminus = np.sum(((labelled_data - minus_clean) / std_labelled) ** 2, axis=0)
            oracle_sign = np.where(dplus <= dminus, 1, -1)
            oracle_rows.append(pd.DataFrame({
                "snr": snr,
                "alpha": alpha,
                "pair": pair_idx,
                "group": group_idx,
                "sign": sign_idx,
                "draw": draw_idx,
                "identity_correct": (oracle_sign == sign_idx).astype(np.int64),
                "delta_chi2_minus_minus_plus": dminus - dplus,
            }))

            for arm, data in (("direct", direct_data), ("labelled", labelled_data)):
                if arm == "direct":
                    pred_a = np.zeros((MODE_COUNT, ncase))
                else:
                    base8 = np.concatenate([arrays["base_q8_n0"], arrays["base_q8_n1"]])
                    setup = setups[snr]["labelled"]
                    y = (data - base8[:, None]) / setup["std"][:, None]
                    y_perp = y - setup["qn"] @ (setup["qn"].T @ y)
                    pred_a = setup["pinv"] @ y_perp
                metrics = mode_frame_metrics(mode_frames, true_a, pred_a, W1)
                dot = sign_idx * np.sum(pred_a * true_a, axis=0) / alpha
                predicted_sign = np.where(dot >= 0, 1, -1)
                pred_norm = np.linalg.norm(pred_a, axis=0)
                target_cosine = np.sum(pred_a * true_a, axis=0) / np.maximum(pred_norm * alpha, 1e-15)
                reconstruction_rows.append(pd.DataFrame({
                    "snr": snr,
                    "alpha": alpha,
                    "pair": pair_idx,
                    "group": group_idx,
                    "sign": sign_idx,
                    "draw": draw_idx,
                    "arm": arm,
                    "identity_correct": (predicted_sign == sign_idx).astype(np.int64),
                    "target_relative_error": np.linalg.norm(pred_a - true_a, axis=0) / alpha,
                    "target_cosine": target_cosine,
                    "active_frames": metrics["active_frames"],
                    "movie_pass": metrics["history_pass"],
                    "mean_active_frame_error": metrics["mean_active_error"],
                    "minimum_active_correlation": metrics["minimum_active_correlation"],
                    "peak_truth_weighted_rms": np.max(metrics["true_rms"], axis=0),
                }))
                if arm == "labelled":
                    for frame_index, tau in enumerate(-2.0 * np.arange(3, 15)):
                        frame_rows.append(pd.DataFrame({
                            "snr": snr,
                            "alpha": alpha,
                            "pair": pair_idx,
                            "group": group_idx,
                            "sign": sign_idx,
                            "draw": draw_idx,
                            "tau": tau,
                            "active": metrics["active"][frame_index],
                            "error": metrics["error"][frame_index],
                            "correlation": metrics["correlation"][frame_index],
                            "pass": metrics["passed"][frame_index],
                        }))
                saved_estimates[f"snr{snr}_alpha{alpha}_{arm}"] = pred_a

    recon = pd.concat(reconstruction_rows, ignore_index=True)
    frames = pd.concat(frame_rows, ignore_index=True)
    construction = pd.DataFrame(construction_rows)
    oracle = pd.concat(oracle_rows, ignore_index=True)

    aggregate_rows: list[dict[str, Any]] = []
    group_rows: list[dict[str, Any]] = []
    for (snr, alpha, arm), group in recon.groupby(["snr", "alpha", "arm"], sort=True):
        pass_bootstrap = bootstrap_distribution(
            group.movie_pass.to_numpy(dtype=float), group.pair.to_numpy(), bootstrap_indices
        )
        identity_bootstrap = bootstrap_distribution(
            group.identity_correct.to_numpy(dtype=float), group.pair.to_numpy(), bootstrap_indices
        )
        setup_s = setups[int(snr)]["labelled"]["singular_values"]
        expected_error = float(np.sqrt(np.sum(1.0 / setup_s**2)) / alpha) if arm == "labelled" else 1.0
        row = {
            "snr": int(snr),
            "alpha": float(alpha),
            "arm": arm,
            "identity_accuracy": float(group.identity_correct.mean()),
            "median_target_relative_error": float(group.target_relative_error.median()),
            "p90_target_relative_error": float(group.target_relative_error.quantile(0.90)),
            "movie_pass_rate": float(group.movie_pass.mean()),
            "bootstrap_movie_median": float(np.median(pass_bootstrap)),
            "bootstrap_movie_p2p5": float(np.percentile(pass_bootstrap, 2.5)),
            "bootstrap_movie_p97p5": float(np.percentile(pass_bootstrap, 97.5)),
            "bootstrap_identity_p2p5": float(np.percentile(identity_bootstrap, 2.5)),
            "expected_GLS_relative_RMS": expected_error,
            "median_peak_truth_weighted_rms": float(group.peak_truth_weighted_rms.median()),
        }
        aggregate_rows.append(row)
        bootstrap_rows.append({
            "snr": int(snr), "alpha": float(alpha), "arm": arm,
            "movie_pass_distribution": pass_bootstrap,
            "identity_distribution": identity_bootstrap,
        })
        for complexity, sub in group.groupby("group", sort=True):
            group_rows.append({
                "snr": int(snr),
                "alpha": float(alpha),
                "arm": arm,
                "group": complexity,
                "identity_accuracy": float(sub.identity_correct.mean()),
                "median_target_relative_error": float(sub.target_relative_error.median()),
                "movie_pass_rate": float(sub.movie_pass.mean()),
                "cases": len(sub),
            })

    aggregate = pd.DataFrame(aggregate_rows)
    group_table = pd.DataFrame(group_rows)

    # Determine the registered threshold at SNR300.
    global_checks = {
        "fresh_direction_count_60": len(directions) == 60,
        "all_accepted_directions_active_at_least_8": all(
            record["active_frames"] >= 8 for record in direction_ledger if record["accepted"]
        ),
        "analytic_positivity_minimum_at_least_0p5": float(np.min(positivity)) >= 0.5,
        "direct_q8_exact_null": float(np.max(np.abs(direct8))) == 0.0,
        "direct_q12_exact_null": float(np.max(np.abs(direct12))) == 0.0,
        "paired_direct_observations_byte_identical": bool(direct_pair_byte_identical and direct_pair_max_difference == 0.0),
        "q8_q12_relative_all": float(construction.q8_q12_relative.max()) <= 5e-4,
        "q8_q12_whitened_all": float(construction.q8_q12_whitened.max()) <= 0.1,
        "no_new_physical_calls": not (ROOT / "attempts" / "physical_calls.jsonl").exists(),
        "paper1_units_used_zero": True,
    }
    threshold_rows = []
    alpha_star = None
    previous_alpha = None
    for alpha in ALPHAS:
        direct = aggregate[(aggregate.snr == 300) & np.isclose(aggregate.alpha, alpha) & (aggregate.arm == "direct")].iloc[0]
        labelled = aggregate[(aggregate.snr == 300) & np.isclose(aggregate.alpha, alpha) & (aggregate.arm == "labelled")].iloc[0]
        groups_at = group_table[(group_table.snr == 300) & np.isclose(group_table.alpha, alpha) & (group_table.arm == "labelled")]
        checks = {
            "direct_identity_exact_half": float(direct.identity_accuracy) == 0.5,
            "labelled_identity_at_least_0p95": float(labelled.identity_accuracy) >= 0.95,
            "movie_pass_at_least_0p95": float(labelled.movie_pass_rate) >= 0.95,
            "bootstrap_lower_at_least_0p90": float(labelled.bootstrap_movie_p2p5) >= 0.90,
            "each_group_movie_pass_at_least_0p90": bool((groups_at.movie_pass_rate >= 0.90).all()),
            **global_checks,
        }
        passed = all(checks.values())
        threshold_rows.append({"alpha": float(alpha), "passed": passed, "checks": checks})
        if passed and alpha_star is None:
            alpha_star = float(alpha)
            break
        previous_alpha = float(alpha)

    status = "MOVIE009_CAUSAL_MOVIE_THRESHOLD_PASS" if alpha_star is not None else "MOVIE009_CAUSAL_MOVIE_THRESHOLD_NOT_REACHED"
    if alpha_star is None:
        threshold_bracket = [float(ALPHAS[-1]), None]
    else:
        index = int(np.where(np.isclose(ALPHAS, alpha_star))[0][0])
        threshold_bracket = [float(ALPHAS[index - 1]) if index > 0 else 0.0, alpha_star]

    # One scalar/batch arithmetic check after all candidate definitions are fixed.
    fixture_alpha = float(ALPHAS[0])
    fixture_snr = 300
    fixture_pair = 0
    fixture_sign = 1
    fixture_draw = 0
    std0 = sigma300 * shape0
    std1 = sigma300 * shape1
    z0 = noise_by_snr[fixture_snr][0][:, fixture_pair, fixture_draw]
    z1 = noise_by_snr[fixture_snr][1][:, fixture_pair, fixture_draw]
    direct_data = clean_background0[:, fixture_pair] + std0 * z0
    order1_data = clean_background1[:, fixture_pair] + fixture_alpha * order1_12[:, fixture_pair] + std1 * z1
    setup = setups[fixture_snr]["labelled"]
    y = (np.concatenate([direct_data, order1_data]) - np.concatenate([arrays["base_q8_n0"], arrays["base_q8_n1"]])) / setup["std"]
    scalar = setup["pinv"] @ (y - setup["qn"] @ (setup["qn"].T @ y))
    batched = saved_estimates[f"snr{fixture_snr}_alpha{fixture_alpha}_labelled"][:, 0]
    scalar_batch_error = float(np.max(np.abs(scalar - batched)))
    if scalar_batch_error > 1e-12:
        raise AssertionError({"scalar_batch_error": scalar_batch_error})

    # Persist dense arrays and tables before summary.
    np.savez_compressed(RESULTS / "SOURCE_AND_ESTIMATES.npz", **saved_estimates)
    np.savez_compressed(RESULTS / "STANDARDIZED_NOISE.npz", **saved_noise)
    np.savez_compressed(
        RESULTS / "BOOTSTRAPS.npz",
        sample_indices=bootstrap_indices,
        **{
            f"snr{row['snr']}_alpha{row['alpha']}_{row['arm']}_movie": row["movie_pass_distribution"]
            for row in bootstrap_rows
        },
        **{
            f"snr{row['snr']}_alpha{row['alpha']}_{row['arm']}_identity": row["identity_distribution"]
            for row in bootstrap_rows
        },
    )
    recon.to_csv(RESULTS / "PER_RECONSTRUCTION.csv", index=False)
    frames.to_csv(RESULTS / "PER_FRAME.csv", index=False)
    construction.to_csv(RESULTS / "CONSTRUCTION_GATES.csv", index=False)
    oracle.to_csv(RESULTS / "PAIR_LIKELIHOOD.csv", index=False)
    aggregate.to_csv(RESULTS / "AGGREGATE.csv", index=False)
    group_table.to_csv(RESULTS / "GROUP_RESULTS.csv", index=False)
    dump(RESULTS / "DIRECTION_LEDGER.json", direction_ledger)
    dump(RESULTS / "BACKGROUND_RECORDS.json", background_records)

    summary = {
        "experiment": "Mahakal II Movie009 direct-null movie signal-strength ladder",
        "status": status,
        "registration_commit": "2ec8dac19844d0fff68b76f6118b5c51717a373e",
        "lineage_movie008_head": "9fec2492b818ccf37e409e9644638913b61e96b5",
        "input_hashes": {**input_hashes, "MODE_BANK.npz": sha256(mode_path)},
        "source_seeds": SEEDS,
        "amplitudes": ALPHAS,
        "snrs": SNRS,
        "pairs": PAIRS,
        "cases_per_arm_per_condition": ncase,
        "alpha_star": alpha_star,
        "threshold_bracket": threshold_bracket,
        "threshold_rows": threshold_rows,
        "global_checks": global_checks,
        "aggregate": aggregate.to_dict(orient="records"),
        "groups": group_table.to_dict(orient="records"),
        "maximum_q8_q12_relative": float(construction.q8_q12_relative.max()),
        "maximum_q8_q12_whitened": float(construction.q8_q12_whitened.max()),
        "minimum_analytic_emissivity_bound": float(construction.minimum_emissivity_bound.min()),
        "minimum_q12_twin_separation_by_snr_alpha": [
            {
                "snr": int(snr),
                "alpha": float(alpha),
                "minimum": float(group.q12_twin_whitened_separation.min()),
            }
            for (snr, alpha), group in construction.groupby(["snr", "alpha"], sort=True)
        ],
        "direct_pair_max_abs_difference": direct_pair_max_difference,
        "target_direction_gram_error": target_gram_error,
        "conditional_singular_values": {
            str(snr): setups[snr]["labelled"]["singular_values"] for snr in SNRS
        },
        "scalar_batch_max_abs": scalar_batch_error,
        "pair_likelihood_accuracy": [
            {
                "snr": int(snr),
                "alpha": float(alpha),
                "accuracy": float(group.identity_correct.mean()),
            }
            for (snr, alpha), group in oracle.groupby(["snr", "alpha"], sort=True)
        ],
        "new_physical_calls": 0,
        "paper1_units_used": 0,
        "scope": [
            "one Movie007 Kerr chart with ideal order labels",
            "four frozen q8-selected old nonaxisymmetric modes under a 385-dimensional nuisance model",
            "fresh backgrounds, directions and noise",
            "not off-basis, full-annulus, multi-chart, visibility-domain, telescope, or observational movie recovery",
        ],
        "seconds": time.perf_counter() - started,
    }
    dump(RESULTS / "SUMMARY.json", summary)
    print(json.dumps({
        "status": status,
        "alpha_star": alpha_star,
        "threshold_bracket": threshold_bracket,
        "maximum_q8_q12_relative": summary["maximum_q8_q12_relative"],
        "maximum_q8_q12_whitened": summary["maximum_q8_q12_whitened"],
        "minimum_analytic_emissivity_bound": summary["minimum_analytic_emissivity_bound"],
        "seconds": summary["seconds"],
    }, indent=2))


if __name__ == "__main__":
    main()
