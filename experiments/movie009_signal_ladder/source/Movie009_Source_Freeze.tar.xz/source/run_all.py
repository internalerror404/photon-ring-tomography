"""Run Movie009 once in a fresh authenticated directory."""
from pathlib import Path
import os
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
if (root / "results" / "SUMMARY.json").exists():
    raise SystemExit("Movie009 outputs exist; reproduce in a fresh directory")
env = {**os.environ, "OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1", "NUMEXPR_NUM_THREADS": "1"}
for script in ("run_signal_ladder.py", "verify.py"):
    subprocess.run([sys.executable, str(root / "source" / script)], cwd=root, env=env, check=True)
