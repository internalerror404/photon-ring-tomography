"""Independent readback for Movie009. No source generation or physical call."""
from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import linalg

from common import ROOT, RESULTS, coefficient_envelope, dump, load_inputs, load_movie007_module, noise_calibration

MODE_BANK_SHA256 = "da24a26323d615b8f1896be6caa5b9f571601c70446c5bc95e916a7abd0029e1"
ALPHAS = np.array([0.08, 0.16, 0.24, 0.32, 0.40, 0.48])


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    started = time.perf_counter()
    arrays, _support, _selection, input_hashes = load_inputs()
    module = load_movie007_module()
    summary = json.loads((RESULTS / "SUMMARY.json").read_text())
    bank_path = ROOT / "inputs" / "MODE_BANK.npz"
    if sha256(bank_path) != MODE_BANK_SHA256:
        raise RuntimeError("Mode bank hash mismatch")
    bank = np.load(bank_path, allow_pickle=False)
    estimates = np.load(RESULTS / "SOURCE_AND_ESTIMATES.npz", allow_pickle=False)
    noise = np.load(RESULTS / "STANDARDIZED_NOISE.npz", allow_pickle=False)
    boot = np.load(RESULTS / "BOOTSTRAPS.npz", allow_pickle=False)
    recon = pd.read_csv(RESULTS / "PER_RECONSTRUCTION.csv")
    frames = pd.read_csv(RESULTS / "PER_FRAME.csv")
    construction = pd.read_csv(RESULTS / "CONSTRUCTION_GATES.csv")
    aggregate = pd.read_csv(RESULTS / "AGGREGATE.csv")
    groups = pd.read_csv(RESULTS / "GROUP_RESULTS.csv")

    mode_coeff = bank["mode_coefficients"]
    nuisance = bank["nuisance_indices"]
    nuisance_coeff = np.eye(595)[:, nuisance]
    H = arrays["H"]
    directions = estimates["directions"]
    target_unit = estimates["target_unit_coefficients"]
    backgrounds = estimates["backgrounds"]
    pair_idx = estimates["case_pair"]
    draw_idx = estimates["case_draw"]
    sign_idx = estimates["case_sign"]
    sigma300, shape0, shape1 = noise_calibration(arrays)

    # Basic source/operator identities.
    direct8 = arrays["A_q8_n0"] @ target_unit
    direct12 = arrays["A_q12_n0"] @ target_unit
    target_gram_error = float(np.linalg.norm(target_unit.T @ H @ target_unit - directions @ directions.T, ord=2))
    target_envelopes = np.array([coefficient_envelope(target_unit[:, i]) for i in range(60)])
    background_envelopes = np.array([coefficient_envelope(backgrounds[:, i]) for i in range(60)])
    positivity_min = float(np.min(1.0 - background_envelopes[None, :] - ALPHAS[:, None] * target_envelopes[None, :]))

    # Reconstruct every aggregate row from the per-case table.
    aggregate_error = 0.0
    for _, row in aggregate.iterrows():
        sub = recon[(recon.snr == row.snr) & np.isclose(recon.alpha, row.alpha) & (recon.arm == row.arm)]
        values = {
            "identity_accuracy": float(sub.identity_correct.mean()),
            "median_target_relative_error": float(sub.target_relative_error.median()),
            "p90_target_relative_error": float(sub.target_relative_error.quantile(0.90)),
            "movie_pass_rate": float(sub.movie_pass.mean()),
        }
        for key, value in values.items():
            aggregate_error = max(aggregate_error, abs(value - float(row[key])))

    # Reconstruct bootstrap distributions with the saved registered resamples.
    sample_indices = boot["sample_indices"]
    bootstrap_error = 0.0
    for _, row in aggregate.iterrows():
        sub = recon[(recon.snr == row.snr) & np.isclose(recon.alpha, row.alpha) & (recon.arm == row.arm)]
        pair_mean = np.asarray([sub[sub.pair == pair].movie_pass.mean() for pair in range(60)])
        distribution = np.mean(pair_mean[sample_indices], axis=1)
        saved = boot[f"snr{int(row.snr)}_alpha{row.alpha}_{row.arm}_movie"]
        bootstrap_error = max(bootstrap_error, float(np.max(np.abs(distribution - saved))))

    # Independent q8 conditional GLS calculation for the first primary case.
    std0 = sigma300 * shape0
    std1 = sigma300 * shape1
    A = np.vstack([arrays["A_q8_n0"], arrays["A_q8_n1"]])
    std = np.concatenate([std0, std1])
    bn = (A @ nuisance_coeff) / std[:, None]
    bt = (A @ mode_coeff) / std[:, None]
    u, s_n, _ = linalg.svd(bn, full_matrices=False, lapack_driver="gesdd", check_finite=False)
    rank = int(np.sum(s_n > 1e-12 * s_n[0]))
    qn = u[:, :rank]
    e = bt - qn @ (qn.T @ bt)
    e_pinv = np.linalg.pinv(e, rcond=1e-12)
    pair, draw, sign, alpha = 0, 0, 1, 0.08
    z0 = noise["z0_300"][:, pair, draw]
    z1 = noise["z1_300"][:, pair, draw]
    coefficient = backgrounds[:, pair] + sign * alpha * target_unit[:, pair]
    data0 = arrays["base_q12_n0"] + arrays["A_q12_n0"] @ coefficient + std0 * z0
    data1 = arrays["base_q12_n1"] + arrays["A_q12_n1"] @ coefficient + std1 * z1
    y = (np.concatenate([data0, data1]) - np.concatenate([arrays["base_q8_n0"], arrays["base_q8_n1"]])) / std
    y_perp = y - qn @ (qn.T @ y)
    independent = e_pinv @ y_perp
    saved = estimates["snr300_alpha0.08_labelled"][:, 0]
    independent_gls_error = float(np.max(np.abs(independent - saved)))

    # Direct paired observations are exactly identical by construction and readback.
    direct_base = arrays["base_q12_n0"][:, None] + arrays["A_q12_n0"] @ backgrounds
    direct_cases = direct_base[:, pair_idx] + std0[:, None] * noise["z0_300"][:, pair_idx, draw_idx]
    direct_pair_difference = float(np.max(np.abs(direct_cases[:, 0::2] - direct_cases[:, 1::2])))
    direct_pair_identical = np.array_equal(direct_cases[:, 0::2], direct_cases[:, 1::2])

    # Recompute threshold from compact records and registered conditions.
    threshold = None
    threshold_checks = []
    for alpha in ALPHAS:
        direct = aggregate[(aggregate.snr == 300) & np.isclose(aggregate.alpha, alpha) & (aggregate.arm == "direct")].iloc[0]
        labelled = aggregate[(aggregate.snr == 300) & np.isclose(aggregate.alpha, alpha) & (aggregate.arm == "labelled")].iloc[0]
        group_at = groups[(groups.snr == 300) & np.isclose(groups.alpha, alpha) & (groups.arm == "labelled")]
        checks = {
            "direct_half": float(direct.identity_accuracy) == 0.5,
            "labelled_identity": float(labelled.identity_accuracy) >= 0.95,
            "movie_pass": float(labelled.movie_pass_rate) >= 0.95,
            "bootstrap_lower": float(labelled.bootstrap_movie_p2p5) >= 0.90,
            "groups": bool((group_at.movie_pass_rate >= 0.90).all()),
            "positivity": positivity_min >= 0.5,
            "relative_gate": float(construction.q8_q12_relative.max()) <= 5e-4,
            "whitened_gate": float(construction.q8_q12_whitened.max()) <= 0.1,
        }
        passed = all(checks.values())
        threshold_checks.append({"alpha": float(alpha), "passed": passed, "checks": checks})
        if passed and threshold is None:
            threshold = float(alpha)

    expected_input_hashes = {**input_hashes, "MODE_BANK.npz": MODE_BANK_SHA256}
    checks = {
        "input_hashes_match_summary": summary["input_hashes"] == expected_input_hashes,
        "source_arrays_finite": all(np.isfinite(estimates[name]).all() for name in estimates.files if estimates[name].dtype.kind in "fiu"),
        "noise_arrays_finite": all(np.isfinite(noise[name]).all() for name in noise.files),
        "mode_source_orthonormality": float(np.linalg.norm(mode_coeff.T @ H @ mode_coeff - np.eye(4), ord=2)) <= 1e-10,
        "target_direction_gram": target_gram_error <= 1e-10,
        "fresh_direct_q8_exact_zero": float(np.max(np.abs(direct8))) == 0.0,
        "fresh_direct_q12_exact_zero": float(np.max(np.abs(direct12))) == 0.0,
        "analytic_positivity": positivity_min >= 0.5,
        "aggregate_readback": aggregate_error <= 1e-12,
        "bootstrap_readback": bootstrap_error == 0.0,
        "independent_conditional_GLS": independent_gls_error <= 1e-10,
        "paired_direct_byte_identical": bool(direct_pair_identical and direct_pair_difference == 0.0),
        "threshold_recomputed": threshold == summary["alpha_star"],
        "threshold_rows_recomputed": [row["passed"] for row in threshold_checks] == [row["passed"] for row in summary["threshold_rows"]],
        "case_count": len(recon) == 2 * 6 * 2 * 480,
        "frame_count": len(frames) == 2 * 6 * 12 * 480,
        "construction_count": len(construction) == 2 * 6 * 60,
        "all_tables_finite": all(
            np.isfinite(frame.select_dtypes(include=[np.number]).to_numpy()).all()
            for frame in (recon, frames, construction, aggregate, groups)
        ),
        "no_physical_attempt_ledger": not (ROOT / "attempts" / "physical_calls.jsonl").exists(),
    }
    result = {
        "checks": checks,
        "all_checks_pass": all(checks.values()),
        "aggregate_max_abs_readback": aggregate_error,
        "bootstrap_max_abs_readback": bootstrap_error,
        "independent_conditional_GLS_max_abs": independent_gls_error,
        "target_direction_gram_error": target_gram_error,
        "minimum_analytic_emissivity_bound": positivity_min,
        "direct_pair_max_abs_difference": direct_pair_difference,
        "recomputed_alpha_star": threshold,
        "recomputed_threshold_rows": threshold_checks,
        "seconds": time.perf_counter() - started,
    }
    if not result["all_checks_pass"]:
        dump(RESULTS / "VERIFICATION.json", result)
        raise AssertionError(result)
    dump(RESULTS / "VERIFICATION.json", result)
    print(json.dumps({"all_checks_pass": True, "recomputed_alpha_star": threshold, "seconds": result["seconds"]}, indent=2))


if __name__ == "__main__":
    main()
